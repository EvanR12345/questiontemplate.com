"""Bounded-memory FFmpeg assembly with cached chapters and separate intro."""

import copy, hashlib, json, math, os, shutil, subprocess, threading, time, wave
from pathlib import Path
from studio_qc import decision as qc_decision
from studio_data import UNCHANGED, digest
from studio_video_settings import capture as capture_video_settings
from render_queue import render_unique_clips
from studio_audio import probe as probe_audio

SUPPORTED_MOTIONS = {'static','slow zoom in','slow zoom out','pan left','pan right','pan up','pan down'}
AAC_LC_FRAME_SAMPLES = 1024

def effective_motion(shot, video):
    """Project motion adds movement to AI holds, preserving explicit shot edits."""
    motion = str(shot.get("motion", "static")).strip().lower()
    if motion not in SUPPORTED_MOTIONS:
        motion = 'static'
    mode = video.get("motionMode", "director")
    if mode == "static":
        return "static"
    if mode != "gentle" or shot.get("manual", {}).get("motion") or motion != "static":
        return motion
    duration = shot.get("end", 0) - shot.get("start", 0)
    camera = shot.get("camera", {}).get("shot", "").lower()
    if duration < 2 or "insert" in camera or "extreme close" in camera:
        return "static"
    if duration >= 8 and ("establishing" in camera or "extreme wide" in camera):
        return "pan right"
    if "close" in camera or "reaction" in camera:
        return "slow zoom out"
    return "slow zoom in"


class VideoRenderer:
    allow_legacy_render_reuse = True
    def __init__(self, store, config):
        self.store = store
        self.config = config
        self._asset_digests = {}

    @staticmethod
    def review_context(project):
        # Reuse reference digests within this preflight only. A later render
        # revalidates references and manual acceptances against current bytes.
        return {'files': {}, 'reviews': {},
                'chapters': {c['id']: c for c in project['chapters']},
                'intro': {s['id'] for s in project.get('intro', {}).get('shots', []) if s.get('id')}}

    @staticmethod
    def available_memory_bytes():
        try:
            if os.name == 'nt':
                import ctypes
                class MemoryStatus(ctypes.Structure):
                    _fields_ = [('length',ctypes.c_ulong),('load',ctypes.c_ulong)] + [
                        (name,ctypes.c_ulonglong) for name in
                        ('total','available','pageTotal','pageAvailable','virtualTotal','virtualAvailable','extended')]
                status = MemoryStatus()
                status.length = ctypes.sizeof(status)
                if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
                    return status.available
            else:
                return os.sysconf('SC_AVPHYS_PAGES') * os.sysconf('SC_PAGE_SIZE')
        except (AttributeError,OSError,ValueError):
            pass
        return None

    def render_capacity(self, video, pending=0):
        maximum = self.config.get('renderWorkers',2)
        if isinstance(maximum,bool) or not isinstance(maximum,int) or not 1 <= maximum <= 3:
            raise ValueError('Choose one to three render workers.')
        maximum = min(maximum,max(1,(os.cpu_count() or 1)//4))
        available = self.available_memory_bytes()
        if available is None:
            return 1
        # Account for workers already using RAM, then keep headroom for Chrome
        # and the queue owner. Never kill a clip just because capacity shrank.
        slot = max(256*2**20, video['width']*video['height']*300)
        capacity = int((available + pending*slot - 512*2**20)//slot)
        return max(1,min(maximum,capacity))

    def render_clips(self, project, jobs, render, gate, video):
        return render_unique_clips(jobs,render,gate,workers=self.config.get('renderWorkers',2),
                                   capacity=lambda pending:self.render_capacity(video,pending))

    def asset_identity(self, project_id, name):
        """Hash the saved bytes once per file revision, not QC or prompt metadata."""
        path = self.store.asset(project_id, name)
        stat = path.stat()
        stamp = (stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns)
        cached = self._asset_digests.get(str(path))
        if cached and cached[0] == stamp:
            return cached[1]
        with path.open('rb') as asset:
            checksum = hashlib.sha256()
            for chunk in iter(lambda: asset.read(1024 * 1024), b''):
                checksum.update(chunk)
            checksum = checksum.hexdigest()
        self._asset_digests[str(path)] = (stamp, checksum)
        return checksum

    def shot_identity(self, project, shot):
        video = project['settings']['video']
        identity = {
            # A clip's pixels depend on its frame count, not where it sits in
            # narration. Moving an unchanged shot must not encode it again.
            'frames': max(1, round(shot['end']*video['fps']) - round(shot['start']*video['fps'])),
            'image': self.asset_identity(project['id'], shot['imagePath']),
            'motion': effective_motion(shot, video),
            'zoomAmount': shot.get('motionSettings', {}).get('zoomAmount', video.get('zoomAmount', .06)),
        }
        if identity['motion'] != 'static':
            identity['subpixelMotionVersion'] = 1
        return identity

    def cached_asset(self, project_id, path):
        """Restore only the exact content-addressed cache requested by this plan.

        Cloud jobs start with empty scratch. Local existence checks alone would
        discard reusable footage in the verified archive on every new job.
        """
        relative = Path(path).relative_to(self.store.folder(project_id)).as_posix()
        target = self.store.asset(project_id, relative)
        return target.is_file() and target.stat().st_size > 0

    def completed_output(self, path):
        callback = getattr(self, 'on_output', None)
        if callable(callback):
            callback(Path(path))

    @staticmethod
    def legacy_is_current(legacy, inputs):
        # Old cache keys did not hash asset bytes. An image or WAV replaced at
        # the same path must not inherit a render of its previous contents.
        return legacy.is_file() and legacy.stat().st_size > 0 and all(
            asset.stat().st_mtime_ns <= legacy.stat().st_mtime_ns for asset in inputs
        )

    @staticmethod
    def reuse_legacy_clip(legacy, current, inputs=()):
        """Keep existing renders usable without consuming another clip's disk space."""
        if current.exists() or not VideoRenderer.legacy_is_current(legacy, inputs):
            return
        try:
            os.link(legacy, current)
        except OSError:
            shutil.copy2(legacy, current)

    def executable(self):
        path = Path(self.config.get("ffmpeg", ""))
        if not path.is_file():
            raise RuntimeError(
                "FFmpeg is unavailable. Set its existing installation path in Advanced settings. No chapter assets were changed."
            )
        return str(path)

    def audio_preview(self, project_id, source, gate, format='opus', bitrate=128):
        """Opus downloads reuse the saved Opus; older input formats remain readable."""
        if format != 'opus':
            raise ValueError('New audio downloads use Opus only.')
        if type(bitrate) is not int or bitrate not in (64, 128, 256):
            raise ValueError('Choose a download bitrate of 64, 128 or 256 kbps.')
        if Path(source).suffix.lower() == '.opus' and bitrate == 128:
            return {'exportPath':source, 'exportCodec':'Opus', 'exportBitrate':128000}
        codec, suffix, label = 'libopus', 'opus', 'Opus'
        signature = digest({'audio':self.asset_identity(project_id, source),
                            'codec':format, 'bitrate':bitrate*1000, 'version':1})
        destination = self.store.folder(project_id) / f'audition-{signature[:24]}.{suffix}'
        if not destination.is_file() or destination.stat().st_size == 0:
            self.run(['-i', str(self.store.asset(project_id, source)), '-vn',
                      '-c:a', codec, '-b:a', f'{bitrate}k',
                      *(['-movflags', '+faststart'] if format == 'aac' else []), str(destination)],
                     gate, self.store.folder(project_id) / 'audition-export.log')
        return {'exportPath':destination.name, 'exportCodec':label, 'exportBitrate':bitrate*1000}

    @staticmethod
    def wait_for_ffmpeg(process, gate):
        while process.poll() is None:
            gate("Rendering video")
            try:
                process.wait(timeout=.15)
            except subprocess.TimeoutExpired:
                pass

    @staticmethod
    def stop_ffmpeg(process):
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()

    def feed_narration(self, destination, segments, channels, gate, log):
        """One decoder feeds the muxer at a time. No PCM file or open input per chapter."""
        rate = 48000
        elapsed = 0.
        written = 0
        for path, duration in segments:
            gate("Joining chapter narration")
            elapsed += duration
            end = round(elapsed * rate)
            samples = end - written
            written = end
            decoder = subprocess.Popen([
                self.executable(), "-hide_banner", "-loglevel", "error", "-nostdin", "-xerror",
                "-i", str(path), "-map", "0:a:0", "-af",
                f"aresample={rate},apad=whole_len={samples},atrim=end_sample={samples}",
                "-ac", str(channels), "-c:a", "pcm_f32le", "-f", "f32le", "pipe:1",
            ], stdout=destination, stderr=log, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            try:
                self.wait_for_ffmpeg(decoder, gate)
                if decoder.returncode:
                    raise RuntimeError("FFmpeg could not join the chapter narration. Original audio and completed videos are retained.")
            finally:
                self.stop_ffmpeg(decoder)

    def run(self, args, gate, log, multiple_outputs=False, *, narration=None):
        # Cache names become visible only after FFmpeg succeeds. A cancelled
        # intro, WAV or concatenation must never be reused as a complete asset.
        destination = Path(args[-1])
        staging = destination.with_name(
            destination.stem + ".writing" + destination.suffix
        )
        staged_args = args if multiple_outputs else [*args[:-1], str(staging)]
        try:
            with Path(log).open("wb") as output:
                proc = subprocess.Popen(
                    [self.executable(), "-hide_banner", "-nostdin", "-y", *staged_args],
                    stdin=subprocess.PIPE if narration else None,
                    stdout=output,
                    stderr=output,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
                try:
                    if narration:
                        with proc.stdin:
                            self.feed_narration(proc.stdin, *narration, gate, output)
                    self.wait_for_ffmpeg(proc, gate)
                finally:
                    self.stop_ffmpeg(proc)
            if proc.returncode:
                detail=Path(log).read_text(errors='replace')[-1400:]
                if 'No space left on device' in detail:
                    raise RuntimeError('Rendering stopped because the disk filled up. Completed clips, original audio and previous videos are retained. Free space and retry; only missing outputs will be rebuilt.')
                raise RuntimeError(
                    "FFmpeg rendering failed: "
                    + detail
                )
            if not multiple_outputs:
                staging.replace(destination)
                self.completed_output(destination)
        finally:
            # This invocation owns its staging path. Keep completed clip caches
            # and previous selected videos; a failed partial cannot be resumed.
            if not multiple_outputs and staging.is_file():
                staging.unlink()

    @staticmethod
    def require_output_space(destination, media_bytes, audio_seconds=0):
        """Bound the next stream-copy assembly from actual completed inputs."""
        required = math.ceil(media_bytes * 1.05 + audio_seconds * 16000) + 64 * 2**20
        free = shutil.disk_usage(Path(destination).parent).free
        if free < required:
            raise RuntimeError(
                f'Not enough disk space to assemble this video: need about {required / 2**30:.2f} GB free; '
                f'{free / 2**30:.2f} GB available. Completed clips and audio are saved. Free space and retry the render.'
            )

    def encoding(self, p):
        v = p["settings"]["video"]
        if (
            v["width"] not in (640, 1280, 1920)
            or v["height"] not in (360, 720, 1080)
            or v["fps"] not in (24, 25, 30, 60)
        ):
            raise ValueError("Use a supported output size and frame rate.")
        return [
            "-c:v",
            "libx264",
            "-preset",
            "veryfast",
            "-crf",
            str(int(v.get("crf", 21))),
            "-pix_fmt",
            "yuv420p",
            "-r",
            str(v["fps"]),
            "-threads",
            "2",
        ]

    def motion(self, shot, v, frames):
        w, h = v["width"], v["height"]
        motion = effective_motion(shot, v)
        interval = max(1, frames - 1)
        zoom = "1"
        x = None
        y = None
        amount = float(shot.get('motionSettings', {}).get('zoomAmount', v.get('zoomAmount', .06)))
        if not math.isfinite(amount) or not 0 <= amount <= .35:
            raise ValueError('Image zoom must be between 0 and 35 percent.')
        progress = f"on/{interval}"
        if v.get('motionEasing') == 'smooth':
            progress = f"(3*pow(on/{interval},2)-2*pow(on/{interval},3))"
        if "zoom in" in motion:
            zoom = f"1+{amount:g}*{progress}"
        elif "zoom out" in motion:
            zoom = f"{1+amount:g}-{amount:g}*{progress}"
        elif "pan left" in motion:
            zoom = "1.08"
            x = f"(W-W/({zoom}))*(1-{progress})"
        elif "pan right" in motion:
            zoom = "1.08"
            x = f"(W-W/({zoom}))*{progress}"
        elif "pan up" in motion:
            zoom = "1.08"
            y = f"(H-H/({zoom}))*(1-{progress})"
        elif "pan down" in motion:
            zoom = "1.08"
            y = f"(H-H/({zoom}))*{progress}"
        fitting = (
            f"scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h}"
            if v.get("imageFit") == "cover"
            else f"scale={w}:{h}:force_original_aspect_ratio=decrease,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2:color=0x101720"
        )
        repeat = f"zoompan=z=1:x=0:y=0:d={frames}:s={w}x{h}:fps={v['fps']}"
        if motion == 'static' or frames <= 1:
            return f'{fitting},{repeat},setsar=1'
        x = x or f'(W-W/({zoom}))/2'
        y = y or f'(H-H/({zoom}))/2'
        # Floating source corners avoid zoompan's integer crop-position jumps.
        corners = [x, y, f'({x})+W/({zoom})', y,
                   x, f'({y})+H/({zoom})', f'({x})+W/({zoom})', f'({y})+H/({zoom})']
        transform = ':'.join(f'{key}=\'{value}\'' for key, value in zip(
            ('x0','y0','x1','y1','x2','y2','x3','y3'), corners))
        return f'{fitting},{repeat},format=yuv444p,perspective={transform}:sense=source:eval=frame:interpolation=cubic,format=yuv420p,setsar=1'

    @staticmethod
    def concat_listing(files, listing, durations=None):
        lines = []
        for i, f in enumerate(files):
            lines.append(
                "file '"
                + str(f.resolve()).replace("\\", "/").replace("'", "'\\''")
                + "'"
            )
            if durations:
                lines.append("duration " + str(durations[i]))
        listing.write_text("\n".join(lines), encoding="utf-8")
        return listing

    def concat(self, files, target, gate, log, durations=None, video_only=False):
        listing = self.concat_listing(files,target.with_suffix('.concat.txt'),durations)
        self.run(
            [
                "-f",
                "concat",
                "-safe",
                "0",
                "-i",
                str(listing),
                *(["-map", "0:v:0", "-an"] if video_only else []),
                "-c",
                "copy",
                "-movflags",
                "+faststart",
                str(target),
            ],
            gate,
            log,
        )

    def chapter(self, p, ch, gate):
        shots = [
            s for scene in ch["scenes"] for s in scene["shots"] if s.get("imagePath")
        ]
        if (
            len(shots) != sum(len(scene["shots"]) for scene in ch["scenes"])
            or not shots
        ):
            raise ValueError("Generate every shot before rendering this chapter.")
        if not ch.get("audio", {}).get("path"):
            raise ValueError("Generate chapter narration first.")
        review_context = self.review_context(p)
        for index,shot in enumerate(shots):
            if qc_decision(p,shot,self.store,review_context)['blocking']:
                raise ValueError(f'Shot {index+1} needs review. Accept this image or request a repair before rendering.')
        if p['settings'].get('qcCheckLevel')!='off' and any(s.get('qc', {}).get('status') == 'PENDING' for s in shots):
            raise ValueError('Finish pending image quality checks before rendering.')
        if ch["audio"].get("textDigest") and ch["audio"]["textDigest"] != digest(
            ch["cleanNarrationText"]
        ):
            raise ValueError(
                "Narration text changed. Regenerate narration and review shot timing before rendering; the previous video is retained."
            )
        cursor = 0
        for shot in shots:
            if abs(shot["start"] - cursor) > 0.08:
                raise ValueError(
                    "Timeline has a gap or overlap. Adjust shot boundaries before rendering."
                )
            cursor = shot["end"]
        if abs(cursor - ch["audio"]["duration"]) > 0.08:
            raise ValueError("Timeline must end at the chapter narration duration.")
        v = p["settings"]["video"]
        fps = v["fps"]
        folder = self.store.folder(p["id"]) / ch["id"]
        folder.mkdir(exist_ok=True)
        legacy_signature = digest(
            {"rendererVersion": 5, "shots": shots, "audio": ch["audio"], "video": v}
        )
        visual_shots = [self.shot_identity(p, shot) for shot in shots]
        previous_visual_shots = [{k:value for k,value in visual.items() if k != 'frames'} |
                                 {'start':shot['start'], 'end':shot['end']}
                                 for shot,visual in zip(shots,visual_shots)]
        previous_signature = digest({
            'rendererVersion': 6, 'shots': previous_visual_shots,
            'transitions': [shot.get('transition') for shot in shots],
            'audio': self.asset_identity(p['id'], ch['audio']['path']),
            'duration': ch['audio']['duration'], 'video': v,
        })
        signature = digest({
            'rendererVersion': 7, 'shots': visual_shots,
            'transitions': [shot.get('transition') for shot in shots],
            'audio': self.asset_identity(p['id'], ch['audio']['path']),
            'duration': ch['audio']['duration'], 'video': v,
        })
        old = ch.get("render", {}).get("narrationRender", ch.get("render", {}))
        old_path = self.store.asset(p['id'], old['path']) if old.get('path') else None
        assets = [self.store.asset(p['id'], s['imagePath']) for s in shots]
        assets.append(self.store.asset(p['id'], ch['audio']['path']))
        if (
            old_path and old_path.is_file() and old_path.stat().st_size > 0
            and (old.get('renderIdentity') in (signature, previous_signature) or
                 self.allow_legacy_render_reuse and old.get('signature') == legacy_signature and all(s['motion'] == 'static' for s in visual_shots) and self.legacy_is_current(old_path, assets))
        ):
            return old | {'renderIdentity': signature, 'downloadName': f"chapter-{ch['number']:03d}.mp4",
                          'reused':True,'renderTimingScope':'reused-base'}
        clip_jobs = []
        # A prior cloud run may have archived this exact chapter even when its
        # original project selection was retained. Recover by content identity
        # before recreating all of its shot clips.
        recovered = folder / f"chapter-{ch['number']:03d}-{signature[:12]}.mp4"
        if self.cached_asset(p['id'], recovered):
            return {'path':recovered.relative_to(self.store.folder(p['id'])).as_posix(),
                'signature':signature,'renderIdentity':signature,'duration':ch['audio']['duration'],
                'created':time.time(),'downloadName':f"chapter-{ch['number']:03d}.mp4",
                'settingsSnapshot':capture_video_settings(p,ch),'reused':True,'renderTimingScope':'reused-base'}
        unique_jobs = {}
        durations = []
        for index, s in enumerate(shots):
            gate(f"Preparing shot {index+1} / {len(shots)}")
            # Round absolute boundaries, avoiding accumulated per-shot rounding drift.
            frames = max(1, round(s["end"] * fps) - round(s["start"] * fps))
            duration = frames / fps
            name = "clip-" + digest({"rendererVersion": 7, "shot": visual_shots[index], "video": v})[:24] + ".mp4"
            clip = folder / name
            previous = folder / ('clip-' + digest({'rendererVersion':6, 'shot':previous_visual_shots[index], 'video':v})[:24] + '.mp4')
            if self.allow_legacy_render_reuse:
                self.reuse_legacy_clip(previous, clip, [assets[index]])
            legacy = folder / ('clip-' + digest({'rendererVersion': 5, 'shot': s, 'video': v})[:24] + '.mp4')
            if self.allow_legacy_render_reuse and visual_shots[index]['motion'] == 'static':
                self.reuse_legacy_clip(legacy, clip, [assets[index]])
            job = {
                'clip':str(clip),
                'sourceAsset':s['imagePath'],
                'sourceDigest':visual_shots[index]['image'],
                'nativeShot':{key:copy.deepcopy(s[key]) for key in
                              ('start','end','motion','motionSettings','manual','camera') if key in s},
                'args':[
                        '-filter_threads','2',
                        "-i",
                        str(self.store.asset(p["id"], s["imagePath"])),
                        "-vf",
                        self.motion(s, v, frames),
                        "-frames:v",
                        str(frames),
                        "-an",
                        *self.encoding(p),
                        str(clip.with_suffix('.partial.mp4')),
                    ],
            }
            # Identical pixels at different timeline positions share one clip.
            # Use the first immutable plan even if identical source bytes have
            # different asset names; no two workers write the same destination.
            unique_jobs.setdefault(name,job)
            clip_jobs.append((name,unique_jobs[name]))
            durations.append(duration)
        cached_clips = threading.Event()
        def render_clip(job, worker_gate):
            clip = Path(job['clip'])
            if self.asset_identity(p['id'],job['sourceAsset'])!=job['sourceDigest']:
                raise ValueError('A source photo changed during rendering. Previous videos are retained; retry to rebuild the updated plan.')
            if not self.cached_asset(p['id'], clip):
                self.run(job['args'],worker_gate,clip.with_suffix('.log'))
                if self.asset_identity(p['id'],job['sourceAsset'])!=job['sourceDigest']:
                    partial=clip.with_suffix('.partial.mp4')
                    if partial.is_file():partial.unlink()
                    raise ValueError('A source photo changed during rendering. Its stale clip was not cached; previous videos are retained.')
                clip.with_suffix('.partial.mp4').replace(clip)
                self.completed_output(clip)
            else:
                cached_clips.set()
            return clip
        clips = self.render_clips(p,clip_jobs,render_clip,gate,v)
        fresh_chapter = len(unique_jobs) == len(shots) and not cached_clips.is_set()
        # Each incoming crossfade blends from the previous shot's final frame.
        # Only two clips are decoded at once, and every boundary keeps its own
        # transition. The fade occupies the incoming shot's first 250 ms, so
        # narration timing and total duration do not drift.
        assembled = []
        for index, clip in enumerate(clips):
            if index and shots[index].get("transition") == "crossfade":
                fade = min(0.25, durations[index] / 2)
                boundary = digest({'version': 1, 'previous': clips[index-1].name, 'incoming': clip.name,
                                   'fade': fade, 'duration': durations[index], 'video': v})
                target = folder / f"fade-{boundary[:24]}.mp4"
                self.reuse_legacy_clip(folder / f"fade-{legacy_signature[:12]}-{index}.mp4", target, [clips[index-1], clip])
                if not self.cached_asset(p['id'], target):
                    temporary = target.with_suffix(".partial.mp4")
                    filters = f"[0:v]trim=end_frame=1,setpts=PTS-STARTPTS,tpad=stop_mode=clone:stop_duration={fade},trim=duration={fade},settb=AVTB,fps={fps}[a];[1:v]setpts=PTS-STARTPTS,settb=AVTB,fps={fps}[b];[a][b]xfade=transition=fade:duration={fade}:offset=0[v]"
                    self.run(
                        [
                            "-sseof",
                            str(-1 / fps - 0.002),
                            "-i",
                            str(clips[index - 1]),
                            "-i",
                            str(clip),
                            "-filter_complex_threads",
                            "1",
                            "-filter_complex",
                            filters,
                            "-map",
                            "[v]",
                            "-t",
                            str(durations[index]),
                            "-an",
                            *self.encoding(p),
                            str(temporary),
                        ],
                        gate,
                        folder / "render.log",
                    )
                    temporary.replace(target)
                    self.completed_output(target)
                else:
                    fresh_chapter = False
                assembled.append(target)
            else:
                assembled.append(clip)
        visual_identity = digest({'version': 1, 'clips': [clip.name for clip in assembled]})
        visual = folder / f"visual-{visual_identity[:24]}.mp4"
        destination = folder / f"chapter-{ch['number']:03d}-{signature[:12]}.mp4"
        temp = destination.with_suffix(".partial.mp4")
        # Reuse existing silent assemblies. For new chapters, concatenate and
        # attach narration in one stream-copy pass, avoiding a second full video.
        if visual.is_file() and visual.stat().st_size:
            fresh_chapter = False
            visual_input = ['-i',str(visual)]
        else:
            listing = self.concat_listing(assembled,destination.with_suffix('.concat.txt'))
            visual_input = ['-f','concat','-safe','0','-i',str(listing)]
        self.require_output_space(destination,
            visual.stat().st_size if visual.is_file() and visual.stat().st_size else sum(c.stat().st_size for c in assembled),
            ch['audio']['duration'])
        self.run(
            [
                *visual_input,
                "-i",
                str(self.store.asset(p["id"], ch["audio"]["path"])),
                "-map",
                "0:v",
                "-map",
                "1:a",
                "-c:v",
                "copy",
                "-c:a",
                "aac",
                "-b:a",
                "128k",
                "-af",
                "apad",
                "-t",
                str(ch["audio"]["duration"]),
                "-movflags",
                "+faststart",
                str(temp),
            ],
            gate,
            folder / "render.log",
        )
        temp.replace(destination)
        self.completed_output(destination)
        return {
            "path": str(destination.relative_to(self.store.folder(p["id"]))).replace(
                "\\", "/"
            ),
            "signature": signature,
            "renderIdentity": signature,
            "duration": ch["audio"]["duration"],
            "created": time.time(),
            "downloadName": f"chapter-{ch['number']:03d}.mp4",
            "settingsSnapshot": capture_video_settings(p, ch),
            "renderTimingScope": "fresh-chapter" if fresh_chapter else "reused-chapter-inputs",
        }

    def watermark_export(self, p, result, gate):
        from studio_branding import identity, bitmap, coordinates
        branding = identity(p,self.store)
        if not branding.get('enabled', True): return result
        source = self.store.asset(p['id'],result['path'])
        signature = digest({'branding':branding,'source':self.asset_identity(p['id'],result['path']),
                            'video':p['settings']['video']})
        target = self.store.folder(p['id']) / ('watermarked-'+signature+'.mp4')
        if not self.cached_asset(p['id'], target):
            logo = target.with_suffix('.png')
            bitmap(p,self.store,logo)
            x,y = coordinates(p)
            self.require_output_space(target,source.stat().st_size*2,result['duration'])
            self.run(['-i',str(source),'-i',str(logo),'-filter_complex_threads','1',
                      '-filter_complex',f'[0:v][1:v]overlay=x={x}:y={y}:eof_action=repeat:format=auto[v]',
                      '-map','[v]','-map','0:a?','-c:a','copy',*self.encoding(p),
                      '-movflags','+faststart',str(target)],gate,target.with_suffix('.log'))
        return result | {'path':target.name,'signature':signature,'renderIdentity':signature,
                         'watermarkIdentity':branding,'narrationRender':result}

    @staticmethod
    def preview_plan(ch, shot_id, fps):
        all_shots = [s for scene in ch.get('scenes', []) for s in scene.get('shots', [])]
        selected = next((s for s in all_shots if s['id'] == shot_id), None)
        if not selected:raise ValueError('Choose an existing shot for the edit preview.')
        total = ch.get('audio', {}).get('duration', 0)
        if type(total) not in (int, float) or not math.isfinite(total) or total <= 0:
            raise ValueError('Generate chapter narration before an edit preview.')
        center = (selected['start'] + selected['end']) / 2
        start = round(max(0, min(center - 7.5, total - 15)) * fps) / fps
        end = min(total, start + 15)
        candidates = [s for s in all_shots if s['end'] > start and s['start'] < end]
        if candidates and candidates[-1]['end'] - candidates[0]['start'] <= 30:
            start, end = candidates[0]['start'], candidates[-1]['end']
        if not candidates or end <= start or end - start > 30.08:
            raise ValueError('This shot has no valid bounded preview interval.')
        return start, end, candidates

    def preview_signature(self, p, ch, shot_id):
        start, end, selected = self.preview_plan(ch, shot_id, p['settings']['video']['fps'])
        from studio_branding import identity
        return digest({'start':start,'end':end,'script':ch['cleanNarrationText'],
            'audio':self.asset_identity(p['id'],ch['audio']['path']),
            'video':p['settings']['video'],'watermark':identity(p,self.store),
            'shots':[{**{key:shot.get(key) for key in ('id','start','end','motion','motionSettings','transition','camera')},
                      'image':self.asset_identity(p['id'],shot['imagePath'])} for shot in selected]})

    def preview(self, p, ch, shot_id, gate):
        """Render at most 30 seconds of saved media; never publish as a chapter.

        Original shot QC is checked before retiming a private copy. It is not
        re-run against the transformed preview or purchased as another API call.
        """
        all_shots = [s for scene in ch.get('scenes', []) for s in scene.get('shots', [])]
        selected = next((s for s in all_shots if s['id'] == shot_id), None)
        if not selected:
            raise ValueError('Choose an existing shot for the edit preview.')
        audio = ch.get('audio', {})
        total = audio.get('duration', 0)
        if not audio.get('path') or not math.isfinite(total) or total <= 0:
            raise ValueError('Generate chapter narration before an edit preview.')
        if audio.get('textDigest') and audio['textDigest'] != digest(ch['cleanNarrationText']):
            raise ValueError('Narration changed. Regenerate audio before previewing the new script.')
        start, end, candidates = self.preview_plan(ch, shot_id, p['settings']['video']['fps'])
        review_context = self.review_context(p)
        for shot in candidates:
            if not shot.get('imagePath'):
                raise ValueError('Generate the pictures in this preview interval first.')
            if qc_decision(p, shot, self.store, review_context)['blocking'] or (
                p['settings'].get('qcCheckLevel') != 'off' and shot.get('qc', {}).get('status') == 'PENDING'):
                raise ValueError('Review or repair the selected preview pictures first; visual checks are preserved.')
        folder = self.store.folder(p['id']) / ch['id']
        folder.mkdir(exist_ok=True)
        identity = digest({'audio': self.asset_identity(p['id'], audio['path']), 'start': start, 'end': end})
        sliced = folder / ('preview-audio-opus-' + identity[:20] + '.opus')
        if not self.cached_asset(p['id'], sliced):
            self.run(['-ss', str(start), '-i', str(self.store.asset(p['id'], audio['path'])),
                      '-t', str(end-start), '-vn', '-c:a', 'libopus', '-b:a', '128k', str(sliced)],
                     gate, sliced.with_suffix('.log'))
            self.completed_output(sliced)
        preview_p, preview_c = copy.deepcopy(p), copy.deepcopy(ch)
        preview_p['settings']['qcCheckLevel'] = 'off'  # original shot decisions checked above
        preview_p['settings']['visionQC'] = False
        preview_c['audio'] = audio | {'path': sliced.relative_to(self.store.folder(p['id'])).as_posix(), 'duration': end-start}
        preview_c['render'] = {}
        preview_c['scenes'] = []
        for scene in ch['scenes']:
            selected_shots = []
            for shot in scene['shots']:
                if shot in candidates:
                    clipped = copy.deepcopy(shot)
                    clipped.update(start=max(start, shot['start'])-start, end=min(end, shot['end'])-start)
                    selected_shots.append(clipped)
            if selected_shots:
                preview_c['scenes'].append(scene | {'shots': selected_shots})
        result = self.chapter(preview_p, preview_c, gate)
        result = self.watermark_export(preview_p, result, gate)
        return result | {'downloadName': 'edit-preview.mp4', 'preview': True, 'chapterId': ch['id'],
            'shotId': shot_id, 'start': start, 'end': end,
            'note': 'Saved narration, pictures, motion and watermark only. Intro, outro and subscribe reminders are excluded. Cropped long shots restart their movement.'}

    def chapter_export(self, p, ch, gate):
        base = self.chapter(p, ch, gate)
        if not p["intro"]["enabled"] or p["intro"]["placement"] != "every_chapter":
            return self.engagement_export(p,base,gate,namespace=ch['id'])
        single = p | {
            "chapters": [ch],
            "intro": p["intro"] | {"placement": "full_story_only"},
        }
        result = self.full(single, gate, publication_project=p)
        return result | {
            "downloadName": base["downloadName"],
            "introDuration": self.intro_duration(p),
            "renderTimingScope": "chapter-with-intro",
            "narrationRender": base,
        }

    def intro(self, p, gate):
        path = self.raw_intro(p,gate)
        result = self.watermark_export(p,{'path':path.name,'duration':self.intro_duration(p)},gate)
        return self.store.asset(p['id'],result['path'])

    def intro_duration(self, p):
        """Keep the saved storyboard; remove only unvoiced time at its end."""
        intro = p['intro']
        planned = float(intro['duration'])
        if not math.isfinite(planned) or not 10 <= planned <= 30:
            raise ValueError('Intro duration must be 10–30 seconds.')
        if not intro.get('audioPath'):
            return planned
        text_digest = intro.get('audioTextDigest')
        if text_digest and text_digest != digest(intro.get('voiceText', '').strip()):
            raise ValueError('Intro narration text changed. Generate separate intro voice again before rendering; previous audio and video are retained.')
        spoken = probe_audio(self.store.asset(p['id'],intro['audioPath']),self.config.get('ffmpeg'))['duration']
        if spoken > planned + .02:
            raise ValueError(f'Intro narration lasts {spoken:.1f}s, longer than the {planned:g}s intro. Shorten its text or regenerate at a faster speaking speed; narration will not be cut off.')
        if intro.get('endOnNarration', True) is False:
            return planned
        fps = p['settings']['video']['fps']
        return min(planned, max(10.0, math.ceil((spoken + .25) * fps) / fps))

    def raw_intro(self, p, gate):
        intro = p["intro"]
        v = p["settings"]["video"]
        planned_duration = float(intro['duration'])
        duration = self.intro_duration(p)
        review_context = self.review_context(p)
        for index, shot in enumerate(intro.get('shots', [])):
            if p['settings'].get('qcCheckLevel')!='off' and shot.get('qc', {}).get('status') == 'PENDING':
                raise ValueError('Finish pending intro image quality checks before rendering.')
            if qc_decision(p,shot,self.store,review_context)['blocking']:
                raise ValueError(f'Intro shot {index+1} needs review. Accept it or request a repair before rendering.')
            if shot.get('imagePath') and not self.store.asset(p['id'], shot['imagePath']).is_file():
                raise ValueError(f'Generate intro shot {index+1} before rendering. No previous intro was replaced.')
        if intro.get('visualPath') and not self.store.asset(p['id'], intro['visualPath']).is_file():
            raise ValueError('Choose or generate the intro background before rendering. No previous intro was replaced.')
        signature = digest(
            {
                "introRendererVersion": 8,
                "effectiveDuration": duration,
                "audioIdentity": self.asset_identity(p['id'], intro.get('audioPath')) if intro.get('audioPath') else None,
                "visualIdentity": self.asset_identity(p['id'], intro.get('visualPath')) if intro.get('visualPath') else None,
                "shotImageIdentities": [self.asset_identity(p['id'], s['imagePath']) for s in intro.get('shots',[]) if s.get('imagePath')],
                "intro": {
                    k: ([{field:s.get(field) for field in ('imagePath','start','end','motion','motionSettings')}
                          for s in intro.get('shots',[])] if k=='shots' else intro.get(k))
                    for k in (
                        "duration",
                        "title",
                        "subtitle",
                        "visualPath",
                        "audioPath",
                        "motion",
                        "showTitle",
                        "shots",
                        "endOnNarration",
                    )
                },
                "video": v,
            }
        )
        folder = self.store.folder(p["id"])
        destination = folder / f"intro-{signature[:12]}.mp4"
        if self.cached_asset(p['id'], destination):
            return destination
        montage = None
        if intro.get('shots'):
            clips, lengths = [], []
            cursor = 0.0
            for index, shot in enumerate(intro['shots']):
                start, end = float(shot['start']), float(shot['end'])
                if not all(math.isfinite(x) for x in (start, end)) or abs(start-cursor) > .02 or end <= start or end > planned_duration+.02:
                    raise ValueError('Intro shots must cover its duration in order without gaps or overlaps.')
                image = self.store.asset(p['id'], shot.get('imagePath', ''))
                if not image.is_file():
                    raise ValueError(f'Generate intro shot {index+1} before rendering. No previous intro was replaced.')
                seconds = max(0, min(end, duration)-start)
                cursor = end
                if seconds <= 0:
                    continue
                visual_shot={key:shot.get(key) for key in ('imagePath','start','end','motion','motionSettings')}
                clip = folder / ('intro-shot-' + digest({'version': 4, 'shot': visual_shot, 'seconds':seconds, 'image':self.asset_identity(p['id'],shot['imagePath']), 'video': v})[:20] + '.mp4')
                if not self.cached_asset(p['id'], clip):
                    visual = self.motion(shot | {'manual': {'motion': True}}, v | {'imageFit': 'cover'}, round(seconds*v['fps']))
                    self.run(['-loop', '1', '-i', str(image), '-vf', visual, '-an', '-t', str(seconds), *self.encoding(p), str(clip)], gate, folder / f'intro-shot-{index+1}.log')
                clips.append(clip)
                lengths.append(seconds)
            if abs(cursor-planned_duration) > .02:
                raise ValueError('Intro shots must reach the end of the intro narration timeline.')
            montage = folder / ('intro-montage-' + signature[:12] + '.mp4')
            if not self.cached_asset(p['id'], montage):
                self.concat(clips, montage, gate, folder / 'intro-montage.log', lengths, video_only=True)
        title_filter = ''
        if intro.get('showTitle', False):
            title = folder / 'intro-title.txt'
            title.write_text(intro.get('title', '') + '\n' + intro.get('subtitle', ''), encoding='utf-8')
            textpath = str(title).replace('\\', '/').replace(':', '\\:').replace("'", "\\'")
            font = self.config.get('font', 'C:/Windows/Fonts/arial.ttf').replace('\\', '/').replace(':', '\\:')
            title_filter = f",drawtext=fontfile='{font}':textfile='{textpath}':fontcolor=white:fontsize=48:borderw=2:bordercolor=black:box=1:boxcolor=black@0.60:boxborderw=18:x=(w-text_w)/2:y=(h-text_h)/2"
        inputs = (
            ["-loop", "1", "-i", str(self.store.asset(p["id"], intro["visualPath"]))]
            if intro.get("visualPath")
            else [
                "-f",
                "lavfi",
                "-i",
                f"color=c=0x171c23:s={v['width']}x{v['height']}:r={v['fps']}",
            ]
        )
        if montage:
            inputs = ['-i', str(montage)]
        inputs += (
            ["-i", str(self.store.asset(p["id"], intro["audioPath"]))]
            if intro.get("audioPath")
            else ["-f", "lavfi", "-i", "anullsrc=r=24000:cl=mono"]
        )
        visual = self.motion({'start':0, 'end':duration, 'motion':intro.get('motion','static'),
            'camera':{'shot':'wide'}, 'manual':{'motion':True}}, v | {'imageFit':'cover'}, round(duration*v['fps']))
        if montage:
            visual = f"fps={v['fps']},setsar=1"
        filters = visual + title_filter + f",fade=t=in:st=0:d=0.5,fade=t=out:st={duration-.5}:d=0.5"
        self.run(
            [
                *inputs,
                "-vf",
                filters,
                "-map",
                "0:v",
                "-map",
                "1:a",
                "-af",
                "apad",
                "-t",
                str(duration),
                *self.encoding(p),
                "-c:a",
                "aac",
                "-b:a",
                "128k",
                "-ar",
                "24000",
                "-ac",
                "1",
                "-movflags",
                "+faststart",
                str(destination),
            ],
            gate,
            folder / "intro-render.log",
        )
        return destination

    @staticmethod
    def aligned_wave_format(paths, durations, fps):
        """A packet join needs one PCM format and chapter starts aligned within a frame."""
        if not paths or len(paths) != len(durations):
            return None
        lengths = {}
        formats = set()
        for path in dict.fromkeys(paths):
            if path is None or Path(path).suffix.lower() != '.wav':
                return None
            try:
                with wave.open(str(path), 'rb') as source:
                    rate = source.getframerate()
                    formats.add((rate, source.getnchannels(), source.getsampwidth(), source.getcomptype()))
                    lengths[path] = source.getnframes() / rate
            except (OSError, ValueError, wave.Error, EOFError):
                return None
        if len(formats) != 1:
            return None
        drift = 0.
        for path, seconds in zip(paths[:-1], durations):
            drift += lengths[path] - seconds
            if abs(drift) > 1 / fps:
                return None
        return formats.pop()

    @staticmethod
    def direct_full_mux_supported(video, sources, durations):
        """Only the media envelope with verified packet/pixel parity may skip remux."""
        if (video.get('width'),video.get('height'),video.get('fps'))!=(1280,720,30):return False
        if any(duration < .5 for duration in durations):return False
        return VideoRenderer.aligned_wave_format(sources, durations, 30) == (24000, 1, 2, 'NONE')

    @classmethod
    def direct_intro_mux_supported(cls, video, sources, durations):
        # The intro Opus is padded to the frame-rounded opening duration. Its
        # original WAV and the chapter WAVs must each match the verified format.
        return (len(sources)>1 and len(sources)==len(durations)
                and cls.direct_full_mux_supported(video,sources[:1],durations[:1])
                and cls.direct_full_mux_supported(video,sources[1:],durations[1:]))

    def full_mux_forecast(self, project):
        """Read local headers only; forecasting must never restore cloud assets."""
        result={'installedCapability':'direct-concat-original-audio-v1','eligibility':'unknown',
                'effectivePolicy':'legacy-two-pass-v1'}
        video=project['settings']['video']
        if (video.get('width'),video.get('height'),video.get('fps'))!=(1280,720,30):
            return result | {'eligibility':'unsupported'}
        entries=[(ch.get('audio',{}).get('path'),ch.get('audio',{}).get('duration'))
                 for ch in project.get('chapters',[]) if ch.get('sourceText','').strip()]
        intro=project.get('intro',{})
        if intro.get('enabled'):
            entries.insert(0,(intro.get('audioPath'),intro.get('duration')))
            if intro.get('placement')=='full_story_only':
                result['installedCapability']='direct-concat-intro-decoded-audio-v1'
        if not entries:return result
        sources=[];durations=[];missing=False
        for name,duration in entries:
            if not name or type(duration) not in (int,float) or not math.isfinite(duration):return result
            if Path(name).suffix.lower()!='.wav' or duration<.5:return result | {'eligibility':'unsupported'}
            try:path=self.store.asset_local(project['id'],name)
            except (ValueError,OSError):return result
            if not path.is_file():missing=True
            sources.append(path);durations.append(duration)
        if missing:return result
        if intro.get('enabled') and intro.get('placement')=='full_story_only' and self.direct_intro_mux_supported(video,sources,durations):
            return result | {'eligibility':'verified','effectivePolicy':'direct-concat-intro-decoded-audio-v1'}
        if not intro.get('enabled') and self.direct_full_mux_supported(video,sources,durations):
            return result | {'eligibility':'verified','effectivePolicy':'direct-concat-original-audio-v1'}
        return result | {'eligibility':'unsupported'}

    def narration_join(self, paths, durations, fps):
        """FFconcat copies the first input's codec parameters to all subsequent packets."""
        if len(paths) == 1:
            return 'original', None
        if self.aligned_wave_format(paths, durations, fps) is not None:
            return 'original', None
        unique = dict.fromkeys(paths)
        audio = {path: probe_audio(path, self.config.get('ffmpeg')) for path in unique}
        channels = max(info['channels'] for info in audio.values())
        if (all(path.suffix.lower() == '.opus' and info['channels'] == 1 for path, info in audio.items())
                and all(abs(audio[path]['duration'] - seconds) <= 1 / 48000
                        for path, seconds in zip(paths, durations))):
            # The default Opus container duration includes encoder pre-skip.
            # Set the decoded timeline explicitly so later chapters stay in time.
            return 'timed-opus', None
        return 'decoded', channels

    def full(self, p, gate, publication_project=None):
        files = []
        audios = []
        audio_sources = []
        chapter_rendered = False
        durations = []
        duration = 0

        def add_intro():
            nonlocal duration
            intro_seconds = self.intro_duration(p)
            visual = self.raw_intro(p, gate)
            files.append(visual)
            durations.append(intro_seconds)
            duration += intro_seconds
            audio = visual.with_suffix(".opus")
            if not audio.exists():
                inputs = (
                    ["-i", str(self.store.asset(p["id"], p["intro"]["audioPath"]))]
                    if p["intro"].get("audioPath")
                    else ["-f", "lavfi", "-i", "anullsrc=r=24000:cl=mono"]
                )
                self.run(
                    [
                        *inputs,
                        "-af",
                        "apad",
                        "-t",
                        str(intro_seconds),
                        "-c:a",
                        "libopus", "-b:a", "128k",
                        "-ar",
                        "24000",
                        "-ac",
                        "1",
                        str(audio),
                    ],
                    gate,
                    self.store.folder(p["id"]) / "intro-audio-render.log",
                )
            audios.append(audio)
            audio_sources.append(self.store.asset(p['id'],p['intro']['audioPath']) if p['intro'].get('audioPath') else None)

        if p["intro"]["enabled"] and p["intro"]["placement"] == "full_story_only":
            add_intro()
        for ch in p["chapters"]:
            if not ch["sourceText"].strip():
                continue
            from studio_render_inputs import render_submission_signature
            # Chapter parts and per-chapter intros deliberately derive settings
            # from the project. Guard the original inputs, not these overrides.
            requested_inputs=render_submission_signature(publication_project or p,self.store,self,ch['id'])
            result = self.chapter(p, ch, gate)
            if not result.get('reused'):
                chapter_rendered = True

            chapter_result = self.watermark_export(p,result,gate)
            def chapter_saved(latest):
                c = next((c for c in latest["chapters"] if c["id"] == ch["id"]),None)
                if c is None or render_submission_signature(latest,self.store,self,ch['id'])!=requested_inputs:
                    target=c if c is not None else latest
                    target.setdefault('renderHistory',[]).append(chapter_result | {'selected':False,
                        'chapterId':ch['id'],'reason':'Chapter changed during full-story assembly; current edits and selection retained.'})
                    target['renderStale']=True
                    latest['renderStale']=True
                    return False
                stale=bool(p["intro"]["enabled"] and p["intro"]["placement"]=="every_chapter")
                previous=c.get("render") or {}
                if result.get('reused') and c.get('renderStale')==stale and previous:
                    # Reusing a selected chapter during assembly preserves the
                    # original render timing and does not rewrite a large project.
                    provenance={'reused','renderTimingScope'}
                    if ({k:v for k,v in previous.items() if k not in provenance}==
                            {k:v for k,v in chapter_result.items() if k not in provenance}):
                        return UNCHANGED
                if (
                    c.get("render", {}).get("path")
                    and c["render"]["path"] != chapter_result["path"]
                ):
                    c.setdefault("renderHistory", []).append(c["render"])
                c.update(render=chapter_result, renderStale=stale)
                return True

            if not self.store.mutate(p["id"], chapter_saved):
                raise ValueError('Chapter changed during full-story assembly. The completed earlier version is saved; current edits and selected exports are retained.')
            if p["intro"]["enabled"] and p["intro"]["placement"] == "every_chapter":
                add_intro()
            files.append(self.store.asset(p["id"], result["path"]))
            audios.append(self.store.asset(p["id"], ch["audio"]["path"]))
            audio_sources.append(audios[-1])
            durations.append(result["duration"])
            duration += result["duration"]
        if not files:
            raise ValueError("Add and generate a chapter first.")
        audio_join, channels = self.narration_join(audios, durations, p['settings']['video']['fps'])
        identity = {
            "fullRendererVersion": 2,
            "files": [str(f.relative_to(self.store.folder(p["id"]))) for f in files],
            "video": p["settings"]["video"],
        }
        if audio_join != 'original':
            # Earlier exports can contain a missing or shifted last chapter.
            # Leave them accessible and build under a different content identity.
            identity.update(narrationJoin=audio_join, narrationDurations=durations)
        signature = digest(identity)
        target = self.store.folder(p["id"]) / f"story-{signature[:12]}.mp4"
        reused_full = self.cached_asset(p['id'], target)
        assembly_policy = 'format-guarded-original-audio-v1'
        timing_scope = 'fresh-assembly'
        if chapter_rendered:
            timing_scope = 'includes-chapter-render'
        elif p['intro']['enabled']:
            timing_scope = 'includes-intro'
        if not reused_full:
            # Join original chapter narration once. Copying separate chapter AAC tracks
            # can accumulate encoder padding at chapter boundaries.
            visual = target.with_name(target.stem + "-visual.mp4")
            log = self.store.folder(p["id"]) / "full-render.log"
            reuse_visual = self.cached_asset(p['id'], visual)
            if reuse_visual and timing_scope == 'fresh-assembly':
                timing_scope = 'reused-visual-assembly'
            video_settings=p['settings']['video']
            direct = audio_join == 'original' and self.direct_full_mux_supported(video_settings,audio_sources,durations)
            direct_intro=(audio_join=='decoded' and p['intro']['enabled'] and p['intro']['placement']=='full_story_only'
                          and self.direct_intro_mux_supported(video_settings,audio_sources,durations))
            if not reuse_visual and not (direct or direct_intro):
                self.concat(files,visual,gate,log,durations,video_only=True)
                reuse_visual = True
            if reuse_visual:
                assembly_policy = 'legacy-two-pass-v1'
                # Keep exact completed checkpoints from an interrupted older run.
                visual_input = ['-i',str(visual)]
                video_copy_options = []
                visual_bytes = visual.stat().st_size
            else:
                assembly_policy = 'direct-concat-intro-decoded-audio-v1' if direct_intro else 'direct-concat-original-audio-v1'
                # Copy chapter video packets and mux original narration together;
                # a new export need not write/read a second full silent video.
                video_listing = self.concat_listing(files,target.with_suffix('.video.txt'),durations)
                visual_input = ['-f','concat','-safe','0','-i',str(video_listing)]
                # Chapter AAC priming can shift concat's input start. The old
                # silent remux normalized video to its first presentation time.
                # Match that normalization without touching narration timing or
                # the PTS/DTS distance used by reordered video frames.
                video_copy_options = ['-bsf:v','setts=pts=PTS-STARTPTS:dts=DTS-STARTPTS']
                visual_bytes = sum(path.stat().st_size for path in files)
            narration_input = {}
            if audio_join == 'decoded':
                audio_input = ['-f', 'f32le', '-ar', '48000', '-ac', str(channels), '-i', 'pipe:0']
                narration_input['narration'] = (zip(audios, durations), channels)
            else:
                listing = self.concat_listing(audios, target.with_suffix('.audio.txt'),
                    durations if audio_join == 'timed-opus' else None)
                audio_input = ['-f', 'concat', '-safe', '0', '-i', str(listing)]
            temporary = target.with_suffix(".partial.mp4")
            self.require_output_space(temporary,visual_bytes,duration)
            self.run(
                [
                    *visual_input,
                    *audio_input,
                    "-map",
                    "0:v:0",
                    "-map",
                    "1:a:0",
                    "-c:v",
                    "copy",
                    *video_copy_options,
                    "-c:a",
                    "aac",
                    "-b:a",
                    "128k",
                    "-af",
                    "apad",
                    "-t",
                    str(duration),
                    "-movflags",
                    "+faststart",
                    str(temporary),
                ],
                gate,
                log,
                **narration_input,
            )
            temporary.replace(target)
            self.completed_output(target)
        return self.engagement_export(p,{
            "path": target.name,
            "duration": duration,
            "signature": signature,
            "downloadName": p["name"] + ".mp4",
            "created": time.time(),
            "settingsSnapshot": capture_video_settings(p),
            "fullAssemblyPolicy": assembly_policy,
            "narrationJoin": audio_join,
            "reused": reused_full,
            "renderTimingScope": "reused-base" if reused_full else timing_scope,
        },gate)

    def aac_splice_info(self, path):
        """Identify the fixed-frame AAC tracks that can be joined by packet copy."""
        sibling = Path(self.executable()).with_name('ffprobe.exe' if os.name == 'nt' else 'ffprobe')
        ffprobe = str(sibling) if sibling.is_file() else shutil.which('ffprobe')
        if not ffprobe:
            return None
        try:
            probe = subprocess.run([ffprobe, '-v', 'error', '-select_streams', 'a:0',
                '-read_intervals', '%+#1', '-show_packets', '-show_streams',
                '-show_entries', 'packet=dts,duration',
                '-show_data_hash', 'sha256', '-of', 'json', str(path)],
                capture_output=True, check=True, timeout=30,
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            data = json.loads(probe.stdout)
            stream, first = data['streams'][0], data['packets'][0]
            rate, channels = int(stream['sample_rate']), int(stream['channels'])
            duration = int(stream['duration_ts'])
            frame = AAC_LC_FRAME_SAMPLES
            frames = (duration + frame - 1) // frame
            if (stream['codec_name'] == 'aac' and stream['profile'] == 'LC' and
                    stream['start_pts'] == 0 and stream['time_base'] == f'1/{rate}' and
                    (channels, stream['channel_layout']) in ((1, 'mono'), (2, 'stereo')) and
                    first['dts'] == -frame and first['duration'] == frame and
                    frames > 0 and int(stream['nb_frames']) == frames + 1):
                return rate, channels, stream['extradata_hash'], frames
        except (OSError, subprocess.SubprocessError, ValueError, TypeError, KeyError, IndexError):
            pass
        return None

    def join_engagement_outro(self, decorated, outro, audio, target, duration, outro_duration, story_aac, gate):
        input_bytes = decorated.stat().st_size + outro.stat().st_size
        outro_aac = self.aac_splice_info(outro) if story_aac else None
        if outro_aac and outro_aac[:3] == story_aac[:3]:
            rate, _, _, frames = story_aac
            frame = AAC_LC_FRAME_SAMPLES
            # The MP4 duration can end inside the last AAC packet. Keep the
            # full packet and place the new track's priming packet after it.
            join = max(frames + 1, math.ceil(duration * rate / frame)) * frame / rate
            if abs(join - duration) <= 2 * frame / rate:
                self.require_output_space(target, input_bytes)
                listing = self.concat_listing([decorated, outro], target.with_suffix('.concat.txt'),
                                              [join, outro_duration])
                self.run(['-xerror', '-copyts', '-f', 'concat', '-safe', '0', '-i', str(listing),
                          '-map', '0:v:0', '-map', '0:a:0', '-c', 'copy',
                          '-avoid_negative_ts', 'disabled', '-movflags', '+faststart', str(target)],
                         gate, target.with_suffix('.log'))
                return
        # Other codecs, layouts and timestamp conventions need one continuous
        # audio encode. Decode both originals and retain all their samples.
        self.require_output_space(target, input_bytes, duration + outro_duration)
        listing = self.concat_listing([decorated, outro], target.with_suffix('.concat.txt'),
                                      [duration, outro_duration])
        graph = ';'.join(
            f'[{index}:a:0]aresample=48000,apad=whole_len={round(length * 48000)},asetpts=N/SR/TB[{label}]'
            for index, length, label in ((1, duration, 'story'), (2, outro_duration, 'ending'))
        ) + ';[story][ending]concat=n=2:v=0:a=1[a]'
        self.run(['-xerror', '-copyts', '-f', 'concat', '-safe', '0', '-i', str(listing),
                  '-i', str(decorated), '-i', str(audio), '-filter_complex', graph,
                  '-map', '0:v:0', '-map', '[a]', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '128k',
                  '-avoid_negative_ts', 'disabled', '-movflags', '+faststart', str(target)],
                 gate, target.with_suffix('.log'))

    def engagement_export(self, p, result, gate, namespace='full'):
        from studio_engagement import settings, schedule, card, ding, audio_signature
        s=settings(p)
        if s['outroEnabled'] and callable(getattr(self,'prepare_outro',None)):
            self.prepare_outro(p); s=settings(p)
        events=schedule(p,result['duration'],namespace)
        if (result.get('renderTimingScope') in ('fresh-chapter','fresh-assembly') and
                (events or s['outroEnabled'] or s['splitEnabled'] or p['settings'].get('watermark',{}).get('enabled'))):
            result = result | {'renderTimingScope':'includes-export-effects'}
        if not events and not s['outroEnabled']:
            final=self.watermark_export(p,result,gate) | {'exportDestination':s['exportDestination']}
            if s['splitEnabled']:final=final|{'parts':self.export_parts(p,final,gate,s,namespace)}
            return final
        from studio_branding import identity as branding_identity, bitmap, coordinates
        branding=branding_identity(p,self.store)
        brand=branding.get('enabled',True) and result.get('watermarkIdentity')!=branding
        folder=self.store.folder(p['id']); source=self.store.asset(p['id'],result['path'])
        identity={'version':2,'source':self.asset_identity(p['id'],result['path']),
                  'settings':s,'events':events,'video':p['settings']['video'],'namespace':namespace,'branding':branding}
        if s['outroEnabled']:
            if not s['outroAudioPath'] or s['outroAudioSignature']!=audio_signature(p):
                raise ValueError('Prepare the updated outro narration before rendering. Chapter audio is unchanged.')
            audio=self.store.asset(p['id'],s['outroAudioPath'])
            identity['outroAudio']=self.asset_identity(p['id'],s['outroAudioPath'])
        signature=digest(identity); duration=result['duration']
        decorated=source
        if events:
            decorated=folder/f'reminders-{signature[:20]}.mp4'
            if not self.cached_asset(p['id'], decorated):
                logo=decorated.with_suffix('.png'); card(p,logo)
                inputs=['-i',str(source),'-i',str(logo)]
                enabled='+'.join(f'between(t,{e["start"]},{e["end"]})' for e in events)
                x='main_w-overlay_w-24' if s['position']=='bottom-right' else '24'
                filters=[f"[0:v][1:v]overlay=x={x}:y=main_h-overlay_h-24:eof_action=repeat:enable='{enabled}'[{ 'reminded' if brand else 'v' }]"]
                next_input=2
                if brand:
                    mark=decorated.with_name(decorated.stem+'-watermark.png');bitmap(p,self.store,mark);bx,by=coordinates(p)
                    inputs+=['-i',str(mark)];next_input+=1
                    filters.append(f'[reminded][2:v]overlay=x={bx}:y={by}:eof_action=repeat:format=auto[v]')
                audio_map='0:a:0'
                if s['dingEnabled'] and s['dingVolume']>0:
                    bell=decorated.with_suffix('.opus'); ding(bell,s['dingVolume'],self.executable()); inputs+=['-i',str(bell)]
                    filters.append(f'[{next_input}:a]asplit='+str(len(events))+''.join(f'[bell{i}]' for i in range(len(events))))
                    segments=[]; cursor=0
                    for i,e in enumerate(events):
                        gap=max(0,e['start']-cursor)
                        filters += [f'anullsrc=r=24000:cl=mono:d={gap}[sil{i}]',
                                    f'[bell{i}]atrim=duration=0.6,asetpts=PTS-STARTPTS[tone{i}]']
                        segments += [f'[sil{i}]',f'[tone{i}]']; cursor=e['start']+.6
                    filters.append(f'anullsrc=r=24000:cl=mono:d={max(0,duration-cursor)}[tail]')
                    segments.append('[tail]')
                    filters.append(''.join(segments)+f'concat=n={len(segments)}:v=0:a=1[chimes]')
                    filters.append('[0:a][chimes]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.95:level=0[a]')
                    audio_map='[a]'
                graph=decorated.with_suffix('.filters.txt'); graph.write_text(';'.join(filters),encoding='utf-8')
                self.require_output_space(decorated,source.stat().st_size*2,duration)
                self.run([*inputs,'-filter_complex_threads','1','-filter_complex_script',str(graph),
                    '-map','[v]','-map',audio_map,*self.encoding(p),'-c:a','aac','-b:a','128k',
                    '-t',str(duration),'-movflags','+faststart',str(decorated)],gate,decorated.with_suffix('.log'))
        elif brand:
            decorated=self.store.asset(p['id'],self.watermark_export(p,result,gate)['path'])
        target=decorated
        if s['outroEnabled']:
            legacy_outro=folder/f'outro-{signature[:20]}.mp4'
            identity=identity | {'outroMuxVersion':1}
            signature=digest(identity)
            spoken=probe_audio(audio,self.executable())['duration']
            outro_duration=max(s['outroDuration'],spoken+.5)
            target=folder/f'complete-{signature[:20]}.mp4'
            if not self.cached_asset(p['id'], target):
                story_aac=self.aac_splice_info(decorated)
                outro=folder/f'outro-{signature[:20]}.mp4'
                if not self.cached_asset(p['id'], outro):
                    audio_index=1
                    if self.cached_asset(p['id'], legacy_outro):
                        inputs=['-i',str(legacy_outro)]
                        video_options=['-map','0:v:0','-c:v','copy']
                    else:
                        visual=outro.with_suffix('.png');card(p,visual,outro=True)
                        inputs=['-loop','1','-i',str(visual)]
                        video_options=['-map','0:v:0',*self.encoding(p)]
                        if branding.get('enabled',True):
                            mark=outro.with_name(outro.stem+'-watermark.png');bitmap(p,self.store,mark);bx,by=coordinates(p)
                            inputs+=['-i',str(mark)]
                            audio_index=2
                            video_options=['-filter_complex_threads','1','-filter_complex',
                                           f'[0:v][1:v]overlay=x={bx}:y={by}:eof_action=repeat:format=auto[v]',
                                           '-map','[v]',*self.encoding(p)]
                    audio_options=['-an']
                    if story_aac:
                        rate, channels, _, _=story_aac
                        inputs+=['-i',str(audio)]
                        audio_options=['-map',f'{audio_index}:a:0','-af','apad','-c:a','aac','-profile:a','aac_low',
                                       '-b:a','128k','-ar',str(rate),'-ac',str(channels)]
                    self.run([*inputs,*video_options,*audio_options,'-t',str(outro_duration),
                              '-movflags','+faststart',str(outro)],gate,outro.with_suffix('.log'))
                self.join_engagement_outro(decorated,outro,audio,target,duration,outro_duration,story_aac,gate)
            duration+=outro_duration
        final=result | {'path':target.name,'duration':duration,'signature':signature,
                         'engagementEvents':events,'engagementIdentity':identity,'narrationRender':result,'watermarkIdentity':branding,
                         'exportDestination':s['exportDestination']}
        if s['splitEnabled']:
            final['parts']=self.export_parts(p,final,gate,s,namespace)
        return final

    def export_parts(self,p,result,gate,s,namespace='full'):
        if s['splitMode']=='chapters':
            return self.split_chapters(p,gate,s['chaptersPerPart']) if namespace=='full' else []
        return self.split_export(p,result,gate,s['partMinutes'])

    def split_chapters(self,p,gate,chapters_per_part=1):
        """Assemble complete chapters; never cut narration at approximate keyframes.

        Reuses cached shot/chapter footage. Each part receives the selected
        destination's ending. A full-story-only intro belongs to the first part.
        """
        if isinstance(chapters_per_part,bool) or not isinstance(chapters_per_part,int) or chapters_per_part<1:
            raise ValueError('Chapters per part must be a positive whole number.')
        chapters=[ch for ch in p['chapters'] if ch['sourceText'].strip()]
        if not chapters:raise ValueError('Add and generate a chapter first.')
        parts=[];cursor=0
        for offset in range(0,len(chapters),chapters_per_part):
            gate('Assembling chapter-aligned part')
            partial=copy.deepcopy(p)
            group=chapters[offset:offset+chapters_per_part]
            partial['chapters']=copy.deepcopy(group)
            partial['settings'].setdefault('engagement',{})['splitEnabled']=False
            if offset and partial['intro']['placement']=='full_story_only':
                partial['intro']['enabled']=False
            result=self.full(partial,gate,publication_project=p)
            end=cursor+result['duration']
            parts.append(result | {'number':len(parts)+1,'start':cursor,'end':end,
                'chapterIds':[ch['id'] for ch in group], 'chapterNames':[ch['name'] for ch in group],
                'chapterAligned':True,'keyframeAligned':True,
                'downloadName':f'{p["name"]}-{result["exportDestination"]}-part-{len(parts)+1:02d}.mp4'})
            cursor=end
        return parts

    def split_export(self,p,result,gate,minutes):
        """Keyframe-aware stream-copy parts: no new image/director/audio calls."""
        source=self.store.asset(p['id'],result['path']); length=float(minutes)*60
        signature=digest({'source':self.asset_identity(p['id'],result['path']),'minutes':minutes,'version':1})
        folder=self.store.folder(p['id'])/('parts-'+signature[:16]); folder.mkdir(exist_ok=True)
        receipt=folder/'parts.json'
        if self.cached_asset(p['id'], receipt):
            saved=json.loads(receipt.read_text(encoding='utf-8'))
            if all(self.store.asset(p['id'],x['path']).is_file() for x in saved): return saved
        # FFmpeg segment muxer chooses existing keyframes near the requested time.
        # Report measured boundaries, not an exact two-hour promise.
        staging=folder/'working'; staging.mkdir(exist_ok=True)
        pattern=staging/'part-%03d.mp4'; listing=staging/'segments.csv'
        self.require_output_space(folder/'parts.json',source.stat().st_size)
        self.run(['-i',str(source),'-map','0','-c','copy','-f','segment','-segment_time',str(length),
            '-reset_timestamps','1','-segment_list',str(listing),'-segment_list_type','csv',str(pattern)],gate,folder/'split.log',multiple_outputs=True)
        import csv
        parts=[]
        for i,row in enumerate(csv.reader(listing.read_text(encoding='utf-8').splitlines()),1):
            file=folder/Path(row[0]).name
            (staging/file.name).replace(file)
            self.completed_output(file)
            parts.append({'number':i,'path':file.relative_to(self.store.folder(p['id'])).as_posix(),
                'start':float(row[1]),'end':float(row[2]),'duration':float(row[2])-float(row[1]),
                'downloadName':f'{p["name"]}-part-{i:02d}.mp4','keyframeAligned':True})
        temp=receipt.with_suffix('.tmp'); temp.write_text(json.dumps(parts),encoding='utf-8'); temp.replace(receipt)
        self.completed_output(receipt)
        return parts
