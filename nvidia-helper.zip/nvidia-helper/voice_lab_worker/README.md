# QuestionTemplate private Voice Lab worker

This worker implements auditions of **Fish Audio Drama 3**, **VoxCPM2**, and
**Qwen3-TTS 1.7B Base + VoiceDesign**. It does not provision, start, stop, or change
RunPod resources. The owner's controller must enforce the authorized total spend
and stop the exact voice pod at its deadline. Releasing model memory does not stop
GPU billing. No anonymous inference endpoint is exposed.

## Preparation and storage

Use an official RunPod PyTorch/Ubuntu base selected from the current catalog.
Preparation can run on a CPU pod mounting the same network volume, in the same
data center, before any GPU is rented. The service requires Linux, Python 3.11,
`uv`, `git`, `ffmpeg`, and `ffprobe`; install these from the base image's official
repositories. The model environments are independent because current Drama3
SGLang-Omni pins a different Torch/Transformers stack than Qwen.

Copy this directory to the persistent volume. For example:

```sh
export QT_LAB_ROOT=/workspace/questiontemplate-voice-lab
python3 /workspace/voice_lab_worker/prepare.py --root "$QT_LAB_ROOT" --model all
```

`prepare.py` explicitly downloads pinned snapshots and installs pinned upstream
source commits. It writes preparation receipts and exact `uv pip freeze` outputs
under `prepared/`. These receipts state `inferenceVerified: false`; a successful
installation is not a passed inference test. `--model drama3`, `voxcpm2`, or
`qwen3` can prepare one model at a time. Downloads resume at the same paths.
Managed Python interpreters also live on the volume, so the environments do not
depend on the CPU setup pod's ephemeral interpreter. The wheel cache is on that
same filesystem and uses hard links to avoid a second full copy of package data.
No model is downloaded by the HTTP inference service, which starts with Hub and
Transformers offline modes.

The four full checkpoint directories total approximately **55.53 decimal GB**,
from the primary repositories' current file metadata. Drama3 also requires the
official pinned S2-Pro **codec file only**, not the S2-Pro language model. Runtime
environments, package caches, CUDA caches and outputs require additional disk.
The setup script requires at least 90 decimal GB free for a fresh all-model
preparation as a safety margin; this is not a measured installation footprint.
A 100 GB volume is an initial planning choice, subject to actual free-space
checks. Do not silently resize a paid volume if the installation does not fit.

Preparation needs network access and may need private Hub access if a license
gate is added upstream. Credentials belong only in the owner's private runtime
environment. Never put an API credential into this directory, a website bundle,
a command-line argument, a Git commit, or an output report.

## Start the private service

Create a random bearer token in a private file, mode 0600, and copy that token
privately to the paired helper's `voiceLabWorkerTokenFile`. Start the worker:

```sh
umask 077
python3 /workspace/voice_lab_worker/service.py \
  --root /workspace/questiontemplate-voice-lab \
  --token-file /workspace/private/voice-lab-token \
  --hourly-usd ACTUAL_QUOTED_GPU_RATE
```

Replace `ACTUAL_QUOTED_GPU_RATE` with the rate from the exact pod creation
receipt. Omit the entire rate option when unknown. Do not treat a catalog's
minimum or a different GPU's rate as this pod's measured rate.

The service listens on **127.0.0.1:18765 only**. Use an SSH local tunnel from the
owner's computer, for example `-L 18765:127.0.0.1:18765`, using the existing private
SSH identity. Set the helper's `voiceLabWorkerURL` to
`http://127.0.0.1:18765`. Do not expose port 18765 or the internal Drama3 port
18767 through a public pod proxy. The website sends requests through its paired
local helper, which holds the worker token server-side.

Keep the service and tunnel under the owner's process supervisor. The worker
does not stop its paid pod when the website closes. A bounded, independent
provider watchdog must stop compute even if this service, browser or tunnel
fails. Retained disk continues billing after compute stops.

## API contract

Every endpoint requires `Authorization: Bearer <private token>`.

- `GET /health`: service availability, per-model preparation status, resident
  model, immutable checkpoint revisions, actual configured hourly rate.
- `POST /jobs`: durable, asynchronous acceptance. Body keys: `id`, `model`,
  `mode`, `text`, `language`, `description`, `parameters`, and optional
  `reference:{audioBase64,mime,transcript}`. IDs must have 8–80 ASCII letters,
  digits, underscores or hyphens. Repeating an identical ID and input returns
  the existing job. Reusing an ID for changed input returns 409.
- `GET /jobs/<id>`: `queued`, `running`, `completed`, `failed`, or `cancelled`.
  Completed jobs include timing and audio-duration metrics.
- `GET /jobs/<id>/audio`: canonical PCM16 WAV for a completed job. The helper
  converts this transport artifact to the existing stored Opus128 preview.
- `POST /jobs/<id>/cancel`: cancels a queued job or kills the active model
  process group. A late completion cannot undo an acknowledged cancellation.

The queue admits at most eight unfinished auditions. Accepted input is stored
in a private SQLite WAL database. A worker restart resumes queued jobs; it marks
an interrupted running job failed and asks the owner to review partial output.
It never automatically resubmits that job or blindly retries a request.

## Actual model behavior

| ID | Modes | Behavior |
| --- | --- | --- |
| `drama3` | `default`, `clone` | Official SGLang-Omni `POST /v1/audio/speech`, full `fishaudio/drama-3` checkpoint. FP8 MoE experts/BF16 remainder are upstream's actual checkpoint precision. No int4 substitution. Clone needs a reference plus accurate transcript. Sampling controls are temperature, top-p, and top-k. Emotion/event tags belong in the input text. |
| `voxcpm2` | `default`, `design`, `clone` | Official `VoxCPM.from_pretrained` and `generate`. Voice description is prepended in parentheses as upstream documents. Clone with transcript uses prompt continuation; without transcript uses `reference_wav_path`. Controls: guidance scale, diffusion steps, seed. |
| `qwen3` | `design`, `clone` | Official `Qwen3TTSModel.generate_voice_design` with the VoiceDesign checkpoint, or `create_voice_clone_prompt` + `generate_voice_clone` with Base. BF16/SDPA baseline. Seed is controlled; model sampling defaults otherwise stay intact. No CustomVoice substitution. |

Qwen language selection supports English, Chinese, Japanese, Korean, German,
French, Russian, Portuguese, Spanish, Italian and Auto. Drama3 and VoxCPM2 infer
language from input text in this initial adapter. A drop-down's presence is not
a native-speaker quality verdict. Audition ranges are deliberate service limits,
not claims about the models' complete native parameter ranges.

The current baseline disables VoxCPM `torch.compile` (`optimize=False`) to avoid
an initial compile delay, and disables automatic bad-case retries so costs are
bounded and failures stay visible. These choices must be retained in benchmark
records. Qwen uses the official SDPA implementation to avoid an additional
FlashAttention source build. Drama3 limits its scheduler/CUDA-graph batch size
to one for sequential auditions. These are audition settings, not a throughput
optimization claim.

Reference uploads are limited to 10 MiB and decoded with FFmpeg. The worker
requires 0.25–60 seconds, canonicalizes references to mono 16 kHz PCM, and caches
them by content hash. Qwen caches up to 16 clone-conditioning prompts while its
Base model stays resident. Reference changes produce different cache keys.
References, payloads, outputs, and diagnostic logs stay private on the volume.
Only use recordings you are authorized to clone.

One model process stays resident for repeated auditions. Switching families
terminates the old process to release VRAM. Switching Qwen modes replaces its
loaded checkpoint. Persistent model/env/CUDA caches avoid redownloading and
reinstalling after a pod restart; they do not eliminate GPU allocation, image
pull, model loading, or graph warmup. An idle model is unloaded after 15 minutes,
but that is not a billing shutdown.

## Honest 30-second cost measurement

Use the same approximately 30-second script for each model and record the actual
output duration. The models stop on their own end marker; no audio is cut to
force a 30-second score. Record startup cold and a second warm run separately.

The worker records `loadSeconds`, `referenceDecodeSeconds`, `conditioningSeconds`,
`generationSeconds`, `audioSeconds`, and `workerWallSeconds`. `startupSeconds`
stays **null** until the owner's provider lifecycle measurement supplies it;
`loadSeconds` records model loading within this worker. `generationSeconds` includes
conditioning; the conditioning field is a subset, not an extra amount to add.
There is no first-audio latency metric because this audition API returns the
completed artifact.

When the exact quoted rate is supplied, the worker calculates
`workerEstimatedUSD = workerWallSeconds × hourlyUSD / 3600`. That figure excludes
provider startup, image pull, package/model downloads, idle time and disk. To
answer the user's all-in cold-start question, add those measured lifecycle
intervals from the owner's provider receipts exactly once and include storage
separately. A measured rate-normalized 30-second audio estimate is
`warm cost × 30 / actual audio seconds`; label it calculated, not measured
30-second output. Do not present provider marketing benchmarks as local results.

## Verification

CPU-only tests use fake inference while exercising real HTTP authentication,
persistent job recovery, duplicate protection, cancellation races and accounting:

```sh
cd /workspace/voice_lab_worker
python3 -m unittest -v test_worker.py
```

Passing these tests does not verify GPU inference. Before marking any model
working, run a real authenticated request, fetch and decode its output, listen
to it, inspect actual duration, and save a redacted timing/cost receipt. Check
the exact model's current license before monetized or self-service release.
This private audition worker does not imply a commercial-license approval.

Primary implementation references:

- [Drama3 official SGLang-Omni cookbook](https://github.com/sgl-project/sglang-omni/blob/65868af0592a852459aa31a6be7ae742c7756841/docs/cookbook/fishaudio_drama3.md)
- [VoxCPM official API](https://github.com/OpenBMB/VoxCPM/blob/cce58a5b59303c9bd63d12f23afe6a49a4a80c59/src/voxcpm/core.py)
- [Qwen3-TTS official API](https://github.com/QwenLM/Qwen3-TTS/blob/022e286b98fbec7e1e916cb940cdf532cd9f488e/qwen_tts/inference/qwen3_tts_model.py)
