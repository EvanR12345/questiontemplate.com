"""Full-story one-pass mux keeps media timing and resumable output guards."""
import copy,hashlib,json,math,os,shutil,struct,subprocess,tempfile,unittest,wave
from pathlib import Path
from unittest.mock import patch
from studio_data import ProjectStore,new_project,new_chapter,digest
from studio_render import VideoRenderer


class PreparedChapters(VideoRenderer):
    def __init__(self,*args):super().__init__(*args);self.calls=[]
    def chapter(self,p,ch,gate):
        return {'path':f'chapter-{ch["number"]}.mp4','duration':ch['audio']['duration'],'signature':str(ch['number'])}
    def run(self,args,gate,log,multiple_outputs=False,*,narration=None):
        self.calls.append(list(args))
        return super().run(args,gate,log,multiple_outputs,narration=narration)


def fixture(root,ffmpeg=None,fps=30,audio_rate=24000):
    store=ProjectStore(root);p=new_project('Mux fixture')
    p['chapters']=[new_chapter(1),new_chapter(2)]
    p['settings']['video'].update(width=1280,height=720,fps=fps,motionMode='static')
    p['settings']['watermark']={'enabled':False}
    p['settings']['engagement'].update(popupEnabled=False,outroEnabled=False,splitEnabled=False)
    p['intro']['enabled']=False
    folder=store.folder(p['id']);folder.mkdir()
    for i,ch in enumerate(p['chapters'],1):
        ch.update(sourceText='Fixture narration.',cleanNarrationText='Fixture narration.',scenes=[],
                  audio={'path':f'audio-{i}.wav','duration':.6})
        with wave.open(str(folder/ch['audio']['path']),'wb') as wav:
            wav.setparams((1,2,audio_rate,0,'NONE','not compressed'))
            wav.writeframes(b''.join(struct.pack('<h',int(3000*math.sin(2*math.pi*(300+i*130)*n/audio_rate))) for n in range(round(.6*audio_rate))))
        video=folder/f'chapter-{i}.mp4'
        if ffmpeg:
            subprocess.run([ffmpeg,'-hide_banner','-v','error','-nostdin','-y',
                '-f','lavfi','-i',f'color=c={"red" if i==1 else "blue"}:s=1280x720:r={fps}',
                '-i',str(folder/ch['audio']['path']),'-t','0.6','-c:v','libx264','-preset','veryfast',
                '-crf','21','-threads','1','-bf','2','-c:a','aac','-b:a','128k',str(video)],check=True,capture_output=True,timeout=30)
        else:video.write_bytes(b'completed chapter '+bytes([i]))
    p=store.save(p)
    return store,p,PreparedChapters(store,{'ffmpeg':ffmpeg or ''})


def story_path(store,p):
    name=digest({'fullRendererVersion':2,'files':[f'chapter-{c["number"]}.mp4' for c in p['chapters']],
                 'video':p['settings']['video']})[:12]
    return store.folder(p['id'])/f'story-{name}.mp4'


class FullMuxCommandTest(unittest.TestCase):
    @staticmethod
    def encoded(args,*_):Path(args[-1]).write_bytes(b'completed story')

    def test_fresh_assembly_is_one_atomic_video_copy_and_keeps_duration_overrides(self):
        with tempfile.TemporaryDirectory() as root:
            store,p,renderer=fixture(root)
            p['chapters'][0]['audio']['duration']=.617;p=store.save(p)
            with patch.object(renderer,'run',side_effect=self.encoded) as run:
                result=renderer.full(p,lambda *_:None)
            self.assertEqual(run.call_count,1)
            args=run.call_args.args[0]
            self.assertEqual(args[:4],['-f','concat','-safe','0'])
            self.assertEqual(args[args.index('-c:v')+1],'copy')
            self.assertEqual(args[args.index('-bsf:v')+1],'setts=pts=PTS-STARTPTS:dts=DTS-STARTPTS')
            self.assertEqual(args[args.index('-t')+1],'1.217')
            self.assertIn('duration 0.617',Path(args[5]).read_text())
            self.assertFalse(list(store.folder(p['id']).glob('*-visual.mp4')))
            self.assertTrue(store.asset(p['id'],result['path']).is_file())
            self.assertEqual(result['fullAssemblyPolicy'],'direct-concat-original-audio-v1')
            self.assertFalse(result['reused'])
            with patch.object(renderer,'run') as repeat:
                reused=renderer.full(store.load(p['id']),lambda *_:None)
            repeat.assert_not_called()
            self.assertTrue(reused['reused'])
            self.assertEqual(reused['fullAssemblyPolicy'],'format-guarded-original-audio-v1')

    def test_completed_legacy_silent_checkpoint_is_reused_without_retimestamping(self):
        with tempfile.TemporaryDirectory() as root:
            store,p,renderer=fixture(root);target=story_path(store,p)
            visual=target.with_name(target.stem+'-visual.mp4');visual.write_bytes(b'completed silent checkpoint')
            with patch.object(renderer,'run',side_effect=self.encoded) as run:
                result=renderer.full(p,lambda *_:None)
            args=run.call_args.args[0]
            self.assertEqual(args[:2],['-i',str(visual)])
            self.assertNotIn('-bsf:v',args)
            self.assertEqual(visual.read_bytes(),b'completed silent checkpoint')
            self.assertEqual(result['fullAssemblyPolicy'],'legacy-two-pass-v1')

    def test_forecast_uses_only_local_headers_and_never_fetches_unknown_assets(self):
        with tempfile.TemporaryDirectory() as root:
            store,p,renderer=fixture(root)
            with patch.object(store,'asset',side_effect=AssertionError('Forecast must not fetch')):
                self.assertEqual(renderer.full_mux_forecast(p)['eligibility'],'verified')
                p['intro'].update(enabled=True,audioPath='missing-intro.wav')
                unknown=renderer.full_mux_forecast(p)
                self.assertEqual(unknown['eligibility'],'unknown')
                self.assertEqual(unknown['effectivePolicy'],'legacy-two-pass-v1')
                p['intro']['audioPath']='intro.opus'
                self.assertEqual(renderer.full_mux_forecast(p)['eligibility'],'unsupported')
                p['intro']['enabled']=False;p['settings']['video']['fps']=60
                self.assertEqual(renderer.full_mux_forecast(p)['eligibility'],'unsupported')

    def test_cumulative_pcm_boundary_drift_selects_decoded_join_and_updates_forecast(self):
        with tempfile.TemporaryDirectory() as root:
            store, p, renderer = fixture(root)
            folder = store.folder(p['id'])
            paths = [folder / ch['audio']['path'] for ch in p['chapters']] * 6
            durations = [.625] * len(paths)
            self.assertEqual(renderer.narration_join(paths, durations, 30), ('decoded', 1))
            self.assertFalse(renderer.direct_full_mux_supported(p['settings']['video'], paths, durations))
            self.assertEqual(renderer.narration_join(paths[:2], [.617, .617], 30), ('original', None))

    def test_failed_fresh_mux_keeps_chapters_and_does_not_publish_complete_story(self):
        with tempfile.TemporaryDirectory() as root:
            store,p,renderer=fixture(root)
            original={f.name:f.read_bytes() for f in store.folder(p['id']).glob('chapter-*.mp4')}
            with patch.object(renderer,'run',side_effect=RuntimeError('cancelled')):
                with self.assertRaisesRegex(RuntimeError,'cancelled'):renderer.full(p,lambda *_:None)
            self.assertFalse(story_path(store,p).exists())
            self.assertFalse(list(store.folder(p['id']).glob('*-visual.mp4')))
            self.assertEqual(original,{f.name:f.read_bytes() for f in store.folder(p['id']).glob('chapter-*.mp4')})

    def test_unproven_pcm_rate_retains_original_two_pass_mux(self):
        with tempfile.TemporaryDirectory() as root:
            store,p,renderer=fixture(root,audio_rate=16000)
            with patch.object(renderer,'run',side_effect=self.encoded) as run:
                renderer.full(p,lambda *_:None)
            self.assertEqual(run.call_count,2)
            final_args=run.call_args.args[0]
            self.assertEqual(final_args[0],'-i')
            self.assertTrue(final_args[1].endswith('-visual.mp4'))
            self.assertNotIn('-bsf:v',final_args)


@unittest.skipUnless(os.environ.get('STUDIO_TEST_FFMPEG'),'Set STUDIO_TEST_FFMPEG for real media verification')
class FullMuxMediaTest(unittest.TestCase):
    @staticmethod
    def as_opus(folder, chapter, ffmpeg):
        source = folder / chapter['audio']['path']
        target = source.with_suffix('.opus')
        subprocess.run([ffmpeg, '-v', 'error', '-y', '-i', str(source), '-c:a', 'libopus',
                        '-b:a', '128k', str(target)], check=True, capture_output=True, timeout=30)
        chapter['audio']['path'] = target.name

    def assert_chapter_tones(self, path, duration, tones):
        ffmpeg = os.environ['STUDIO_TEST_FFMPEG']
        raw = subprocess.check_output([ffmpeg, '-v', 'error', '-i', str(path), '-map', '0:a:0',
                                       '-ar', '24000', '-ac', '1', '-f', 's16le', '-'], timeout=30)
        # AAC may expose one extra output packet of decoder padding.
        self.assertAlmostEqual(len(raw) / 48000, duration, delta=.05)
        for offset, hz in tones:
            start = round(offset * 24000) * 2
            samples = [x for (x,) in struct.iter_unpack('<h', raw[start:start + 4800])]
            self.assertEqual(len(samples), 2400)
            angle = math.tau * hz / 24000
            real = sum(x * math.cos(i * angle) for i, x in enumerate(samples))
            imag = sum(x * math.sin(i * angle) for i, x in enumerate(samples))
            self.assertGreater(2 * math.hypot(real, imag) / len(samples), 2000, (offset, hz))

    def test_mixed_saved_audio_preserves_later_chapters_and_supersedes_bad_cache(self):
        ffmpeg = os.environ['STUDIO_TEST_FFMPEG']
        for opus_index in (0, 1):
            with self.subTest(opusChapter=opus_index), tempfile.TemporaryDirectory() as root:
                store, p, renderer = fixture(root, ffmpeg)
                folder = store.folder(p['id'])
                self.as_opus(folder, p['chapters'][opus_index], ffmpeg)
                p = store.save(p)
                sources = {path: path.read_bytes() for path in folder.iterdir()
                           if path.suffix in ('.wav', '.opus')}
                previous = story_path(store, p)
                previous.write_bytes(b'preserved previous export')
                result = renderer.full(p, lambda *_: None)
                final = store.asset(p['id'], result['path'])
                self.assertNotEqual(previous, final)
                self.assertEqual(previous.read_bytes(), b'preserved previous export')
                self.assert_chapter_tones(final, 1.2, [(.2, 430), (.8, 560)])
                self.assertTrue(all(path.read_bytes() == before for path, before in sources.items()))
                with patch.object(renderer, 'run') as encoder:
                    repeat = renderer.full(store.load(p['id']), lambda *_: None)
                encoder.assert_not_called()
                self.assertTrue(repeat['reused'])

    def test_real_opus_intro_preserves_following_legacy_wav_chapters(self):
        ffmpeg = os.environ['STUDIO_TEST_FFMPEG']
        with tempfile.TemporaryDirectory() as root:
            store, p, renderer = fixture(root, ffmpeg)
            p['intro'].update(enabled=True, duration=10, audioPath='audio-1.wav',
                              placement='full_story_only', showTitle=False)
            p = store.save(p)
            with patch.object(renderer,'direct_intro_mux_supported',return_value=False,create=True):
                baseline=renderer.full(p,lambda *_:None)
            original=store.asset(p['id'],baseline['path'])
            before=original.read_bytes()
            original.rename(original.with_name('baseline-check.mp4'))
            checkpoint=original.with_name(original.stem+'-visual.mp4')
            checkpoint.rename(checkpoint.with_name('baseline-visual-check.mp4'))
            self.assertEqual(renderer.full_mux_forecast(p)['effectivePolicy'],'direct-concat-intro-decoded-audio-v1')
            result = renderer.full(p, lambda *_: None)
            self.assertEqual(result['fullAssemblyPolicy'],'direct-concat-intro-decoded-audio-v1')
            self.assertEqual(store.asset(p['id'],result['path']).read_bytes(),before)
            self.assertFalse(checkpoint.exists())
            self.assert_chapter_tones(store.asset(p['id'], result['path']), 11.2,
                                      [(.2, 430), (10.2, 430), (10.8, 560)])

    def test_mixed_mux_cancellation_reaps_decoders_and_preserves_completed_inputs(self):
        ffmpeg = os.environ['STUDIO_TEST_FFMPEG']
        with tempfile.TemporaryDirectory() as root:
            store, p, renderer = fixture(root, ffmpeg)
            folder = store.folder(p['id'])
            self.as_opus(folder, p['chapters'][1], ffmpeg)
            p = store.save(p)
            processes = []
            real_popen = subprocess.Popen
            def capture(*args, **kwargs):
                process = real_popen(*args, **kwargs)
                processes.append(process)
                return process
            seen_audio = False
            def cancel(message):
                nonlocal seen_audio
                if seen_audio:
                    raise RuntimeError('Fixture cancelled during audio decode')
                seen_audio = message == 'Joining chapter narration'
            with patch.object(subprocess, 'Popen', side_effect=capture):
                with self.assertRaisesRegex(RuntimeError, 'Fixture cancelled'):
                    renderer.full(p, cancel)
            self.assertTrue(seen_audio)
            self.assertTrue(all(proc.poll() is not None for proc in processes))
            self.assertFalse(list(folder.glob('*.writing.*')))
            self.assertFalse(list(folder.glob('*.partial.mp4')))
            self.assertTrue((folder / 'chapter-1.mp4').is_file())
            self.assertTrue((folder / 'audio-2.opus').is_file())

    def test_eighty_opus_chapters_keep_last_marker_and_bounded_command_size(self):
        ffmpeg = os.environ['STUDIO_TEST_FFMPEG']
        with tempfile.TemporaryDirectory() as root:
            store, p, renderer = fixture(root, ffmpeg)
            folder = store.folder(p['id'])
            for ch in p['chapters']:
                self.as_opus(folder, ch, ffmpeg)
            for index in range(2, 80):
                template = p['chapters'][index % 2]
                ch = new_chapter(index + 1)
                for field in ('sourceText', 'cleanNarrationText', 'audio'):
                    ch[field] = copy.deepcopy(template[field])
                os.link(folder / f'chapter-{template["number"]}.mp4', folder / f'chapter-{ch["number"]}.mp4')
                p['chapters'].append(ch)
            p = store.save(p)
            result = renderer.full(p, lambda *_: None)
            self.assert_chapter_tones(store.asset(p['id'], result['path']), 48.,
                [(i * .6 + .2, (430, 560)[i % 2]) for i in (0, 1, 37, 60, 79)])
            # Sources are supplied via a concat list, even with high chapter counts.
            self.assertLess(max(map(len, renderer.calls)), 40)

    def test_real_aac_chapters_keep_frames_pcm_and_packet_timestamps(self):
        ffmpeg=os.environ['STUDIO_TEST_FFMPEG']
        probe=os.environ.get('STUDIO_TEST_FFPROBE') or str(Path(ffmpeg).with_name('ffprobe.exe' if os.name=='nt' else 'ffprobe'))
        for offset,fps,audio_rate in ((0,30,24000),(.017,30,24000),(-.017,30,24000),(0,60,8000),(0,60,16000),(0,24,48000)):
            with self.subTest(chapterDurationOffset=offset,fps=fps,audioRate=audio_rate),tempfile.TemporaryDirectory() as root:
                store,p,renderer=fixture(root,ffmpeg,fps,audio_rate);folder=store.folder(p['id'])
                for ch in p['chapters']:ch['audio']['duration']+=offset
                p=store.save(p);durations=[ch['audio']['duration'] for ch in p['chapters']]
                files=[folder/f'chapter-{ch["number"]}.mp4' for ch in p['chapters']]
                silent=folder/'baseline-silent.mp4';old=folder/'baseline.mp4'
                renderer.concat(files,silent,lambda *_:None,folder/'baseline.log',durations,video_only=True)
                listing=renderer.concat_listing([folder/ch['audio']['path'] for ch in p['chapters']],folder/'baseline-audio.txt')
                renderer.run(['-i',str(silent),'-f','concat','-safe','0','-i',str(listing),'-map','0:v:0','-map','1:a:0',
                    '-c:v','copy','-c:a','aac','-b:a','128k','-af','apad','-t',str(sum(durations)),
                    '-movflags','+faststart',str(old)],lambda *_:None,folder/'baseline.log')
                renderer.calls=[]
                new=store.asset(p['id'],renderer.full(p,lambda *_:None)['path'])
                direct=fps==30 and audio_rate==24000
                self.assertEqual(len(renderer.calls),1 if direct else 2)
                def decoded(path,stream,codec):
                    return subprocess.check_output([ffmpeg,'-v','error','-threads','1','-i',str(path),'-map',stream,
                        *codec,'-f','hash','-hash','sha256','-'],timeout=30)
                self.assertEqual(decoded(old,'0:v:0',['-pix_fmt','rgb24']),decoded(new,'0:v:0',['-pix_fmt','rgb24']))
                self.assertEqual(decoded(old,'0:a:0',['-c:a','pcm_s16le']),decoded(new,'0:a:0',['-c:a','pcm_s16le']))
                def packets(path):
                    return json.loads(subprocess.check_output([probe,'-v','error','-show_data_hash','sha256',
                        '-show_entries','packet=stream_index,pts,dts,duration,flags,data_hash,side_data_list:stream=codec_name,time_base,start_pts,duration_ts',
                        '-of','json',str(path)],timeout=30))
                self.assertEqual(packets(old),packets(new))
                self.assertEqual(bool(list(folder.glob('story-*-visual.mp4'))),not direct)


if __name__=='__main__':unittest.main()
