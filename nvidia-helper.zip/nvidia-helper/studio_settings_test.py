"""Settings exercise real dispatch guards and export caches, with no cloud calls."""
import base64, copy, io, json, tempfile, unittest
from pathlib import Path
from unittest.mock import Mock, patch
from PIL import Image
from studio_data import new_project, ProjectStore, get_shot
from studio_qc import check_level, should_check, validate_checks, review_signature, accept_image, decision, automatic_repairs
from studio_branding import validate, identity, bitmap
from studio_service import StudioService
from studio_render import VideoRenderer
from studio_overlap import validate_overlap
import full_video_test as full_fixtures
import server_test as server_fixtures

class DispatchSettingsTest(unittest.TestCase):
    setUp = full_fixtures.FullVideoTest.setUp
    tearDown = full_fixtures.FullVideoTest.tearDown
    def repair_fixture(self):
        self.service.prepare_story(self.project['id'],{})
        p=self.service.store.load(self.project['id']);ch=p['chapters'][0];shot=ch['scenes'][0]['shots'][0]
        for name,color in (('current.png','navy'),('older-source.png','red')):
            Image.new('RGB',(128,128),color).save(self.service.store.asset(p['id'],name))
        qc={'status':'FAILED','pass':False,'action':'image_edit','issues':['Wrong essential action'],
            'findings':[{'issue':'Wrong essential action','severity':'major'}],'repairPrompt':'Fix only the essential action.'}
        shot.update(imagePath='current.png',sourceImagePath='older-source.png',qc=copy.deepcopy(qc))
        p['settings'].update(qcCheckLevel='practical',automaticRepair=True,maxImageRetries=1,
            qcCostEstimate={'baselineControlled':True,'includesAPI':True,'includesIncrementalRental':True,
                'includesRechecks':True,'baselineGenerationUSD':1,'combinedQCAndReplacementUpperUSD':.08,
                'maxImageRetriesCovered':1})
        p=self.service.store.save(p);self.service.providers['native-flux']=Mock()
        provider=self.service.providers['existing']
        provider.getCapabilities=lambda:{'maxReferenceImages':0,'supportsImageEditing':False}
        self.service.visual_check=Mock(return_value=qc);self.service.record_timing=lambda *a,**kwargs:None
        provider.generateImage=Mock(return_value={'pil':Image.new('RGB',(128,128),'green')})
        return p,ch,shot,provider

    def test_budgeted_repair_uses_latest_image_and_counts_first_request_as_replacement(self):
        from image_provider import data_url
        p,ch,shot,provider=self.repair_fixture()
        StudioService.generate(self.service,p,ch['id'],shot['id'],123,
            {'budgetedQCRepair':True,'operation':'edit','_repairPrompt':'Fix action.','_collectReview':True})
        self.assertEqual(provider.generateImage.call_count,1)
        self.assertEqual(provider.generateImage.call_args.args[0]['sourceImage'],data_url(self.service.store.asset(p['id'],'current.png')))
        result=get_shot(self.service.store.load(p['id']),ch['id'],shot['id'])
        self.assertEqual(result['imageMetadata']['sourceImagePath'],'current.png')
        self.assertEqual(result['sourceImagePath'],'current.png')
        self.assertEqual(result['history'][0]['imagePath'],'current.png')
        self.assertFalse(result['qc']['pass'])

    def test_budgeted_failed_replacement_stops_at_limit_with_original_intact(self):
        p,ch,shot,provider=self.repair_fixture()
        provider.generateImage.side_effect=RuntimeError('Worker failed before output')
        with self.assertRaisesRegex(RuntimeError,'Worker failed'):
            StudioService.generate(self.service,p,ch['id'],shot['id'],123,{'budgetedQCRepair':True})
        self.assertEqual(provider.generateImage.call_count,1)
        self.assertEqual(get_shot(self.service.store.load(p['id']),ch['id'],shot['id'])['imagePath'],'current.png')

    # Reuse the actual orchestration harness, not its image-generation override.
    def test_changed_check_settings_do_not_boot_gpu_or_recheck_explicitly_accepted_image(self):
        from studio_qc import review_settings_signature
        p,ch,shot,provider=self.repair_fixture()
        shot=get_shot(p,ch['id'],shot['id'])
        original=review_settings_signature(p['settings'])
        shot['qc']['reviewSettingsSignature']=original
        p=self.service.store.save(p)
        accepted=accept_image(self.service.store,p['id'],ch['id'],shot['id'],{'imagePath':'current.png',
            'reviewSpecSignature':review_signature(p,shot,self.service.store)})
        self.service.store.mutate(p['id'],lambda latest:latest['settings'].update(qcCheckLevel='strict'))
        self.service.ensure_production_gpu=Mock(side_effect=AssertionError('No rental required'))
        self.service.inspect_shot=Mock(side_effect=AssertionError('Explicit acceptance must remain effective'))
        self.service.generate_production_chapter_images(p['id'],ch['id'],0,[ch['id']])
        self.service.ensure_production_gpu.assert_not_called();self.service.inspect_shot.assert_not_called()

    def test_stale_strict_review_uses_saved_image_without_gpu_boot(self):
        from studio_qc import review_settings_signature
        p,ch,shot,provider=self.repair_fixture()
        shot=get_shot(p,ch['id'],shot['id'])
        shot['qc'].update(status='PASSED',reviewSettingsSignature=review_settings_signature(p['settings']))
        shot['qc']['pass']=True;p['settings']['qcCheckLevel']='strict';self.service.store.save(p)
        self.service.ensure_production_gpu=Mock(side_effect=AssertionError('Only review work is pending'))
        self.service.inspect_shot=Mock(return_value={'selected':True})
        self.service.generate_production_chapter_images(p['id'],ch['id'],0,[ch['id']])
        self.service.ensure_production_gpu.assert_not_called();self.service.inspect_shot.assert_called_once()

    def test_intro_image_publication_does_not_depend_on_an_unfinished_qc_result(self):
        p,ch,shot,provider=self.repair_fixture()
        intro=copy.deepcopy(shot);intro.update(id='intro-publish-fixture',imagePath='')
        intro.pop('chapterId');intro.pop('sceneId')
        p['intro'].update(enabled=True,shots=[intro]);p['settings']['qcCheckLevel']='off'
        p=self.service.store.save(p)
        self.service.prepare_image_device=Mock()
        self.service.check_cloud_budget=Mock()
        StudioService.intro_image(self.service,p)
        saved=self.service.store.load(p['id'])['intro']['shots'][0]
        self.assertTrue(saved['imagePath']);self.assertEqual(saved['qc']['status'],'UNCHECKED')
        self.assertTrue(self.service.store.has_asset(p['id'],saved['imagePath']))

    def test_newly_selected_check_reuses_unchecked_chapter_image_without_gpu(self):
        p,ch,shot,provider=self.repair_fixture()
        shot=get_shot(p,ch['id'],shot['id'])
        shot.update(status='COMPLETE',qc={'status':'UNCHECKED','pass':None,'checkLevel':'off'})
        p['settings'].update(qcCheckLevel='practical',unattendedProduction=False)
        self.service.store.save(p)
        self.service.ensure_production_gpu=Mock(side_effect=AssertionError('Only review work is pending'))
        self.service.inspect_shot=Mock(return_value={'selected':True})
        self.service.generate_production_chapter_images(p['id'],ch['id'],0,[ch['id']])
        self.service.inspect_shot.assert_called_once()
        self.service.ensure_production_gpu.assert_not_called()
        provider.generateImage.assert_not_called()
        self.assertEqual(get_shot(self.service.store.load(p['id']),ch['id'],shot['id'])['imagePath'],'current.png')

    def test_changed_qc_policy_during_review_retains_result_without_certifying_new_settings(self):
        from studio_qc import review_settings_signature
        p,ch,shot,provider=self.repair_fixture()
        expected=review_settings_signature(p['settings'])
        def reviewed(*args):
            self.service.store.mutate(p['id'],lambda latest:latest['settings'].update(continuityStrictness='High'))
            return {'pass':True,'issues':[],'action':'pass','reviewSettingsSignature':expected}
        self.service.visual_check=reviewed
        result=StudioService.inspect_shot(self.service,p,ch['id'],shot['id'])
        saved=get_shot(self.service.store.load(p['id']),ch['id'],shot['id'])
        self.assertFalse(result['selected']);self.assertEqual(saved['imagePath'],'current.png')
        self.assertEqual(saved['qcHistory'][-1]['qc']['reviewSettingsSignature'],expected)

    def test_explicit_off_overrides_max_and_deferred_generation_without_paid_qc(self):
        self.service.prepare_story(self.project['id'], {})
        p=self.service.store.load(self.project['id']);ch=p['chapters'][0];shot=ch['scenes'][0]['shots'][0]
        p['settings'].update(qcCheckLevel='off', visionQC=True, generationMode='MAX QUALITY')
        p=self.service.store.save(p)
        provider=self.service.providers['existing']
        self.service.providers['native-flux']=Mock()
        provider.generateImage=Mock(return_value={'pil':Image.new('RGB',(128,128),'navy')})
        provider.getCapabilities=lambda:{'maxReferenceImages':0,'supportsImageEditing':False}
        self.service.visual_check=Mock(side_effect=AssertionError('No paid QC allowed'))
        self.service.record_timing=lambda *a,**kwargs:None
        StudioService.generate(self.service,p,ch['id'],shot['id'],123,{'deferQC':True})
        actual=get_shot(self.service.store.load(p['id']),ch['id'],shot['id'])
        self.assertEqual(actual['qc']['status'],'UNCHECKED');self.assertIsNone(actual['qc']['pass'])
        self.service.visual_check.assert_not_called();self.assertTrue(actual['imagePath'])
        with self.assertRaisesRegex(ValueError,'checks are Off'):
            self.service.enqueue(p['id'],ch['id'],'qc',[shot['id']],{})
        with self.assertRaisesRegex(ValueError,'checks are Off'):
            StudioService.inspect_shot(self.service,p,ch['id'],shot['id'])
        self.assertFalse(automatic_repairs(p['settings'] | {'qcPolicy':'strict','automaticRepair':True}))

    def test_sampled_generation_checks_selected_shots_only_and_records_skips_honestly(self):
        self.service.prepare_story(self.project['id'], {})
        p=self.service.store.load(self.project['id']);ch=p['chapters'][0];first=ch['scenes'][0]['shots'][0]
        p['settings'].update(qcCheckLevel='sampled',qcSampleEvery=5)
        other=copy.deepcopy(first)
        for i in range(100):
            other['id']='sample-candidate-'+str(i)
            if not should_check(p,other):break
        first['end']=2;other.update(start=2,end=4)
        ch['scenes'][0]['shots'].append(other);p=self.service.store.save(p)
        provider=self.service.providers['existing'];self.service.providers['native-flux']=Mock()
        provider.generateImage=Mock(side_effect=lambda *a:{'pil':Image.new('RGB',(128,128),'navy')})
        provider.getCapabilities=lambda:{'maxReferenceImages':0,'supportsImageEditing':False}
        self.service.visual_check=Mock(return_value={'pass':True,'issues':[],'action':'accept'})
        self.service.record_timing=lambda *a,**kwargs:None
        StudioService.generate(self.service,p,ch['id'],first['id'],123,{})
        StudioService.generate(self.service,self.service.store.load(p['id']),ch['id'],other['id'],124,{})
        self.assertEqual(self.service.visual_check.call_count,1)
        actual=self.service.store.load(p['id'])
        self.assertTrue(get_shot(actual,ch['id'],first['id'])['qc']['pass'])
        self.assertEqual(get_shot(actual,ch['id'],other['id'])['qc']['status'],'UNCHECKED')
        self.assertIsNone(get_shot(actual,ch['id'],other['id'])['qc']['pass'])

class SettingsContractTest(unittest.TestCase):
    def test_stable_sampling_new_defaults_and_legacy_compatibility(self):
        p=new_project();self.assertEqual(check_level(p['settings']),'practical')
        # Saved projects without the new default retain legacy check behavior.
        p['settings'].pop('qcCheckLevel');p['settings']['visionQC']=False
        self.assertEqual(check_level(p['settings']),'off')
        p['settings']['generationMode']='MAX QUALITY';self.assertEqual(check_level(p['settings']),'practical')
        p['settings']['qcCheckLevel']='off';self.assertFalse(should_check(p,{'id':'a'}))
        p['settings'].update(qcCheckLevel='sampled',qcSampleEvery=5)
        ch=p['chapters'][0];shots=[{'id':f'shot-{i}'} for i in range(200)]
        ch['scenes']=[{'shots':shots}];p['intro']['shots']=[{'id':'intro-first'},{'id':'intro-next'}]
        selected=[s['id'] for s in shots if should_check(p,s)]
        self.assertIn('shot-0',selected);self.assertTrue(should_check(p,p['intro']['shots'][0]))
        self.assertEqual(selected,[s['id'] for s in copy.deepcopy(shots) if should_check(copy.deepcopy(p),s)])
        self.assertTrue(20<len(selected)<70)
        for bad in [True,1,21,5.5,float('nan')]:
            with self.assertRaises(ValueError):validate_checks({'qcSampleEvery':bad})

    def test_manual_acceptance_survives_frequency_and_watermark_edits_without_faking_ai_pass(self):
        from studio_qc_test import PracticalQCTest
        fixture=PracticalQCTest();fixture.setUp()
        try:
            p=fixture.accept();s=get_shot(p,fixture.chid,fixture.sid);original=copy.deepcopy(s['qc'])
            p['settings'].update(qcCheckLevel='strict',qcSampleEvery=10,watermark={'enabled':True,'text':'Author'})
            self.assertEqual(decision(p,s,fixture.store)['disposition'],'accepted')
            self.assertEqual(s['qc'],original);self.assertFalse(s['qc']['pass'])
            fixture.store.save(p);reloaded=fixture.store.load(p['id'])
            self.assertEqual(reloaded['settings']['qcCheckLevel'],'strict')
            self.assertEqual(reloaded['settings']['watermark']['text'],'Author')
        finally:fixture.tearDown()

    def test_watermark_inputs_are_validated_and_logo_byte_changes_invalidate_export_publication(self):
        for w in [{'opacity':float('nan')},{'enabled':True,'text':''},{'imagePath':'../x'},
                  {'imagePath':'C:\\private.png'},{'color':"white;movie=x"},{'text':'A\nB'}, {'widthPercent':True}]:
            with self.assertRaises(ValueError):validate(w)
        with tempfile.TemporaryDirectory() as root:
            store=ProjectStore(root);p=store.save(new_project());logo=store.asset(p['id'],'logo.png')
            Image.new('RGBA',(40,20),(255,0,0,128)).save(logo)
            p['settings']['watermark']={'enabled':True,'type':'image','imagePath':'logo.png','opacity':.5}
            service=StudioService.__new__(StudioService);service.store=store;service.renderer=VideoRenderer(store,{})
            a=service.render_submission_signature(p);i=service.intro_submission_signature(p)
            dest=store.asset(p['id'],'prepared.png');bitmap(p,store,dest)
            with Image.open(dest) as img:self.assertEqual(img.getchannel('A').getextrema(),(64,64))
            Image.new('RGBA',(40,20),(0,255,0,128)).save(logo)
            self.assertNotEqual(a,service.render_submission_signature(p));self.assertNotEqual(i,service.intro_submission_signature(p))
            before=service.render_submission_signature(p);p['settings']['watermark']['enabled']=False
            self.assertNotEqual(before,service.render_submission_signature(p))

class SettingsBridgeTest(unittest.TestCase):
    setUp = server_fixtures.BridgeTest.setUp
    tearDown = server_fixtures.BridgeTest.tearDown
    request = server_fixtures.BridgeTest.request
    def test_logo_upload_preserves_alpha_and_settings_invalidate_exports_without_changing_sources(self):
        p=self.server.RequestHandlerClass.studio_service.store.save(new_project())
        p['intro']['duration']=30;p['chapters'][0]['sourceText']='Preserve this source.'
        service=self.server.RequestHandlerClass.studio_service;service.store.save(p)
        buf=io.BytesIO();Image.new('RGBA',(80,40),(255,255,255,96)).save(buf,'PNG')
        code,_,raw=self.request('/studio/upload',{'project':p['id'],'purpose':'watermark','data':'data:image/png;base64,'+base64.b64encode(buf.getvalue()).decode()})
        self.assertEqual(code,200);path=json.loads(raw)['path']
        with Image.open(service.store.asset(p['id'],path)) as logo:self.assertEqual(logo.getchannel('A').getextrema(),(96,96))
        s=copy.deepcopy(p['settings']);s.update(qcCheckLevel='off',watermark={'enabled':True,'type':'image','imagePath':path})
        code,_,raw=self.request('/studio/edit',{'project':p['id'],'scope':'project','patch':{'settings':s}})
        self.assertEqual(code,200);actual=service.store.load(p['id'])
        self.assertTrue(actual['renderStale']);self.assertTrue(actual['chapters'][0]['renderStale']);self.assertTrue(actual['intro']['renderStale'])
        self.assertEqual(actual['chapters'][0]['sourceText'],'Preserve this source.');self.assertEqual(actual['intro']['duration'],30)
        s['watermark']['imagePath']='missing.png'
        code,_,_=self.request('/studio/edit',{'project':p['id'],'scope':'project','patch':{'settings':s}})
        self.assertEqual(code,400);self.assertEqual(service.store.load(p['id'])['settings']['watermark']['imagePath'],path)

if __name__=='__main__':unittest.main()
