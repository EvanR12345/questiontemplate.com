"""Durable, compatible production observations, not another billing ledger.

Keep failed/reused/pending observations for diagnostics. Only fresh successful
matching work informs speed. Parent intervals and nested work are never added.
"""
import hashlib
import json
import math
import sqlite3
import statistics
import threading
import time

VERSION = 1

RENDER_TIMING_VERSION = 3
FRESH_RENDER_SCOPE = {'Render chapter':'fresh-chapter', 'Assemble full video':'fresh-assembly'}

def render_timing_details(stage, result):
    """Describe this invocation even when its returned file carries older render metadata."""
    if stage not in FRESH_RENDER_SCOPE or not isinstance(result, dict):
        return {}
    reused = result.get('reused') is True
    scope = 'reused-base' if reused else result.get('renderTimingScope', 'unverified')
    details = {'renderTimingScope':scope,'reused':reused}
    if stage == 'Assemble full video':
        details['fullAssemblyPolicy'] = result.get('fullAssemblyPolicy','format-guarded-original-audio-v1')
    return details

class HostExecutionClock:
    """Detect long gaps in host execution, not ordinary network/API waiting.

    A background sampler continues during remote waits. Sleep, suspension or
    severe starvation delays the sampler itself. Such runs remain recorded but
    must not teach the ETA an hour of apparent model work. No OS settings change.
    """
    def __init__(self,clock=time.monotonic,interval=2,threshold=20):
        self.clock=clock;self.interval=interval;self.threshold=threshold
        self.lock=threading.Lock();self.last=clock();self.total=0.;self.started=False

    def sample(self):
        with self.lock:
            now=self.clock();elapsed=max(0,now-self.last);self.last=now
            if elapsed>self.threshold:self.total+=elapsed-self.interval
            return self.total

    def snapshot(self):
        with self.lock:
            if not self.started:
                self.started=True
                threading.Thread(target=self._watch,name='studio-host-clock',daemon=True).start()
        return self.sample()

    def _watch(self):
        while True:
            time.sleep(self.interval);self.sample()

_host_execution_clock=HostExecutionClock()
def host_execution_gaps():return _host_execution_clock.snapshot()
def host_interruption_details(start):
    gap=max(0,host_execution_gaps()-start)
    return {'hostInterrupted':gap>0,'hostGapSeconds':round(gap,3)}
DIRECTOR_PASSES = {'Casting supervisor', 'Story analyst', 'Chapter director',
    'Scene director', 'Cinematographer', 'Workflow planner', 'Continuity supervisor',
    'Image prompt engineer','Source fact analyst','Source continuity reviewer','Source fact correction','Visual storyboard director','Storyboard continuity supervisor','Targeted storyboard repair'}


def positive(value):
    return type(value) in (int, float) and math.isfinite(value) and value > 0


def signature(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def interval_union(intervals):
    total=0;end=None
    for start,finish in sorted(intervals):
        if finish<=start:continue
        total+=max(0,finish-max(start,end if end is not None else start))
        end=max(finish,end if end is not None else finish)
    return total


def profile_for(stage, project, config, details=None):
    details=details or {};settings=project['settings']
    image=settings['image'];director=settings['director'];video=settings['video']
    profile={'version':VERSION,'stage':stage}
    if stage in ('Image pipeline','Image generation','Image + quality checks','Automatic image repair','Visual QC') and (
            project.get('production',{}).get('generationStrategy')=='dense' or project.get('generationStrategy')=='dense'):
        profile['imagePhasePolicy']='dense-generation-independent-qc-v1'
    from studio_image_workers import model_copies
    if stage in ('AI directing','Image pipeline','Image generation','Image + quality checks','Automatic image repair'):
        copies=model_copies(config) if image.get('provider')=='comfyui' else 1
        profile['productionTopology']={'modelCopies':copies,'requestSlots':copies*2 if copies>1 else 1,
            'audioLookahead':bool(config.get('studioAudioLookahead',True)),
            'chapterRenderOverlap':bool(config.get('studioRenderOverlap',True))}
    if stage=='AI directing' or stage in DIRECTOR_PASSES:
        profile.update(provider=director.get('provider'),model=details.get('model') or
            (config.get('openaiModel','gpt-6-luna') if director.get('provider')=='openai-luna' else director.get('model')),
            reasoning=director.get('reasoning','Balanced'),parallelism=details.get('directorTasks',director.get('parallelism',1)),
            concise=director.get('concisePrompts',False),focused=settings.get('focusedPrompts',False),
            executionMode=director.get('executionMode','classic'),reasoningProfile=director.get('reasoningProfile','selected'),
            factGroupSentences=director.get('factGroupSentences',48),
            cadencePerMinute=director.get('cadencePerMinute'),
            compactWire=config.get('openaiCompactWire',False) or director.get('executionMode','classic').startswith('staged'),
            tier=director.get('processingTier',config.get('openaiServiceTier','default')),layout=settings.get('layoutMode','AUTO'),
            mode=settings.get('generationMode','BALANCED'),style=settings.get('style'),
            layoutSettings=settings.get('customLayout',{}),maxOutputTokens=director.get('maxOutputTokens',12000),
            checkLevel=settings.get('qcCheckLevel','off'))
        profile['sourceGroundingVersion']=1
        if stage=='AI directing':
            from story_grounding import OWNERSHIP_RESOLUTION_VERSION
            profile['ownershipResolutionVersion']=OWNERSHIP_RESOLUTION_VERSION
        if stage=='AI directing' and director.get('executionMode') in ('staged-review','staged-lean'):
            from director_provider import STORYBOARD_REVIEW_CAPACITY_VERSION
            profile['storyboardReviewCapacityVersion']=STORYBOARD_REVIEW_CAPACITY_VERSION
        if director.get('executionMode','classic').startswith('staged'):
            lean=director.get('executionMode')=='staged-lean'
            profile['compactCuts']=director.get('compactCuts',False)
            profile['planVersion']=13 if lean and profile['compactCuts'] else 11 if lean else 2
            from director_pipeline import fact_beats_mode
            profile['factsVersion']=5 if lean and fact_beats_mode(director)=='storyboard' else 4 if lean else 3
            if lean:profile['reviewHintsVersion']=2
            if lean:profile['sourceTimingUnitsVersion']=1
            if lean:profile['sourceVisualOverlap']=director.get('sourceVisualOverlap',False)
            if lean and profile['sourceVisualOverlap']:
                profile['acceptedVisualDispatchVersion']=2
            if lean:profile['factReasoning']='high' if director.get('reasoning')=='High' else 'medium'
            from director_staged import visual_group_limits
            sentences,characters,shots=visual_group_limits(director)
            profile['visualGroupLimit']={'sentences':sentences,'characters':characters,'targetShots':shots}
    elif stage=='Visual QC':
        from studio_qc import policy
        selected=details.get('_shotSpec') or next((s for c in project['chapters'] for sc in c['scenes'] for s in sc['shots'] if s['id']==details.get('shot')), {})
        model=(config.get('openaiModel','gpt-6-luna') if director.get('provider')=='openai-luna' else director.get('model'))
        profile.update(reviewVersion=4,timingScope=details.get('reviewTimingScope','api-call'),provider=director.get('provider'),model=model,
            reviewAPISlots=min(4,director.get('parallelism',1)) if profile.get('imagePhasePolicy') else details.get('reviewAPISlots',details.get('directorTasks',director.get('parallelism',1))),
            processingTier=director.get('processingTier') or config.get('openaiServiceTier','default'),
            reasoning=director.get('qcReasoning') or ('High' if settings.get('generationMode')=='MAX QUALITY' else 'Fast'),
            policy=policy(settings),continuity=settings.get('continuityStrictness'),style=settings.get('style'),
            constraints=signature(settings.get('imageVisualConstraints',settings.get('visualConstraints',''))),
            imageModel=selected.get('imageModel',image.get('model')),imageProvider=selected.get('imageProvider',image.get('provider')),
            imageWorkflow=selected.get('workflow',image.get('workflow')),width=selected.get('generationSettings',{}).get('width',image.get('width')),
            height=selected.get('generationSettings',{}).get('height',image.get('height')),detail='low')
    elif stage in ('Image pipeline','Image + quality checks','Image generation','Visual QC','Character reference','Intro images','Automatic image repair'):
        profile['visualGroundingVersion']=1
        if details.get('shot'):
            image=details.get('_shotSpec') or next((s for c in project['chapters'] for sc in c['scenes'] for s in sc['shots']
                if s['id']==details['shot']),{}) | {}
            image={**settings['image'],**image.get('generationSettings',{}),
                'provider':image.get('imageProvider',settings['image']['provider']),
                'model':image.get('imageModel',settings['image']['model']),
                'workflow':image.get('workflow',settings['image']['workflow'])}
        # A changed cloud host cannot inherit the previous host's timing.
        backend=signature({k:config.get(k) for k in ('comfyEndpoint','comfySshHost','comfyPort','comfyWorkflow','performanceGPU')})
        profile.update(provider=details.get('provider') or image.get('provider'),model=details.get('model') or image.get('model'),
            workflow=image.get('workflow'),width=image.get('width'),height=image.get('height'),
            steps=image.get('steps'),sampler=image.get('sampler'),scheduler=image.get('scheduler'),
            conditioning=signature({k:image.get(k) for k in ('guidance','denoisingStrength','loras','controlnets','ipAdapter')}),
            references=image.get('workflow')=='reference-edit',checkLevel=settings.get('qcCheckLevel','off'),
            sampleEvery=settings.get('qcSampleEvery',5),backend=backend,execution='single-image-lane',
            automaticRepair=settings.get('automaticRepair',False),maxRetries=settings.get('maxImageRetries',0),
            style=settings.get('style'))
        if profile.get('provider')=='comfyui' and config.get('comfyPersistentHTTP',True) is True:
            profile['imageTransport']='private-http-keepalive-v1'
        if stage in ('Image pipeline','Image generation','Character reference','Intro images','Automatic image repair'):
            rental=project.get('production',{}).get('gpuRental',{})
            if rental.get('provider') in ('vast','lium') and rental.get('project')==project['id']:
                profile.update(cloudMarketplace=rental['provider'],cloudBackend=rental.get('imageBackendFingerprint','unverified'))
        if settings.get('unattendedProduction'):
            profile.update(unattended=True,repairBudgetMode=settings.get('qcRepairBudgetMode','overhead'),repairTiming='deferred')
        if stage=='Image pipeline':
            from studio_overlap import shot_task_limit
            profile.update(imageTasks=details.get('imageTasks',shot_task_limit(project,{})),director=director.get('provider'),
                directorParallelism=director.get('parallelism',1),reasoning=director.get('reasoning','Balanced'))
        if stage in ('Image pipeline','Image + quality checks'):
            from studio_director_limits import ADAPTIVE_IMAGE_ADMISSION,adaptive_image_window
            eligible=(config.get('experimentalAdaptiveImageAdmission') is True
                      and adaptive_image_window(settings,copies,copies*2 if copies>1 else 1))
            if eligible or details.get('imageAdmissionPolicy')==ADAPTIVE_IMAGE_ADMISSION:
                window=details.get('imageTasks',5)
                profile.update(imageAdmissionPolicy=ADAPTIVE_IMAGE_ADMISSION,
                    imageWindowMin=details.get('imageWindowMin',window),
                    imageWindowMax=details.get('imageWindowMax',window))
    elif stage in ('Render chapter','Assemble full video'):
        backend=details.get('renderBackend',config.get('performanceRenderBackend',config.get('renderBackend','cpu')))
        profile.update(width=video.get('width'),height=video.get('height'),fps=video.get('fps'),
            renderTimingVersion=RENDER_TIMING_VERSION,renderTimingScope=details.get('renderTimingScope', FRESH_RENDER_SCOPE[stage]),
            renderer=backend,renderWorkers=1 if backend=='native' else config.get('renderWorkers',2),
            crf=video.get('crf'),fit=video.get('imageFit'),
            motion=video.get('motionMode'),zoomAmount=video.get('zoomAmount',.06),motionEasing=video.get('motionEasing','smooth'),
            watermark=signature(settings.get('watermark',{})),engagement=signature(settings.get('engagement',{})),
            machine=signature({'gpu':config.get('performanceGPU','local'),
                'renderer':config.get('nativeRendererExecutable'), 'ffmpeg':config.get('ffmpeg')}))
        if stage=='Assemble full video':
            profile['fullAssemblyPolicy']=details.get('fullAssemblyPolicy','format-guarded-original-audio-v1')
        if backend=='native':
            from studio_gpu_render import ENGINE
            profile['renderEngine']=dict(ENGINE)
            # The same encoded pixels now avoid per-frame progress commits.
            # Old native timings must not teach the new display-write policy.
            profile['frameProgressPolicy']='sampled-250ms-v1'
    elif stage=='Narration':
        from studio_voice_provider import identity
        profile.update(identity(settings))
        if profile.get('voiceCompute')=='kaggle':
            # Actual single-chapter jobs and shared notebook waits have distinct
            # histories, regardless of the project's configured batch ceiling.
            profile['chapterBatchSize']=details.get('voiceBatch',{}).get('chapters',1)
        from narration_audio import VERSION as delivery_version, FLOW_VERSION
        profile.update(voice=settings.get('voice'),speed=settings.get('speed',1),deliveryVersion=delivery_version,flowVersion=FLOW_VERSION,
            delivery=settings.get('narrationDelivery','standard'),effectMode=settings.get('soundEffects','subtle'),
            emphasis=signature(settings.get('emphasisPhrases',[])))
    else:return None
    if stage in ('Visual QC', 'Image pipeline', 'Image + quality checks') and settings.get('qcClothingContinuity') == 'advisory':
        profile['clothingContinuity'] = 'advisory'
        profile['clothingFindingVersion'] = 1
    return profile


def observation_units(stage, project, details):
    chapter=next((c for c in project['chapters'] if c['number']==details.get('chapter')),None)
    if stage in DIRECTOR_PASSES:return {'kind':'calls','value':1}
    if stage=='AI directing' or stage=='Narration':
        if not chapter:return None
        return {'kind':'characters','value':len(chapter.get('cleanNarrationText') or chapter['sourceText'])}
    if stage=='Image pipeline':return {'kind':'images','value':details.get('images',0)}
    if stage in ('Image + quality checks','Image generation','Visual QC','Character reference','Intro images','Automatic image repair'):
        return {'kind':'images','value':1}
    if stage=='Render chapter':
        duration=chapter.get('audio',{}).get('duration') if chapter else None
        return {'kind':'videoSeconds','value':duration} if positive(duration) else None
    if stage=='Assemble full video':
        duration=sum(c.get('audio',{}).get('duration',0) for c in project['chapters'] if c['sourceText'].strip())
        return {'kind':'videoSeconds','value':duration} if positive(duration) else None
    return None


class PerformanceStore:
    def __init__(self,path):
        self.lock=threading.RLock()
        self.db=sqlite3.connect(path,check_same_thread=False)
        self.db.row_factory=sqlite3.Row
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('CREATE TABLE IF NOT EXISTS observations '
            '(id TEXT PRIMARY KEY,run_id TEXT,profile_hash TEXT,profile TEXT,stage TEXT,units_kind TEXT,'
            'units REAL,seconds REAL,cost REAL,status TEXT,reused INTEGER,pending INTEGER,paused INTEGER,'
            'finished REAL,source TEXT)')
        self.db.execute('CREATE INDEX IF NOT EXISTS observations_profile ON observations(profile_hash,finished)')
        self.db.commit()

    def record(self,identity,run_id,profile,units,seconds,details,finished=None,source='live'):
        if not profile or not units or not positive(units['value']) or not positive(seconds) or details.get('excludeFromLearning'):return False
        cost=details.get('estimatedUSD')
        if type(cost) not in (int,float) or not math.isfinite(cost) or cost<0:cost=None
        with self.lock:
            changed=self.db.execute('INSERT OR IGNORE INTO observations VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                (identity,str(run_id),signature(profile),json.dumps(profile,sort_keys=True),profile['stage'],
                 units['kind'],units['value'],seconds,cost,details.get('status','COMPLETE'),
                 bool(details.get('reused')),bool(details.get('usagePending')),bool(details.get('paused') or details.get('hostInterrupted')),
                 finished or time.time(),source)).rowcount
            self.db.commit()
        return bool(changed)

    def estimate(self,profile,units,now=None):
        now=now or time.time()
        if not profile or not units or not positive(units['value']):return {'status':'UNKNOWN','seconds':None,'costUSD':None,'samples':0,'runs':0}
        with self.lock:
            identity=signature(profile)
            retained=self.db.execute('SELECT COUNT(*) FROM observations WHERE profile_hash=? AND units_kind=?',
                (identity,units['kind'])).fetchone()[0]
            expected_scope = FRESH_RENDER_SCOPE.get(profile.get('stage'))
            if expected_scope and (profile.get('renderTimingVersion') != RENDER_TIMING_VERSION or
                                   profile.get('renderTimingScope') != expected_scope):
                return {'status':'UNKNOWN','seconds':None,'costUSD':None,'samples':0,'runs':0,'retained':retained,
                    'note':'The saved work scope does not establish a fresh render-stage timing.'}
            usable=[dict(r) for r in self.db.execute('SELECT * FROM observations WHERE profile_hash=? AND units_kind=? '
                "AND status='COMPLETE' AND reused=0 AND pending=0 AND paused=0 AND finished BETWEEN ? AND ? "
                'ORDER BY finished DESC LIMIT 30',(identity,units['kind'],now-90*86400,now))]
        if not usable:return {'status':'UNKNOWN','seconds':None,'costUSD':None,'samples':0,'runs':0,'retained':retained}
        # One long run cannot masquerade as thirty independent experiments.
        rates={};costs={}
        for row in usable:
            rates.setdefault(row['run_id'],[]).append(row['seconds']/row['units'])
            if row['cost'] is not None:costs.setdefault(row['run_id'],[]).append(row['cost']/row['units'])
        run_rates=[statistics.median(v) for v in rates.values()]
        scale=units['value'];seconds=statistics.median(run_rates)*scale
        return {'status':'LIMITED_HISTORY' if len(run_rates)<3 else 'OBSERVED',
            'seconds':seconds,'rangeSeconds':[min(run_rates)*scale,max(run_rates)*scale],
            'costUSD':statistics.median([statistics.median(v) for v in costs.values()])*scale if costs else None,
            'samples':len(usable),'runs':len(run_rates),'retained':retained,
            'latest':max(r['finished'] for r in usable),'profile':profile,
            'note':'Recent matching successful fresh work; observed range is not a confidence interval or a guaranteed finish.'}

    def summary(self):
        with self.lock:
            return dict(self.db.execute('SELECT COUNT(*) AS observations,COUNT(DISTINCT run_id) AS runs,'
                'MAX(finished) AS latest FROM observations').fetchone())

    def known(self,identities):
        result=set()
        with self.lock:
            for start in range(0,len(identities),400):
                group=identities[start:start+400]
                result.update(r[0] for r in self.db.execute('SELECT id FROM observations WHERE id IN ('+
                    ','.join('?' for _ in group)+')',group))
        return result

    def close(self):
        with self.lock:self.db.close()
