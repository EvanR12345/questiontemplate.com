import json
import struct
import threading
import unittest
import tempfile
import io
from concurrent.futures import ThreadPoolExecutor
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import patch
from http.client import HTTPConnection
from http.server import ThreadingHTTPServer
from server import make_handler, main
from studio_data import new_project

KEY = 'a' * 64
ORIGIN = 'https://questiontemplate.com'


class StartupTest(unittest.TestCase):
    def check_startup(self, hidden):
        with tempfile.TemporaryDirectory() as directory:
            key_path = Path(directory) / '.pairing-key'
            key_path.write_text(KEY)
            output = io.StringIO()
            with patch('server.__file__', str(Path(directory) / 'server.py')), \
                    patch('server.CudaEngine') as engine, \
                    patch('server.make_handler'), \
                    patch('server.ThreadingHTTPServer'), \
                    patch('subprocess.run'), \
                    patch('server.webbrowser.open') as browser, \
                    patch.dict('os.environ', {'QT_NO_BROWSER': '1' if hidden else '0'}), \
                    redirect_stdout(output):
                engine.return_value.gpu = 'Test GPU'
                main()
            self.assertEqual(key_path.read_text(), KEY)
            if hidden:
                self.assertNotIn(KEY, output.getvalue())
                self.assertNotIn('#native=', output.getvalue())
                browser.assert_not_called()
            else:
                self.assertIn('#native=' + KEY, output.getvalue())
                browser.assert_called_once_with('https://questiontemplate.com/studio.html#native=' + KEY)

    def test_hidden_startup_keeps_pairing_key_out_of_redirected_output(self):
        self.check_startup(True)

    def test_interactive_startup_preserves_pairing_and_saved_key(self):
        self.check_startup(False)


class FakeEngine:
    def __init__(self):
        self.gpu='Test GPU'
        self.lock = threading.Lock()
        self.calls = []

    def health(self):
        return {'protocol': 1, 'backend': 'cuda', 'gpu': 'Test GPU', 'sampleRate': 24000, 'vocab': {'h': 1}}

    def prepare(self, voice):
        self.calls.append(('prepare', voice))

    def synthesize(self, phonemes, voice, speed):
        self.calls.append((phonemes, voice, speed))
        return struct.pack('<fff', -.5, 0, .5)


class BridgeTest(unittest.TestCase):
    def test_manual_edit_history_undo_and_private_report_are_authenticated(self):
        service=self.server.RequestHandlerClass.studio_service
        p=service.store.save(new_project('History fixture'))
        body={'project':p['id'],'scope':'chapter','id':p['chapters'][0]['id'],
              'chapter':p['chapters'][0]['id'],'patch':{'sourceText':'A quiet return.'}}
        code,_,raw=self.request('/studio/edit',body)
        self.assertEqual(code,200,raw)
        edited=json.loads(raw);entry=edited['actionHistory'][-1]
        self.assertEqual(edited['chapters'][0]['cleanNarrationText'],'A quiet return.')
        code,_,raw=self.request('/studio/workspace',{'project':p['id'],'operation':'undo',
             'actionId':entry['id'],'revision':edited['revision']})
        self.assertEqual(code,200,raw)
        restored=json.loads(raw);self.assertEqual(restored['chapters'][0]['sourceText'],'')
        self.assertTrue(restored['actionHistory'][-1]['undone'])
        self.assertEqual(self.request('/studio/workspace-report?project='+p['id'],key='wrong')[0],401)
        code,_,raw=self.request('/studio/workspace-report?project='+p['id'])
        self.assertEqual(code,200,raw)
        report=json.loads(raw);self.assertIsNone(report['cost']['apiKnownEstimatedUSD'])
        self.assertEqual(report['status'],'NOT_COMPLETE');self.assertFalse(self.engine.calls)

    def test_chapter_editor_history_matches_full_project_diff(self):
        from studio_action_history import changes, snapshot
        from studio_data import new_chapter

        store = self.server.RequestHandlerClass.studio_service.store
        project = new_project('Prose history')
        project['chapters'].append(new_chapter(2))
        chapter, other = project['chapters']
        project = store.save(project)
        chapter_id, other_id = chapter['id'], other['id']
        edits = [
            {'sourceText': 'Second chapter\n\nA quiet return.', 'name': 'The return'},
            {'cleanNarrationText': 'A deliberate voice.', 'narrationMode': 'manual', 'includeChapterLabel': True},
            {'sourceText': 'The author changed the story.', 'name': 'The new name'},
            {'name': 'A plan edit', 'analysis': {'note': 'Keep the original beats'}},
        ]
        for values in edits:
            with self.subTest(values=values):
                before = snapshot(project)
                body = {'project': project['id'], 'scope': 'chapter', 'id': other_id,
                        'chapter': other_id, 'patch': values}
                code,_,raw = self.request('/studio/edit',body)
                self.assertEqual(code,200,raw)
                response = json.loads(raw)
                project = store.load(project['id'])
                action = project['actionHistory'][-1]
                self.assertEqual(action['changes'],changes(before,project))
                self.assertEqual(response['chapters'][0],project['chapters'][0])
                self.assertEqual(response['chapters'][1],project['chapters'][1])
                self.assertEqual(response['revision'],project['revision'])
                self.assertIn('qcRepairBudget',response)
        self.assertEqual(project['chapters'][1]['cleanNarrationText'],'A deliberate voice.')
        self.assertEqual(project['chapters'][0]['id'],chapter_id)

        earlier = project['actionHistory'][0]
        code,_,raw = self.request('/studio/workspace',{'project':project['id'],'operation':'undo',
            'actionId':earlier['id'],'revision':project['revision']})
        self.assertNotEqual(code,200,raw)
        self.assertIn(b'Newer work changed this value',raw)
        self.assertEqual(store.load(project['id']),project)

    def test_workspace_requires_auth_and_revision_and_keeps_caps(self):
        service=self.server.RequestHandlerClass.studio_service
        p=service.store.save(new_project('Workspace'))
        body={'project':p['id'],'revision':p['revision'],'operation':'save-setup','name':'Fantasy'}
        self.assertEqual(self.request('/studio/workspace',body,key='wrong')[0],401)
        code,_,raw=self.request('/studio/workspace',body)
        self.assertEqual(code,200);saved=json.loads(raw)
        self.assertEqual(saved['savedSetups'][0]['name'],'Fantasy')
        self.assertEqual(self.request('/studio/workspace',body)[0],400)
        self.assertFalse(self.engine.calls)

    def test_workspace_cannot_replace_state_during_queued_work(self):
        service=self.server.RequestHandlerClass.studio_service
        p=service.store.save(new_project('Busy'))
        with service.cv:
            service.paused=True
            service.db.execute("INSERT INTO jobs(id,project,chapter,kind,status,payload,created) VALUES(?,?,?,?,?,?,?)",
                ('workspace-job',p['id'],p['chapters'][0]['id'],'image','QUEUED','{}',1))
            service.db.commit()
        code,_,raw=self.request('/studio/workspace',{'project':p['id'],'revision':p['revision'],
            'operation':'save-setup','name':'Unsafe boundary'})
        self.assertEqual(code,400);self.assertIn('idle',json.loads(raw)['error'])
        self.assertEqual(service.store.load(p['id'])['revision'],p['revision'])

    def test_vimeo_credentials_and_private_paths_never_enter_browser_configuration(self):
        service=self.server.RequestHandlerClass.studio_service
        with patch.dict(service.config,{'vimeoApiToken':'private-vimeo-test-token','vimeoKeyFile':'C:/private/vimeo-key.json'}):
            code,_,raw=self.request('/studio/config')
        self.assertEqual(code,200)
        self.assertNotIn(b'private-vimeo-test-token',raw)
        self.assertNotIn(b'vimeo-key.json',raw)
        self.assertNotIn('vimeoKeyFile',json.loads(raw))
        self.assertEqual(self.request('/studio/vimeo',key='wrong')[0],401)

    def test_planner_profile_reports_the_actual_cpu_fallback_without_starting_work(self):
        service=self.server.RequestHandlerClass.studio_service
        project=service.store.save(new_project('Read-only renderer profile'))
        service.config['renderBackend']='native'
        with patch.object(service.renderer,'allow_legacy_render_reuse',True):
            code,_,raw=self.request('/studio/planner-profile?project='+project['id'])
        self.assertEqual(code,200,raw)
        self.assertEqual(json.loads(raw)['renderExecution']['backend'],'cpu')
        self.assertEqual(service.store.load(project['id']),project)
        self.assertIsNone(service.current)

    def test_recommended_preset_preserves_original_story_outputs_and_spending_grants(self):
        service=self.server.RequestHandlerClass.studio_service
        p=new_project('Saved story');p['settings']['budget']={'openaiUSD':1}
        p['settings']['image'].update(provider='comfyui',model='flux2-klein-4b',workflow='klein')
        p['settings']['director'].update(provider='openai-luna',executionMode='staged-lean',visualPacking='large',compactCuts=True,sourceVisualOverlap=True)
        p['chapters'][0]['sourceText']='Keep this story.';p['render']={'path':'saved.mp4'}
        p=service.store.save(p)
        code,_,raw=self.request('/studio/production-preset',{'project':p['id']})
        self.assertEqual(code,200,raw)
        result=json.loads(raw)['project']
        self.assertEqual(result['chapters'],p['chapters']);self.assertEqual(result['render'],p['render'])
        self.assertEqual(result['settings']['budget'],p['settings']['budget'])
        self.assertEqual(result['settings']['director']['visualPacking'],'small')
        self.assertFalse(result['settings']['director']['compactCuts'])
        self.assertEqual(result['settingsHistory'][-1]['settings'],p['settings'])

    def test_health_reports_the_broker_image_configuration_and_dense_lease_policy(self):
        service = self.server.RequestHandlerClass.studio_service
        provider = service.providers['comfyui']
        cases = [
            ({'runpodManagedPodId': 'fixture'}, True, True),
            ({'gpuProviderOrder': ['vast'], 'gpuImageVerifiedProviders': ['vast']}, True, True),
            ({'gpuProviderOrder': ['lium'], 'gpuImageVerifiedProviders': ['lium'],
              'studioDenseLeaseContinuity': False}, True, False),
            ({'gpuProviderOrder': ['lium'], 'gpuRenderVerifiedProviders': ['lium']}, False, True),
            ({'runpodImageCacheEnabled': True}, False, True),
        ]
        for config, managed, holds_gpu in cases:
            with self.subTest(config=config), patch.dict(service.config, config, clear=True), \
                    patch.object(provider, 'healthCheck', return_value={'installed': False}) as probe:
                code, _, raw = self.request('/studio/health')
                self.assertEqual(code, 200, raw)
                health = json.loads(raw)
                self.assertIs(health['managedGPU']['configured'], managed)
                self.assertIs(health['managedGPU']['holdsGPUForQC'], holds_gpu)
                self.assertEqual(probe.call_count, 0 if managed else 1)

    def test_production_readiness_reports_blocks_without_paid_requests(self):
        from unittest.mock import Mock
        service=self.server.RequestHandlerClass.studio_service
        p=service.store.save(new_project('Readiness only'))
        with patch.object(service,'storage',Mock(status=lambda *_:{'enabled':True,'provider':'Google Cloud Storage'})), \
             patch('studio_service.LocalQwenDirector.healthCheck',return_value={'installed':True}), \
             patch.object(service,'provider') as provider:
            code,_,raw=self.request('/studio/production-readiness?project='+p['id'])
        self.assertEqual(code,200)
        report=json.loads(raw)
        self.assertFalse(report['ready']);self.assertEqual(report['paidRequestsSubmitted'],0)
        self.assertEqual(report['voiceLocation'],'local')
        self.assertFalse(next(x for x in report['checks'] if x['name']=='chapters')['ready'])
        provider.assert_not_called()

    def test_preflight_revision_rejects_changed_story_before_queue_admission(self):
        service=self.server.RequestHandlerClass.studio_service
        p=new_project('Changed after checks');p['chapters'][0]['sourceText']='Story.'
        p=service.store.save(p);revision=p['revision']
        service.store.mutate(p['id'],lambda q:q.update(name='Later edit'))
        before=service.snapshot()['jobs']
        code,_,raw=self.request('/studio/jobs',{'project':p['id'],'kind':'produce-story',
            'options':{'preflightRevision':revision}})
        self.assertEqual(code,400)
        self.assertIn('Project changed',json.loads(raw)['error'])
        self.assertEqual(service.snapshot()['jobs'],before)

    def test_ready_cloud_project_checks_worker_without_starting_generation(self):
        from unittest.mock import Mock
        service=self.server.RequestHandlerClass.studio_service
        p=new_project('Ready project');p['chapters'][0]['sourceText']='Mira carries the key.'
        p['settings'].update(cloudImagesOnly=True,qcCheckLevel='off')
        p['settings']['image']['provider']='comfyui'
        p['settings']['director']['provider']='openai-luna'
        p['settings']['budget']={'openaiUSD':1}
        p=service.store.save(p)
        worker=Mock();worker.healthCheck.return_value={'installed':True}
        with patch.object(service,'storage',Mock(status=lambda *_:{'enabled':True,'provider':'Google Cloud Storage'})), \
             patch('studio_service.OpenAIDirector.healthCheck',return_value={'installed':True}), \
             patch.object(service,'provider',return_value=worker), \
             patch.dict(service.config,{'ffmpeg':__file__}):
            code,_,raw=self.request('/studio/production-readiness?project='+p['id']+'&overlap=true')
        report=json.loads(raw)
        self.assertEqual(code,200);self.assertTrue(report['ready'])
        self.assertEqual(report['paidRequestsSubmitted'],0)
        worker.healthCheck.assert_called_once();worker.generateImage.assert_not_called()

    def test_unavailable_cloud_worker_blocks_readiness_without_fallback_generation(self):
        from unittest.mock import Mock
        service=self.server.RequestHandlerClass.studio_service
        p=new_project('Unavailable project');p['chapters'][0]['sourceText']='Mira carries the key.'
        p['settings']['image']['provider']='comfyui';p=service.store.save(p)
        worker=Mock();worker.healthCheck.side_effect=TimeoutError('private upstream detail')
        with patch.object(service,'provider',return_value=worker):
            report=service.production_readiness(p['id'])
        self.assertFalse(report['ready']);worker.generateImage.assert_not_called()
        self.assertNotIn('private upstream detail',json.dumps(report))
        self.assertFalse(next(x for x in report['checks'] if x['name']=='images')['ready'])

    def test_cloud_attachment_link_does_not_restore_video_to_laptop(self):
        from unittest.mock import Mock
        service=self.server.RequestHandlerClass.studio_service
        storage=Mock(enabled=True,provider='Google Cloud Storage')
        storage.media_url.return_value='https://storage.googleapis.com/private/signed'
        with patch.object(service,'storage',storage),patch.object(service.store,'asset') as restore:
            code,_,raw=self.request('/studio/media-link',{'project':'pr-0123456789abcdef','path':'story.mp4','download':'Part 1.mp4'})
            self.assertEqual(code,200)
            self.assertEqual(json.loads(raw)['provider'],'Google Cloud Storage')
            storage.media_url.assert_called_once_with('pr-0123456789abcdef','story.mp4',download_name='Part 1.mp4')
            restore.assert_not_called()

    def test_new_project_reuses_selected_cloud_profile_without_old_story_or_audio_assets(self):
        service=self.server.RequestHandlerClass.studio_service
        original=new_project('Existing story')
        original['settings']['director']['provider']='openai-luna'
        original['settings']['image'].update(provider='comfyui',model='flux2-klein-4b',workflow='saved-cloud-workflow')
        original['settings']['video']['fps']=60
        original['settings'].update(cloudImagesOnly=True,qcCheckLevel='sampled')
        original['settings']['engagement'].update(outroAudioPath='old-outro.wav',outroAudioSignature='old-signature')
        original['settings']['image']['controlnets']=[{'image':'old-pose.png'}]
        original['chapters'][0]['sourceText']='Keep the existing story.'
        original['intro'].update(enabled=True,audioPath='old-intro.wav')
        original=service.store.save(original)
        code,_,raw=self.request('/studio/create',{'name':'New story','sourceProject':original['id']})
        self.assertEqual(code,200)
        created=json.loads(raw)
        self.assertEqual(created['settings']['director']['provider'],'openai-luna')
        self.assertEqual(created['settings']['image']['provider'],'comfyui')
        self.assertEqual(created['settings']['image']['model'],'flux2-klein-4b')
        self.assertEqual(created['settings']['video']['fps'],60)
        self.assertTrue(created['settings']['cloudImagesOnly'])
        self.assertEqual(created['settings']['qcCheckLevel'],'sampled')
        self.assertEqual(created['settings']['image']['controlnets'],[])
        self.assertNotIn('outroAudioPath',created['settings']['engagement'])
        self.assertEqual(created['chapters'][0]['sourceText'],'')
        self.assertFalse(created['intro']['enabled'])
        self.assertEqual(created['intro']['audioPath'],'')
        self.assertNotEqual(created['id'],original['id'])
        self.assertEqual(service.store.load(original['id']),original)

    def test_changing_intro_placement_invalidates_old_chapter_exports(self):
        service=self.server.RequestHandlerClass.studio_service
        project=new_project();project['intro'].update(enabled=True,placement='every_chapter')
        project['chapters'][0].update(renderStale=False,render={'path':'saved.mp4'})
        project=service.store.save(project)
        intro=project['intro'] | {'placement':'full_story_only'}
        code,_,_=self.request('/studio/edit',{'project':project['id'],'scope':'project','id':project['id'],'patch':{'intro':intro}})
        self.assertEqual(code,200)
        saved=service.store.load(project['id'])
        self.assertTrue(saved['chapters'][0]['renderStale'])
        self.assertEqual(saved['chapters'][0]['render']['path'],'saved.mp4')

    def test_editing_legacy_intro_text_records_old_audio_text_identity(self):
        from studio_data import digest
        service=self.server.RequestHandlerClass.studio_service
        project=new_project();project['intro'].update(voiceText='Original hook.',audioPath='intro.wav')
        project=service.store.save(project)
        code,_,_=self.request('/studio/edit',{'project':project['id'],'scope':'project','id':project['id'],'patch':{'intro':project['intro'] | {'voiceText':'Rewritten hook.'}}})
        self.assertEqual(code,200)
        saved=service.store.load(project['id'])
        self.assertEqual(saved['intro']['audioTextDigest'],digest('Original hook.'))
        self.assertEqual(saved['intro']['voiceText'],'Rewritten hook.')

    def test_trace_export_is_authenticated_and_does_not_expose_project_text(self):
        service = self.server.RequestHandlerClass.studio_service
        project = service.store.save(new_project())
        with service.trace.span(project['id'], 'Test stage', {'prompt': 'PRIVATE STORY'}):
            pass
        path = '/studio/trace?project=' + project['id']
        self.assertEqual(self.request(path=path, key='bad')[0], 401)
        code, _, raw = self.request(path=path)
        self.assertEqual(code, 200)
        self.assertNotIn(b'PRIVATE STORY', raw)
        self.assertEqual(json.loads(raw)['spans'][0]['stage'], 'Test stage')

    def test_offline_text_sync_merges_current_assets_atomically_and_can_retry(self):
        from studio_data import new_chapter
        store=self.server.RequestHandlerClass.studio_service.store
        p=new_project()
        p['chapters'].append(new_chapter(2))
        first,second=p['chapters']
        first['sourceText']='Original first.'
        second['sourceText']='Original second.'
        p=store.save(p)
        def new_work(latest):
            latest['chapters'][0]['render']={'path':'finished-after-disconnect.mp4'}
            latest['chapters'][1]['sourceText']='Another human edit.'
        store.mutate(p['id'],new_work)
        newer=store.load(p['id'])
        edits=[{'id':ch['id'],'before':{'sourceText':ch['sourceText']},'values':{'sourceText':'Browser edit.'}}
               for ch in (first,second)]
        sync=lambda fields:self.request('/studio/sync-offline',{'project':p['id'],'edits':fields})
        code,_,_=sync(edits)
        self.assertNotEqual(code,200)
        self.assertEqual(store.load(p['id']),newer)
        self.assertEqual(sync(edits[:1])[0],200)
        merged=store.load(p['id'])
        ch=merged['chapters'][0]
        self.assertEqual(ch['cleanNarrationText'],'Browser edit.')
        self.assertTrue(ch['renderStale'])
        self.assertEqual(ch['render'],newer['chapters'][0]['render'])
        self.assertEqual(merged['chapters'][1],newer['chapters'][1])
        self.assertEqual(sync(edits[:1])[0],200)
        self.assertEqual(store.load(p['id']),merged)

    def test_legacy_browser_sync_requires_matching_revision_without_changing_file_import(self):
        store=self.server.RequestHandlerClass.studio_service.store
        saved=store.save(new_project())
        payload={'project':saved['id'],'snapshot':saved,'expectedRevision':saved['revision']}
        store.mutate(saved['id'],lambda p:p.update(name='New helper edition'))
        newer=store.load(saved['id'])
        self.assertNotEqual(self.request('/studio/sync-offline',payload)[0],200)
        self.assertEqual(store.load(saved['id']),newer)
        payload.update(snapshot=newer | {'name':'Edited offline'},expectedRevision=newer['revision'])
        self.assertEqual(self.request('/studio/sync-offline',payload)[0],200)
        self.assertEqual(store.load(saved['id'])['name'],'Edited offline')

    def test_file_import_clears_browser_state_and_reconnect_cannot_replace_a_new_arrival(self):
        store=self.server.RequestHandlerClass.studio_service.store
        draft=new_project('One offline story')
        draft.update(_unsynced=True,_offlineChapterEdits=[],_connectionPlaceholder=True)
        self.assertEqual(self.request('/studio/import',{'project':draft,'onlyIfMissing':True})[0],200)
        saved=store.load(draft['id'])
        self.assertFalse(any(key in saved for key in ('_unsynced','_offlineChapterEdits','_connectionPlaceholder')))
        newer=store.mutate(draft['id'],lambda p:p.update(name='Changed on helper'))
        self.assertNotEqual(self.request('/studio/import',{'project':draft,'onlyIfMissing':True})[0],200)
        self.assertEqual(store.load(draft['id']),newer)
        self.assertEqual(self.request('/studio/import',{'project':draft})[0],200)
        self.assertEqual(store.load(draft['id'])['name'],draft['name'])

    def test_explicit_sync_of_a_new_offline_project_before_first_helper_save(self):
        store=self.server.RequestHandlerClass.studio_service.store
        draft=new_project('Created offline')
        payload={'project':draft['id'],'expectedRevision':0,'snapshot':draft}
        self.assertEqual(self.request('/studio/sync-offline',payload)[0],200)
        self.assertEqual(store.load(draft['id'])['name'],draft['name'])
        restored=new_project('Previously saved on another helper')
        restored['revision']=2
        payload.update(project=restored['id'],expectedRevision=2,snapshot=restored)
        self.assertNotEqual(self.request('/studio/sync-offline',payload)[0],200)
        self.assertFalse((store.folder(restored['id'])/'project.json').exists())

    def setUp(self):
        self.engine = FakeEngine()
        self.directory = tempfile.TemporaryDirectory()
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), make_handler(self.engine, KEY, self.directory.name))
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown()
        self.server.RequestHandlerClass.image_queue.close()
        self.server.RequestHandlerClass.studio_service.close()
        self.server.server_close()
        self.thread.join()
        self.directory.cleanup()

    def request(self, path='/health', body=None, key=KEY, origin=ORIGIN, method=None, extra_headers=None):
        client = HTTPConnection('127.0.0.1', self.server.server_port, timeout=2)
        headers = {'Origin': origin, 'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json'}
        headers.update(extra_headers or {})
        client.request(method or ('GET' if body is None else 'POST'), path, None if body is None else json.dumps(body), headers)
        response = client.getresponse()
        result = response.status, dict(response.getheaders()), response.read()
        client.close()
        return result

    def test_missing_project_is_distinct_from_an_invalid_saved_snapshot(self):
        service=self.server.RequestHandlerClass.studio_service
        pid='pr-0123456789abcdef'
        code,_,data=self.request('/studio/project?id='+pid)
        self.assertEqual(code,404);self.assertEqual(json.loads(data)['code'],'PROJECT_NOT_FOUND')
        folder=service.store.folder(pid);folder.mkdir();snapshot=folder/'project.json';snapshot.write_text('{broken')
        code,_,data=self.request('/studio/project?id='+pid)
        self.assertEqual(code,400);self.assertNotEqual(json.loads(data).get('code'),'PROJECT_NOT_FOUND')
        self.assertEqual(snapshot.read_text(),'{broken')
        code,_,data=self.request('/studio/project?id=invalid')
        self.assertEqual(code,400)

    def test_unchanged_editor_save_does_not_rewrite_or_archive_the_whole_project(self):
        from unittest.mock import Mock
        service=self.server.RequestHandlerClass.studio_service
        p=service.store.save(new_project('Unchanged settings'))
        file=service.store.folder(p['id'])/'project.json';before=file.read_bytes()
        archive=Mock();archive.enqueue=Mock()
        with patch.object(service.store,'archive',archive):
            code,_,data=self.request('/studio/edit',{'project':p['id'],'scope':'project','patch':{'name':p['name'],'settings':p['settings'],'intro':p['intro']}})
        self.assertEqual(code,200);self.assertEqual(json.loads(data)['revision'],p['revision'])
        self.assertEqual(file.read_bytes(),before);archive.enqueue.assert_not_called()
        code,_,data=self.request('/studio/edit',{'project':p['id'],'scope':'project','patch':{'name':'Actual update'}})
        self.assertEqual(code,200);self.assertEqual(json.loads(data)['revision'],p['revision']+1)

    def test_authentication_and_origins(self):
        self.assertEqual(self.request(key='bad')[0], 401)
        code, headers, _ = self.request(origin='https://unrelated.example')
        self.assertEqual(code, 403)
        self.assertNotIn('Access-Control-Allow-Origin', headers)
        self.assertEqual(self.request()[0], 200)
        self.assertFalse(self.engine.calls)

    def test_preflight_and_cuda_metadata(self):
        code, headers, _ = self.request(method='OPTIONS', key='')
        self.assertEqual(code, 200)
        self.assertEqual(headers['Access-Control-Allow-Origin'], ORIGIN)
        self.assertEqual(headers['Access-Control-Allow-Private-Network'], 'true')
        code, _, data = self.request()
        self.assertEqual(json.loads(data)['backend'], 'cuda')

    def test_exact_binary_samples_and_voice(self):
        code, headers, data = self.request('/synthesize', {'phonemes': 'h', 'voice': 'am_michael', 'speed': 1})
        self.assertEqual(code, 200)
        self.assertEqual(headers['X-Sample-Rate'], '24000')
        self.assertEqual(struct.unpack('<fff', data), (-.5, 0, .5))
        self.assertEqual(self.engine.calls, [('h', 'am_michael', 1)])

    def test_reject_truncation_path_traversal_and_invalid_speed(self):
        for body in [
            {'phonemes': 'h' * 279, 'voice': 'am_michael', 'speed': 1},
            {'phonemes': 'h', 'voice': '../private', 'speed': 1},
            {'phonemes': 'h', 'voice': 'am_michael', 'speed': True},
            {'phonemes': 'h', 'voice': 'am_michael', 'speed': 11},
        ]:
            self.assertEqual(self.request('/synthesize', body)[0], 400)
        client = HTTPConnection('127.0.0.1', self.server.server_port, timeout=2)
        client.request('POST', '/synthesize', b'', {'Origin': ORIGIN, 'Authorization': 'Bearer '+KEY, 'Content-Length': str(32*1024*1024+1)})
        self.assertEqual(client.getresponse().status, 413)
        client.close()
        self.assertFalse(self.engine.calls)

    def test_one_inference_at_a_time(self):
        self.engine.lock.acquire()
        try:
            self.assertEqual(self.request('/image/generate', {'prompt': 'test'})[0], 409)
            self.assertEqual(self.request()[0], 200)
        finally:
            self.engine.lock.release()
        self.assertEqual(self.request('/prepare', {'voice': 'af_heart'})[0], 200)

    def test_aac_audition_media_ticket_serves_saved_bytes(self):
        store = self.server.RequestHandlerClass.studio_service.store
        p = store.save(new_project())
        store.asset(p['id'], 'audition.m4a').write_bytes(b'saved-aac-audition')
        code, _, body = self.request('/studio/media-link', {'project':p['id'], 'path':'audition.m4a'})
        self.assertEqual(code, 200)
        ticket = json.loads(body)['url'].split('/studio/media?',1)[1]
        code, headers, content = self.request('/studio/media?'+ticket)
        self.assertEqual(code, 200)
        self.assertTrue(headers['Content-Type'].startswith('audio/'))
        self.assertEqual(content, b'saved-aac-audition')
        self.assertEqual(self.request('/studio/media-link', {'project':p['id'], 'path':'../../private.m4a'})[0],400)
        self.assertFalse(self.engine.calls)

    def test_parallel_previews_reuse_one_ticket_and_expiry_still_applies(self):
        store = self.server.RequestHandlerClass.studio_service.store
        project = store.save(new_project())
        store.asset(project['id'], 'preview.mp4').write_bytes(b'saved-video')
        def link(_):
            return json.loads(self.request('/studio/media-link', {'project':project['id'], 'path':'preview.mp4'})[2])
        with ThreadPoolExecutor(4) as pool:links=list(pool.map(link, range(16)))
        self.assertEqual(len({item['url'] for item in links}), 1)
        ticket_path='/studio/media?'+links[0]['url'].split('/studio/media?',1)[1]
        self.assertEqual(self.request(ticket_path)[2], b'saved-video')
        with patch('server.time.time', return_value=links[0]['expires']+1):
            self.assertEqual(self.request(ticket_path)[0], 401)
            replacement=link(0)
            self.assertNotEqual(replacement['url'], links[0]['url'])

    def test_unexpected_errors_preserve_diagnostics_without_credentials_in_logs(self):
        secret='sk-proj-'+ 'examplecredential' * 3
        log=io.StringIO()
        with patch.object(self.engine, 'prepare', side_effect=RuntimeError('Upstream HTTP 429; Bearer '+secret)), redirect_stdout(log):
            code, _, raw=self.request('/prepare', {'voice':'af_heart'})
        self.assertEqual(code, 503)
        self.assertIn(b'HTTP 429', raw)
        self.assertNotIn(secret.encode(), raw)
        self.assertNotIn(secret, log.getvalue())

    def test_media_seeks_reject_bad_ranges_without_breaking_playback(self):
        store = self.server.RequestHandlerClass.studio_service.store
        project = store.save(new_project())
        store.asset(project['id'], 'seek.mp4').write_bytes(b'0123456789')
        _, _, body = self.request('/studio/media-link', {'project':project['id'], 'path':'seek.mp4'})
        path = '/studio/media?' + json.loads(body)['url'].split('/studio/media?', 1)[1]
        for value in ('bytes=-', 'bytes=-0', 'bytes=10-', 'bytes=8-2',
                      'bytes=0-1,4-5', 'bytes=' + '9' * 5000 + '-'):
            with self.subTest(value=value[:32]):
                self.assertEqual(self.request(path, extra_headers={'Range':value})[0], 416)
        for value, expected, content_range in (
            ('bytes=2-4', b'234', 'bytes 2-4/10'),
            ('bytes=-3', b'789', 'bytes 7-9/10'),
            ('bytes=7-', b'789', 'bytes 7-9/10'),
            ('bytes=8-99', b'89', 'bytes 8-9/10'),
        ):
            with self.subTest(value=value):
                code, headers, content = self.request(path, extra_headers={'Range':value})
                self.assertEqual((code, content), (206, expected))
                self.assertEqual(headers['Content-Range'], content_range)
        self.assertEqual(self.request(path)[2], b'0123456789')
        self.assertFalse(self.engine.calls)


if __name__ == '__main__':
    unittest.main()
