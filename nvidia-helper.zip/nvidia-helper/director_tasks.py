"""Bounded independent director work; chronological story state stays serial."""
import contextvars
import threading
from collections import deque
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait


def validate_director_result(method, context, result):
    if method=='writeImagePrompt':
        entries=result.get('prompts',[])
        indices=[entry.get('shotIndex') for entry in entries]
        if (any(type(index) is not int for index in indices)
                or sorted(indices)!=list(range(len(context['shots'])))
                or any(not isinstance(entry.get('prompt'),str) or not entry['prompt'].strip() for entry in entries)):
            raise ValueError('Director prompt batch has missing, duplicate or empty shot prompts. '
                'Valid completed stages stay saved; existing shots and manual edits were retained.')
    if method=='selectImageWorkflow':
        matches=[provider for provider in context['available']
            if provider['provider']==result['provider']
            and result['model'] in provider['models']
            and result['workflow'] in provider['workflows']]
        if not matches:
            raise ValueError('Director selected an unavailable image model/workflow. Review settings and retry.')
    return result


def bounded_director_map(items, execute, gate, limit=3):
    """Return input order with a bounded admission window, no automatic retries.

    Each execute callback must own its adapter, budget reservation and journal
    context. After a failure, already submitted work drains for its receipts;
    no new item is admitted. Failed or cancelled work is never silently replayed.
    """
    if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 8:
        raise ValueError('Choose one through eight bounded parallel director calls.')
    iterator = iter(enumerate(items))
    results = {}
    stopped = threading.Event()
    pending = {}
    failure = None
    exhausted = False

    def invoke(index, item):
        try:
            # Copy the trace parent, never share a mutable provider instance.
            gate('Preparing independent director pass')
            if stopped.is_set():
                return None
            return execute(item, stopped)
        except BaseException:
            stopped.set()
            raise

    with ThreadPoolExecutor(max_workers=limit, thread_name_prefix='studio-director') as pool:
        try:
            while pending or not exhausted:
                # Drain and surface all completed errors before admitting more.
                done = [future for future in pending if future.done()]
                for future in done:
                    index = pending.pop(future)
                    try:
                        results[index] = future.result()
                    except BaseException as error:
                        if failure is None:
                            failure = error
                if failure is not None or stopped.is_set():
                    exhausted = True
                while not exhausted and len(pending) < limit:
                    gate('Preparing independent director pass')
                    if stopped.is_set():
                        exhausted = True
                        break
                    try:
                        index, item = next(iterator)
                    except StopIteration:
                        exhausted = True
                        break
                    future = pool.submit(contextvars.copy_context().run, invoke, index, item)
                    pending[future] = index
                if pending:
                    wait(pending, timeout=.1, return_when=FIRST_COMPLETED)
                    # The ordinary gate checks cancellation and pause. Already
                    # paid streams have their separate non-pausing receive gate.
                    gate('Waiting for independent director passes')
        except BaseException as error:
            stopped.set()
            if failure is None:
                failure = error
        finally:
            # Cancel only callbacks that never started. Active callbacks finish
            # or preserve their own UNKNOWN liability on true cancellation.
            for future in pending:
                future.cancel()
            for future, index in pending.items():
                if future.cancelled():
                    continue
                try:
                    results[index] = future.result()
                except BaseException as error:
                    if failure is None:
                        failure = error
    if failure is not None:
        raise failure
    return [results[index] for index in sorted(results)]


def bounded_director_chains(chains, execute, gate, limit=3):
    """Run independent request chains with one bounded shared admission window.

    A generator yields one request and receives its result. A ready continuation
    takes the next free slot before another root; it never occupies a worker
    while waiting for its previous request. Every execute callback owns exactly
    one durable request, using the same stop event for admission and retries.
    """
    if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 8:
        raise ValueError('Choose one through eight bounded parallel director calls.')
    roots=iter(enumerate(chains));ready=deque();opened=[];pending={};results={}
    stopped=threading.Event();failure=None;exhausted=False

    def invoke(item):
        try:
            gate('Preparing independent director pass')
            if stopped.is_set():return None
            return execute(item,stopped)
        except BaseException:
            stopped.set()
            raise

    with ThreadPoolExecutor(max_workers=limit,thread_name_prefix='studio-director-review') as pool:
        try:
            while pending or ready or not exhausted:
                completed=[]
                # Observe every completed failure before advancing any chain.
                for future in [f for f in pending if f.done()]:
                    index,chain=pending.pop(future)
                    try:completed.append((index,chain,future.result()))
                    except BaseException as error:
                        if failure is None:failure=error
                        stopped.set()
                if stopped.is_set():break
                for index,chain,result in completed:
                    try:ready.append((index,chain,chain.send(result)))
                    except StopIteration as finished:results[index]=finished.value
                while len(pending)<limit:
                    gate('Preparing independent director pass')
                    if stopped.is_set():break
                    if ready:index,chain,item=ready.popleft()
                    elif not exhausted:
                        try:index,chain=next(roots)
                        except StopIteration:
                            exhausted=True
                            break
                        opened.append(chain)
                        try:item=next(chain)
                        except StopIteration as finished:
                            results[index]=finished.value
                            continue
                    else:break
                    if stopped.is_set():break
                    future=pool.submit(contextvars.copy_context().run,invoke,item)
                    pending[future]=(index,chain)
                if stopped.is_set():break
                if pending:
                    wait(pending,timeout=.1,return_when=FIRST_COMPLETED)
                    gate('Waiting for independent director passes')
        except BaseException as error:
            stopped.set()
            if failure is None:failure=error
        finally:
            # Close generators only on this caller thread, after paid streams
            # finish. Neither an abandoned chain nor cleanup can buy a stage.
            stopped.set()
            for future in pending:future.cancel()
            for future in pending:
                if future.cancelled():continue
                try:future.result()
                except BaseException as error:
                    if failure is None:failure=error
            for chain in opened:
                try:chain.close()
                except BaseException as error:
                    if failure is None:failure=error
    if failure is not None:raise failure
    return [results[index] for index in sorted(results)]
