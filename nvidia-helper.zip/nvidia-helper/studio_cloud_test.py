import copy, json, tempfile, unittest, hashlib, wave, math, os, subprocess
import threading
from concurrent.futures import ThreadPoolExecutor
from array import array
from unittest.mock import patch
from pathlib import Path
from PIL import Image
from studio_data import ProjectStore,new_project
from studio_storage import R2Archive,sha
from studio_engagement import schedule,ding,audio_signature
from studio_thumbnails import make
from studio_render import VideoRenderer

class Objects:
    def __init__(self):self.data={};self.serial=0;self.fail=False;self.uploads=0
    def read(self,k):return self.data.get(k,(None,None))
    def put_json(self,k,value,etag=None,create=False):
        if create and k in self.data or etag and self.data.get(k,(None,None))[1]!=etag:raise ValueError('Conflict')
        self.serial+=1;self.data[k]=(json.dumps(value).encode(),str(self.serial))
    def upload(self,k,path,checksum):
        if self.fail:raise RuntimeError('secret must not be exposed')
        assert sha(path)==checksum
        self.data[k]=(path.read_bytes(),'asset');self.uploads+=1
    def download(self,k,path):path.write_bytes(self.data[k][0])
    def keys(self,prefix):return [k for k in self.data if k.startswith(prefix)]
    def url(self,k):return 'https://private.example/'+k

class CloudSaveTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.store=ProjectStore(self.tmp.name)
        self.p=self.store.save(new_project('Cloud story'));self.obj=Objects()
        self.a=R2Archive(self.store,Path(self.tmp.name)/'absent');self.a.close()
        self.a.objects=self.obj;self.a.enabled=True;self.store.archive=self.a
        self.image=self.store.folder(self.p['id'])/'art.png';Image.new('RGB',(640,360),'purple').save(self.image)
    def tearDown(self):self.tmp.cleanup()
    def test_retry_clears_stale_error_but_retains_failure_history(self):
        self.a.states[self.p['id']]={'status':'FAILED','error':'previous upload failed','revision':3}
        self.a.enqueue(self.p['id'])
        result=self.a.status()['projects'][self.p['id']]
        self.assertEqual(result['error'],'');self.assertEqual(result['status'],'PENDING')
        self.assertEqual(result['revision'],3)
        self.assertEqual(result['errorHistory'][0]['message'],'previous upload failed')
    def test_edit_during_upload_preserves_active_status_and_progress(self):
        self.a.active_project=self.p['id']
        self.a.states[self.p['id']]={'status':'UPLOADING'}
        self.a.enqueue(self.p['id'])
        self.assertEqual(self.a.status()['projects'][self.p['id']]['status'],'UPLOADING')
        self.assertIn(self.p['id'],self.a.pending)
        self.obj.fail=True
        with self.assertRaises(RuntimeError):self.a.sync(self.p['id'])
        progress=self.a.status()['projects'][self.p['id']]['syncProgress']
        self.assertEqual(progress['totalFiles'],1)
        self.assertEqual(progress['filesProcessed'],0)
        self.assertEqual(progress['uploadedBytes'],0)
    def test_derived_encode_caches_are_not_uploaded_but_referenced_exports_are(self):
        scratch='clip-'+'a'*24+'.mp4'
        final='story-'+'b'*12+'.mp4'
        self.store.asset(self.p['id'],scratch).write_bytes(b'rebuildable cache')
        self.store.asset(self.p['id'],final).write_bytes(b'final export')
        self.a.sync(self.p['id'])
        manifest,_=self.a.manifest(self.p['id'],True)
        self.assertNotIn(scratch,manifest['files'])
        self.assertIn(final,manifest['files'])
        self.assertTrue(self.store.asset(self.p['id'],scratch).is_file())
        self.store.mutate(self.p['id'],lambda p:p.update(render={'path':scratch}))
        self.a.sync(self.p['id'])
        manifest,_=self.a.manifest(self.p['id'],True)
        self.assertIn(scratch,manifest['files'])
        self.store.mutate(self.p['id'],lambda p:p.update(render={}))
        self.a.sync(self.p['id'])
        manifest,_=self.a.manifest(self.p['id'],True)
        self.assertIn(scratch,manifest['files']) # Previously saved copies survive.
    def test_cloud_presence_and_identity_checks_never_restore_media_to_laptop(self):
        from studio_qc import asset_hash
        original=sha(self.image);self.a.sync(self.p['id']);self.image.unlink()
        with patch.object(self.obj,'download',side_effect=AssertionError('Metadata check downloaded media')):
            self.assertTrue(self.store.has_asset(self.p['id'],'art.png'))
            self.assertEqual(self.store.asset_digest(self.p['id'],'art.png'),original)
            self.assertEqual(asset_hash(self.store,self.p['id'],'art.png'),original)
            self.assertFalse(self.store.has_asset(self.p['id'],'missing.png'))
            self.assertIsNone(self.store.asset_digest(self.p['id'],'missing.png'))
        self.assertFalse(self.image.exists())
        # A local replacement takes priority over an older cloud fingerprint.
        self.image.write_bytes(b'new local image')
        self.assertEqual(self.store.asset_digest(self.p['id'],'art.png'),sha(self.image))
        self.assertNotEqual(sha(self.image),original)

    def test_cloud_presence_rejects_invalid_manifest_identity_and_unsafe_paths(self):
        self.a.sync(self.p['id']);self.image.unlink()
        manifest,_=self.a.manifest(self.p['id']);original=copy.deepcopy(manifest['files']['art.png'])
        for patch_value in ({'key':'other-account/object'},{'sha256':'bad'},{'bytes':True},{'bytes':-1}):
            manifest['files']['art.png']=original|patch_value
            with self.assertRaises(ValueError):self.store.has_asset(self.p['id'],'art.png')
        manifest['files']['art.png']=original
        with self.assertRaises(ValueError):self.store.has_asset(self.p['id'],'../outside.png')
        # Metadata availability does not disable checksum verification on a real read.
        key=original['key'];self.obj.data[key]=(b'corrupt remote bytes','asset')
        with self.assertRaises(ValueError):self.store.asset(self.p['id'],'art.png')
        self.assertFalse(self.image.exists())

    def test_cloud_render_reuse_index_survives_a_regular_project_save(self):
        self.a.sync(self.p['id'])
        key='studio/manifests/'+self.p['id']+'.json'
        manifest,etag=self.a.manifest(self.p['id'],True)
        manifest['renderCache']={'chapter-cached.mp4':{'path':'cloud-renders/old/chapter.mp4','sha256':'a'*64,'bytes':123}}
        self.obj.put_json(key,manifest,etag)
        self.a.manifests.pop(self.p['id'],None)
        self.store.mutate(self.p['id'],lambda p:p.update(name='Changed title'))
        self.a.sync(self.p['id'])
        updated,_=self.a.manifest(self.p['id'],True)
        self.assertEqual(updated['renderCache'],manifest['renderCache'])
        self.assertEqual(updated['project']['name'],'Changed title')

    def test_missing_cloud_saved_at_repairs_metadata_without_reuploading_media(self):
        self.a.sync(self.p['id']);uploads=self.obj.uploads
        key='studio/manifests/'+self.p['id']+'.json'
        manifest,etag=self.a.manifest(self.p['id'],True);manifest.pop('savedAt')
        self.obj.put_json(key,manifest,etag);self.a.manifests.pop(self.p['id'],None)
        self.assertTrue(self.a.sync(self.p['id']))
        current,_=self.a.manifest(self.p['id'],True)
        self.assertGreater(current['savedAt'],0)
        self.assertEqual(self.obj.uploads,uploads)
        self.assertEqual(current['project'],manifest['project'])

    def test_uploads_before_manifest_and_does_not_repeat_unchanged_assets(self):
        self.a.sync(self.p['id']);n=self.obj.uploads
        self.a.sync(self.p['id']);self.assertEqual(self.obj.uploads,n)
        self.assertTrue(self.image.exists());self.assertEqual(self.a.status()['projects'][self.p['id']]['status'],'SYNCED')
        self.assertEqual(self.a.files(self.p['id'])['files'][0]['sha256'],sha(self.image))

    def test_atomic_asset_replacement_with_same_size_and_mtime_is_not_skipped(self):
        target=self.store.asset(self.p['id'], 'state.json');target.write_text('{"value":1}')
        self.a.sync(self.p['id']);original=target.stat()
        replacement=target.with_suffix('.writing.json');replacement.write_text('{"value":2}')
        os.utime(replacement, ns=(original.st_atime_ns, original.st_mtime_ns))
        replacement.replace(target)
        self.assertEqual(target.stat().st_size,original.st_size)
        self.assertEqual(target.stat().st_mtime_ns,original.st_mtime_ns)
        self.a.sync(self.p['id'])
        manifest,_=self.a.manifest(self.p['id'],True)
        self.assertEqual(manifest['files']['state.json']['sha256'],sha(target))
        self.assertEqual(self.obj.data[manifest['files']['state.json']['key']][0],b'{"value":2}')

    def test_failed_thumbnail_encoding_preserves_completed_thumbnail_and_leaves_no_partial(self):
        options={'source':'art.png','title':'Story','part':'1'}
        asset=make(self.store,self.p['id'],options)
        target=self.store.asset(self.p['id'],asset['path']);before=target.read_bytes()
        def fail(image,filename,*args,**kwargs):
            Path(filename).write_bytes(b'partial-jpeg')
            raise OSError('Simulated encoder failure')
        with patch.object(Image.Image,'save',fail), self.assertRaises(OSError):
            make(self.store,self.p['id'],options)
        self.assertEqual(target.read_bytes(),before)
        self.assertEqual(list(target.parent.glob('*.writing.*')),[])
    def test_failed_upload_leaves_previous_cloud_snapshot_and_local_edits(self):
        self.a.sync(self.p['id']);key='studio/manifests/'+self.p['id']+'.json';old=self.obj.data[key]
        self.store.mutate(self.p['id'],lambda p:p.update(name='Keep me'))
        Image.new('RGB',(640,360),'red').save(self.image);self.obj.fail=True
        with self.assertRaises(RuntimeError):self.a.sync(self.p['id'])
        self.assertEqual(self.obj.data[key],old);self.assertEqual(self.store.load(self.p['id'])['name'],'Keep me')

    def test_slow_cloud_publication_does_not_block_local_edits_and_requeues_new_revision(self):
        entered=threading.Event();release=threading.Event();original=self.obj.put_json
        def slow(key,*args,**kwargs):
            if key.startswith('studio/manifests/'):
                entered.set()
                if not release.wait(5):raise TimeoutError('Test network not released')
            return original(key,*args,**kwargs)
        self.obj.put_json=slow
        with ThreadPoolExecutor(2) as pool:
            sync=pool.submit(self.a.sync,self.p['id'])
            try:
                self.assertTrue(entered.wait(5))
                edit=pool.submit(self.store.mutate,self.p['id'],lambda p:p.update(name='New local revision'))
                edit.result(timeout=1)
            finally:release.set()
            self.assertFalse(sync.result(timeout=5))
        self.assertEqual(self.store.load_local(self.p['id'])['name'],'New local revision')
        self.assertEqual(self.a.status()['projects'][self.p['id']]['status'],'PENDING')
        self.assertIn(self.p['id'],self.a.pending)
        self.obj.put_json=original;self.a.sync(self.p['id'])
        manifest,_=self.a.manifest(self.p['id'],True)
        self.assertEqual(manifest['project']['name'],'New local revision')
        self.assertEqual(self.a.status()['projects'][self.p['id']]['status'],'SYNCED')
    def test_dashboard_preserves_pending_files_and_does_not_label_local_edits_cloud_saved(self):
        before={r['path']:r for r in self.a.files(self.p['id'])['files']}
        self.assertIn('art.png',before);self.assertFalse(before['art.png']['cloud'])
        self.a.sync(self.p['id'])
        Image.new('RGB',(640,360),'red').save(self.image)
        added=self.store.folder(self.p['id'])/'new.wav';added.write_bytes(b'new pending narration')
        hidden=self.store.folder(self.p['id'])/'working';hidden.mkdir();(hidden/'private.json').write_text('{}')
        pending={r['path']:r for r in self.a.files(self.p['id'])['files']}
        self.assertFalse(pending['art.png']['cloud']);self.assertFalse(pending['new.wav']['cloud'])
        self.assertNotIn('working/private.json',pending)
        self.a.sync(self.p['id'])
        self.assertTrue(all(r['cloud'] for r in self.a.files(self.p['id'])['files']))
    def test_restore_rejects_newer_local_work_and_recovers_missing_asset(self):
        self.a.sync(self.p['id']);expected=self.image.read_bytes();self.image.unlink()
        self.assertEqual(self.store.asset(self.p['id'],'art.png').read_bytes(),expected)
        self.store.mutate(self.p['id'],lambda p:p.update(name='Newer'))
        with self.assertRaisesRegex(ValueError,'Both copies retained'):self.a.restore(self.p['id'])
    def test_divergent_helpers_preserve_both_editions_regardless_of_revision_order(self):
        pid=self.p['id']
        self.a.sync(pid)
        with tempfile.TemporaryDirectory() as folder:
            other_store=ProjectStore(folder)
            other=R2Archive(other_store,Path(folder)/'no-config',self.obj,start_worker=False)
            base=other_store.load(pid)
            chosen=self.store.mutate(pid,lambda p:p.update(notes='Chosen independently on A'))
            self.a.sync(pid)
            other_store.mutate(pid,lambda p:p['chapters'][0].update(name='B chapter'))
            local=other_store.mutate(pid,lambda p:p['chapters'][0].update(sourceText='Unsynchronized B text'))
            self.assertLess(base['revision'], chosen['revision'])
            self.assertGreater(local['revision'], chosen['revision'])
            # Reopen B with its durable acknowledgement, as after a helper restart.
            other=R2Archive(other_store,Path(folder)/'no-config',self.obj,start_worker=False)
            with self.assertRaisesRegex(ValueError,'conflict'):
                other.sync(pid)
            self.assertEqual(other.manifest(pid,True)[0]['project'],chosen)
            self.store.mutate(pid,lambda p:p.update(name='A project'))
            cloud=self.store.mutate(pid,lambda p:p.update(notes='Another A edit'))
            self.a.sync(pid)
            self.assertGreater(cloud['revision'],local['revision'])
            with self.assertRaisesRegex(ValueError,'conflict'):
                other.restore(pid)
            self.assertEqual(other_store.load_local(pid),local)
            self.assertEqual(other.manifest(pid,True)[0]['project'],cloud)

    def test_preupgrade_sync_journal_detects_remote_advance_and_allows_ordinary_local_save(self):
        pid=self.p['id']
        self.a.sync(pid)
        self.a.states[pid].pop('sharedProjectSHA256')
        self.store.mutate(pid,lambda p:p.update(name='Normal local edit'))
        self.assertTrue(self.a.sync(pid))
        state=self.a.states[pid];state.pop('sharedProjectSHA256')
        base,etag=self.a.manifest(pid,True)
        foreign=copy.deepcopy(base);foreign['project']['revision']+=1;foreign['project']['notes']='Cloud edition'
        self.obj.put_json(f'studio/manifests/{pid}.json',foreign,etag=etag)
        self.store.mutate(pid,lambda p:p.update(name='Offline A'))
        self.store.mutate(pid,lambda p:p.update(notes='Offline B'))
        with self.assertRaisesRegex(ValueError,'conflict'):self.a.sync(pid)
        self.assertEqual(self.a.manifest(pid,True)[0]['project'],foreign['project'])

    def test_complete_restart_restores_project_from_cloud(self):
        self.a.sync(self.p['id'])
        with tempfile.TemporaryDirectory() as new:
            store=ProjectStore(new);a=R2Archive(store,Path(new)/'absent');a.close();a.enabled=True;a.objects=self.obj;store.archive=a
            p=store.load(self.p['id']);self.assertEqual(p['name'],'Cloud story')
            self.assertEqual(sha(store.asset(p['id'],'art.png')),sha(self.image))
    def test_thumbnail_has_part_badge_and_is_under_youtube_limit(self):
        asset=make(self.store,self.p['id'],{'source':'art.png','title':'The return of magic','part':'1–6'})
        path=self.store.asset(self.p['id'],asset['path'])
        with Image.open(path) as img:self.assertEqual(img.size,(1280,720));self.assertGreater(img.getpixel((38,55))[0],180)
        self.assertLess(path.stat().st_size,2_000_000)
    def test_parallel_asset_requests_restore_once_without_overwriting_each_other(self):
        self.a.sync(self.p['id']);expected=self.image.read_bytes();self.image.unlink()
        entered=threading.Event();release=threading.Event();downloads=[]
        original=self.obj.download
        def delayed(key,path):
            downloads.append(key);entered.set()
            if not release.wait(5):raise RuntimeError('Test release timed out')
            original(key,path)
        self.obj.download=delayed
        with ThreadPoolExecutor(2) as pool:
            first=pool.submit(self.a.fetch_asset,self.p['id'],'art.png')
            self.assertTrue(entered.wait(5))
            second=pool.submit(self.a.fetch_asset,self.p['id'],'art.png')
            release.set()
            for request in (first,second):self.assertEqual(request.result(timeout=5).read_bytes(),expected)
        self.assertEqual(len(downloads),1)
    def test_asset_record_must_match_exact_path_not_only_project_hash_prefix(self):
        self.a.sync(self.p['id']);self.image.unlink()
        manifest,etag=self.a.manifest(self.p['id'])
        manifest['files']['art.png']['key']=manifest['files']['art.png']['key'].replace('art.png','other.png')
        with self.assertRaisesRegex(ValueError,'Invalid cloud asset identity'):self.a.fetch_asset(self.p['id'],'art.png')
        with self.assertRaisesRegex(ValueError,'Invalid cloud asset identity'):self.a.media_url(self.p['id'],'art.png')
    def test_project_catalogue_reuses_reads_and_returns_independent_values(self):
        self.a.sync(self.p['id']);calls=[];original=self.obj.keys
        def keys(prefix):calls.append(prefix);return original(prefix)
        self.obj.keys=keys
        first=self.a.list_projects();first[0]['name']='Do not leak edits'
        self.assertEqual(self.a.list_projects()[0]['name'],'Cloud story');self.assertEqual(len(calls),1)
        self.store.mutate(self.p['id'],lambda p:p.update(name='Changed'));self.a.sync(self.p['id'])
        self.assertEqual(self.a.list_projects()[0]['name'],'Changed');self.assertEqual(len(calls),2)

    def test_cold_catalogue_reads_overlap_with_four_bounded_slots_and_no_media_restore(self):
        projects=[new_project('Remote story') for _ in range(8)]
        for p in projects:self.obj.put_json(f'studio/manifests/{p["id"]}.json',{'project':p})
        original=self.obj.read;lock=threading.Lock();entered=threading.Event();release=threading.Event()
        active=peak=0
        def read(key):
            nonlocal active,peak
            with lock:
                active+=1;peak=max(peak,active)
                if active==4:entered.set()
            try:
                if not release.wait(5):raise AssertionError('Catalogue did not overlap reads')
                return original(key)
            finally:
                with lock:active-=1
        self.obj.read=read
        with ThreadPoolExecutor(1) as pool:
            request=pool.submit(self.a.list_projects)
            try:self.assertTrue(entered.wait(3))
            finally:release.set()
            rows=request.result(timeout=5)
        self.assertEqual(peak,4);self.assertEqual({r['id'] for r in rows},{p['id'] for p in projects})
        self.assertEqual(self.a.manifests,{})
        self.assertFalse(any((self.store.root/p['id']).exists() for p in projects))

    def test_one_bad_cloud_manifest_does_not_hide_other_projects_or_expose_sdk_details(self):
        self.a.sync(self.p['id'])
        bad=new_project('Damaged');key=f'studio/manifests/{bad["id"]}.json'
        self.obj.data[key]=(b'not JSON','1')
        self.obj.data['studio/manifests/invalid-id.json']=(b'not JSON','1')
        rows=self.a.list_projects()
        self.assertEqual(len(rows),2)
        self.assertEqual(next(r for r in rows if r['id']==self.p['id'])['name'],'Cloud story')
        self.assertIn('loadError',next(r for r in rows if r['id']==bad['id']))
        self.assertEqual(self.obj.data[key][0],b'not JSON')

    def test_sync_cannot_lose_catalogue_invalidation_to_an_inflight_old_listing(self):
        self.a.sync(self.p['id']);old=self.a.list_projects();self.a.catalogue_at=0
        entered=threading.Event();release=threading.Event();published=threading.Event()
        def held():
            entered.set()
            if not release.wait(5):raise AssertionError('Listing was not released')
            return old
        original=self.obj.put_json
        def put(key,*args,**kwargs):
            original(key,*args,**kwargs)
            if key==f'studio/manifests/{self.p["id"]}.json':published.set()
        self.obj.put_json=put
        with patch.object(self.a,'_list_projects',side_effect=held),ThreadPoolExecutor(2) as pool:
            listing=pool.submit(self.a.list_projects)
            try:
                self.assertTrue(entered.wait(3))
                self.store.mutate(self.p['id'],lambda p:p.update(name='Latest cloud name'))
                sync=pool.submit(self.a.sync,self.p['id'])
                self.assertTrue(published.wait(3))
            finally:release.set()
            listing.result(timeout=5);self.assertTrue(sync.result(timeout=5))
        self.assertEqual(self.a.catalogue_at,0)
        self.assertEqual(self.a.list_projects()[0]['name'],'Latest cloud name')

class EngagementTests(unittest.TestCase):
    def test_reminders_stable_across_outro_asset_and_thumbnail_changes(self):
        p=new_project();p['settings']['engagement']['popupEnabled']=True
        first=schedule(p,7200);self.assertGreater(len(first),5)
        previous=0
        for e in first:self.assertTrue(599<=e['start']-previous<=901);previous=e['start']
        p['settings']['engagement']['outroAudioPath']='outro.wav';p['thumbnails']=[{'path':'x.jpg'}]
        self.assertEqual(first,schedule(p,7200))
    def test_ding_volume_is_bounded(self):
        with tempfile.TemporaryDirectory() as tmp:
            target=Path(tmp)/'ding.opus';ding(target,.12)
            decoded=subprocess.run(['ffmpeg','-v','error','-i',str(target),'-f','s16le',
                '-ac','1','-ar','24000','pipe:1'],capture_output=True,check=True).stdout
            x=array('h',decoded)
            self.assertEqual(len(x),14400)
            self.assertLessEqual(max(abs(v) for v in x),32767*.12)

@unittest.skipUnless(os.environ.get('STUDIO_TEST_FFMPEG'),'Set STUDIO_TEST_FFMPEG for the real render test')
class RenderIntegrationTests(unittest.TestCase):
    def test_sixty_fps_reminder_ding_outro_and_safe_video_parts(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=ProjectStore(tmp);p=store.save(new_project());p['settings']['video'].update(width=640,height=360,fps=60)
            p['settings']['engagement'].update(popupEnabled=True,minMinutes=1,maxMinutes=1,outroEnabled=True,outroAudioPath='outro.wav',outroDuration=5)
            p['settings']['engagement']['outroAudioSignature']=audio_signature(p)
            p['settings']['watermark']={'enabled':True,'type':'text','text':'Studio'}
            folder=store.folder(p['id']);audio=folder/'outro.wav'
            with wave.open(str(audio),'wb') as wav:
                tone=array('h',(round(8000*math.sin(2*math.pi*800*i/24000)) for i in range(24000)))
                wav.setparams((1,2,24000,0,'NONE','not compressed'));wav.writeframes(tone.tobytes())
            before=sha(audio);r=VideoRenderer(store,{'ffmpeg':os.environ['STUDIO_TEST_FFMPEG']})
            gate=lambda *a:None
            source=folder/'source.mp4'
            r.run(['-f','lavfi','-i','color=c=purple:s=640x360:r=60:d=70','-f','lavfi','-i','sine=frequency=200:sample_rate=48000:duration=70',*r.encoding(p),'-g','120','-c:a','aac','-ac','2','-shortest',str(source)],gate,folder/'fixture.log')
            base={'path':source.name,'duration':70,'signature':'fixture'}
            original=sha(source)
            result=r.engagement_export(p,base,gate)
            self.assertEqual(result['duration'],75);self.assertEqual(len(result['engagementEvents']),1);self.assertEqual(sha(audio),before)
            self.assertEqual(len(list(folder.glob('watermarked-*.mp4'))),0)
            self.assertTrue(result['watermarkIdentity']['settings']['enabled'])
            target=store.asset(p['id'],result['path'])
            self.assertEqual(r.engagement_export(p,base,gate)['path'],result['path'])
            self.assertEqual(sha(source),original)
            parts=r.split_export(p,result,gate,1);self.assertEqual(len(parts),2)
            self.assertAlmostEqual(sum(x['duration'] for x in parts),75,delta=.2)
            for part in parts:self.assertTrue(store.asset(p['id'],part['path']).is_file())
            decoded=subprocess.run([r.executable(),'-hide_banner','-xerror','-i',str(target),'-f','null','-'],check=True,capture_output=True)
            self.assertIn('60 fps',decoded.stderr.decode(errors='replace'))
            ending=subprocess.check_output([r.executable(),'-v','error','-xerror','-ss','70.25','-i',str(target),
                '-map','0:a:0','-t','0.5','-ac','1','-ar','24000','-f','s16le','pipe:1'])
            samples=array('h',ending)
            self.assertEqual(len(samples),12000)
            self.assertGreater(max(samples),4000)

    def test_outro_reuses_legacy_lossless_story_audio(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=ProjectStore(tmp);p=store.save(new_project())
            p['settings']['video'].update(width=640,height=360,fps=30)
            p['settings']['watermark']={'enabled':False}
            p['settings']['engagement'].update(outroEnabled=True,outroAudioPath='outro.wav',outroDuration=5)
            p['settings']['engagement']['outroAudioSignature']=audio_signature(p)
            folder=store.folder(p['id']);audio=folder/'outro.wav';source=folder/'story.mp4'
            r=VideoRenderer(store,{'ffmpeg':os.environ['STUDIO_TEST_FFMPEG']})
            gate=lambda *a:None
            r.run(['-f','lavfi','-i','sine=frequency=800:sample_rate=24000:duration=1',str(audio)],
                  gate,folder/'outro-fixture.log')
            r.run(['-f','lavfi','-i','color=c=blue:s=640x360:r=30:d=2','-f','lavfi','-i',
                   'sine=frequency=200:sample_rate=44100:duration=2',*r.encoding(p),'-c:a','alac',
                   str(source)],gate,folder/'story-fixture.log')
            original=sha(source);spoken=sha(audio)
            result=r.engagement_export(p,{'path':source.name,'duration':2,'signature':'fixture'},gate)
            target=folder/result['path']
            self.assertEqual(result['duration'],7)
            self.assertEqual((sha(source),sha(audio)),(original,spoken))
            subprocess.run([r.executable(),'-v','error','-xerror','-i',str(target),'-f','null','-'],
                           capture_output=True,check=True)
            for timestamp in ('1.7','2.2'):
                raw=subprocess.check_output([r.executable(),'-v','error','-xerror','-ss',timestamp,'-i',str(target),
                    '-map','0:a:0','-t','0.2','-ac','1','-ar','24000','-f','s16le','pipe:1'])
                samples=array('h',raw)
                self.assertEqual(len(samples),4800)
                self.assertGreater(max(samples),2000)

if __name__=='__main__':unittest.main()
