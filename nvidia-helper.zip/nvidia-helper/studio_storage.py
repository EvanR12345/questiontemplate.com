"""Private R2 archives, immutable assets, atomic manifests and recoverable sync.

The helper's folders remain a working cache. No file is deleted by this module.
Secrets never enter project exports, health responses or signed URL reports.
"""
import copy
import hashlib
import json
import math
import mimetypes
import os
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
from pathlib import Path
from studio_data import digest
from urllib.parse import quote
from immutable_upload import frozen_body, SourceChangedAfterUpload

MEDIA = {'.png', '.jpg', '.jpeg', '.webp', '.wav', '.m4a', '.opus', '.mp3', '.mp4', '.json', '.flac'}

def local_media(folder):
    """Prune excluded working/private trees before visiting their contents."""
    def excluded(name):
        return name.startswith('.') or name=='working' or '.writing.' in name or '.partial.' in name
    def scan_error(error):
        # A denied/unreadable folder must not become a successful partial sync.
        raise error
    for root, directories, filenames in os.walk(folder, followlinks=False, onerror=scan_error):
        parent=Path(root)
        directories[:]=[name for name in directories if not excluded(name) and not (parent/name).is_symlink()]
        for name in filenames:
            if excluded(name) or Path(name).suffix.lower() not in MEDIA:continue
            path=parent/name
            if not path.is_symlink() and path.is_file():yield path

def project_video_paths(project):
    paths=set()
    def visit(value):
        if isinstance(value,str):
            if len(value)<512 and value.lower().endswith('.mp4'):paths.add(value.replace('\\','/'))
        elif isinstance(value,dict):
            for child in value.values():visit(child)
        elif isinstance(value,list):
            for child in value:visit(child)
    visit(project)
    return paths

def render_scratch(project, relative, references):
    """Rebuildable, unreferenced encode caches; never originals or exports.

    Existing cloud copies remain in history. This only avoids new uploads of
    derived caches; final/chapter/part videos and any referenced asset stay saved.
    """
    if project.get('settings',{}).get('archiveRenderCache'):return False
    name=Path(relative).name
    if not re.fullmatch(r'(?:clip-[a-f0-9]{24}|intro-shot-[a-f0-9]{20}|intro-montage-[a-f0-9]{12}|story-[a-f0-9]{12}-visual)\.mp4',name):return False
    return relative not in references

def attachment_disposition(name):
    if not isinstance(name,str) or not name or len(name)>240 or any(ord(c)<32 or ord(c)==127 for c in name) or any(c in name for c in '\\/:') or name in ('.','..'):
        raise ValueError('Enter a plain download filename without folders or control characters.')
    fallback=re.sub(r'[^a-zA-Z0-9 ._-]','_',name)
    return 'attachment; filename="'+fallback+'"; filename*=UTF-8\'\''+quote(name,safe='')

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(4*1024*1024), b''): h.update(b)
    return h.hexdigest()

def stable_file(path):
    stat = path.stat()
    return (stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns)

def stage_immutable_assets(objects, pid, folder, paths, records, validate_path,
                           progress=lambda *_:None, workers=1, cancelled=lambda:False):
    """Transfer bounded immutable assets; the caller alone publishes a manifest.

    Successful records remain private until every admitted transfer finishes.
    Failure cancels pending work and joins active transfers before returning.
    No file body is retained in memory and input records are never mutated.
    """
    if type(workers) is not int or not 1<=workers<=4:
        raise ValueError('Archive upload workers must be an integer from 1 to 4.')
    paths=list(paths);folder=Path(folder)
    tasks=[]
    for path in paths:
        relative=path.relative_to(folder).as_posix()
        validate_path(relative)
        tasks.append((path,relative,records.get(relative,{})))
    def check_cancelled():
        if cancelled():raise RuntimeError('Cloud archive stopped; previous snapshot and local files retained.')
    def one(task):
        check_cancelled()
        path,relative,previous=task
        before=stable_file(path)
        if previous.get('stamp')==list(before):return relative,previous,0
        checksum=sha(path)
        if stable_file(path)!=before:raise ValueError('An asset changed during upload preparation. Retry safely.')
        check_cancelled()
        key=f'studio/assets/{pid}/{checksum}/{relative}'
        uploaded=0;receipt=None
        if previous.get('sha256')!=checksum:
            receipt=objects.upload(key,path,checksum);uploaded=before[0]
        try:changed=stable_file(path)!=before
        except FileNotFoundError:changed=True
        if changed:raise SourceChangedAfterUpload(receipt)
        return relative,{'key':key,'sha256':checksum,'bytes':before[0],'stamp':list(before)},uploaded
    check_cancelled();completed={};uploaded=0
    progress(0,len(tasks),0)
    if workers==1:
        for index,task in enumerate(tasks):
            check_cancelled();completed[index]=one(task)
            uploaded+=completed[index][2];progress(index+1,len(tasks),uploaded)
    else:
        pool=ThreadPoolExecutor(max_workers=workers,thread_name_prefix='studio-cloud-asset')
        pending={};next_index=0
        try:
            while next_index<len(tasks) or pending:
                check_cancelled()
                while next_index<len(tasks) and len(pending)<workers:
                    check_cancelled();future=pool.submit(one,tasks[next_index])
                    pending[future]=next_index;next_index+=1
                done,_=wait(pending,return_when=FIRST_COMPLETED)
                # Resolve the entire completion set before admitting more work;
                # a failed transfer cannot cause an avoidable additional submit.
                ready=[(pending[f],f.result()) for f in sorted(done,key=lambda f:pending[f])]
                for index,value in ready:
                    completed[index]=value;uploaded+=value[2]
                for future in done:del pending[future]
                progress(len(completed),len(tasks),uploaded)
        except BaseException:
            for future in pending:future.cancel()
            raise
        finally:
            pool.shutdown(wait=True,cancel_futures=True)
    check_cancelled()
    staged=dict(records)
    for index in range(len(tasks)):
        relative,record,_=completed[index];staged[relative]=record
    return staged,uploaded

class S3Objects:
    provider = 'Cloudflare R2'
    publisher_compatible = True
    def __init__(self, config):
        import boto3
        from botocore.config import Config
        if not re.fullmatch(r'[a-f0-9]{32}', config.get('accountId', '')):
            raise ValueError('Enter a valid Cloudflare account ID.')
        if not re.fullmatch(r'[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]', config.get('bucket', '')):
            raise ValueError('Enter a valid private bucket name.')
        self.bucket = config['bucket']
        self.client = boto3.client('s3', endpoint_url=f"https://{config['accountId']}.r2.cloudflarestorage.com",
            aws_access_key_id=config['accessKeyId'], aws_secret_access_key=config['secretAccessKey'],
            region_name='auto', config=Config(signature_version='s3v4', retries={'max_attempts':4,'mode':'standard'},
                connect_timeout=10, read_timeout=60, request_checksum_calculation='when_required',
                response_checksum_validation='when_required'))

    def read(self, key):
        try:
            r = self.client.get_object(Bucket=self.bucket, Key=key)
            try: return r['Body'].read(), r['ETag']
            finally: r['Body'].close()
        except self.client.exceptions.NoSuchKey: return None, None

    def put_json(self, key, value, etag=None, create=False):
        args = {'Bucket':self.bucket,'Key':key,'Body':json.dumps(value,ensure_ascii=False,separators=(',',':')).encode(),
                'ContentType':'application/json'}
        if etag: args['IfMatch'] = etag
        elif create: args['IfNoneMatch'] = '*'
        self.client.put_object(**args)

    def upload(self, key, path, checksum):
        # The complete body and checksum are fixed before the SDK sees a file.
        # Local atomic ledger replacements cannot change this transfer's bytes.
        path=Path(path)
        with frozen_body(path, checksum) as (snapshot, size):
            return self.upload_frozen(key, snapshot, size, checksum, path.name)

    def upload_frozen(self, key, snapshot, size, checksum, original_name):
        from boto3.s3.transfer import TransferConfig
        snapshot.seek(0)
        self.client.upload_fileobj(snapshot, self.bucket, key,
            ExtraArgs={'ContentType':mimetypes.guess_type(original_name)[0] or 'application/octet-stream',
                       'Metadata':{'sha256':checksum}},
            Config=TransferConfig(multipart_threshold=64*1024*1024,multipart_chunksize=64*1024*1024,max_concurrency=3))
        head = self.client.head_object(Bucket=self.bucket,Key=key)
        if head['ContentLength'] != size or head.get('Metadata',{}).get('sha256') != checksum:
            raise ValueError('Cloud upload verification failed; local file retained.')
        # This post-transfer HEAD verifies bytes/metadata; it is deliberately
        # not labelled a native writer-generation/ownership receipt.
        return {'bytes':size, 'sha256':checksum, 'writerOwnershipVerified':False}

    def download(self, key, target):
        self.client.download_file(self.bucket, key, str(target))

    def open_object(self, key):
        """Streaming migration source: never creates a laptop download file."""
        r = self.client.get_object(Bucket=self.bucket, Key=key)
        return {'body':r['Body'], 'bytes':r['ContentLength'], 'etag':r['ETag'],
                'contentType':r.get('ContentType', 'application/octet-stream')}

    def keys(self, prefix):
        for page in self.client.get_paginator('list_objects_v2').paginate(Bucket=self.bucket,Prefix=prefix):
            for x in page.get('Contents',[]): yield x['Key']

    def url(self, key, download_name=None):
        params={'Bucket':self.bucket,'Key':key}
        if download_name is not None:params['ResponseContentDisposition']=attachment_disposition(download_name)
        return self.client.generate_presigned_url('get_object',Params=params,ExpiresIn=3600)

class R2Archive:
    def __init__(self, store, secret_path, objects=None, start_worker=True):
        self.store = store; self.secret_path = Path(secret_path)
        self.state_path = store.root / 'cloud-sync.json'
        self.cv = threading.Condition(threading.RLock()); self.stopped = False
        self.pending = set(); self.states = {}; self.objects = objects
        self.active_project = None
        self.configuration_error='';self.journal_error=''
        if self.state_path.exists():
            try:self.states = json.loads(self.state_path.read_text(encoding='utf-8'))
            except (OSError,ValueError):self.journal_error='Cloud status journal could not be read. Local project data is unchanged; retry cloud save.'
        requested_provider = 'r2'
        if self.objects is None and self.secret_path.exists():
            try:
                config = json.loads(self.secret_path.read_text(encoding='utf-8'))
                requested_provider = config.get('provider', 'r2')
                if config.get('provider', 'r2') == 'gcs':
                    from google_storage import GCSObjects
                    self.objects = GCSObjects(config)
                elif config.get('provider', 'r2') == 'r2':self.objects = S3Objects(config)
                else:raise ValueError('Unsupported storage provider.')
            except Exception:self.configuration_error='Cloud storage configuration is unavailable. Local audio and projects remain usable; check the private storage credentials and SDK.'
        self.provider = getattr(self.objects, 'provider', 'Google Cloud Storage' if requested_provider == 'gcs' else 'Cloudflare R2')
        self.publisher_compatible = getattr(self.objects, 'publisher_compatible', requested_provider == 'r2')
        if self.provider == 'Google Cloud Storage':
            # Never display old R2 synchronization results as Google uploads.
            self.state_path = store.root / 'cloud-sync-gcs.json'
            self.states = {};self.journal_error = ''
            if self.state_path.exists():
                try:self.states = json.loads(self.state_path.read_text(encoding='utf-8'))
                except (OSError,ValueError):self.journal_error='Cloud status journal could not be read. Retry cloud save.'
        self.enabled = self.objects is not None
        self.manifests = {}
        # Completed immutable transfers can outlive a superseded project
        # snapshot. Reuse their verified file stamps on the next sync without
        # publishing the old project or repeating hashes/remote existence reads.
        # Private, bounded metadata only; every file still passes stable_file.
        self.staged_assets = {}
        self.asset_locks = [threading.RLock() for _ in range(32)]
        self.catalogue_lock = threading.RLock()
        self.catalogue = None; self.catalogue_at = 0
        if self.enabled:
            store.archive = self
            if start_worker:
                for p in store.list_local(): self.enqueue(p['id'])
        self.thread = threading.Thread(target=self.worker,daemon=True,name='studio-cloud-save') if start_worker else None
        if self.thread:self.thread.start()

    def persist(self):
        temp = self.state_path.with_suffix('.tmp')
        try:
            temp.write_text(json.dumps(self.states,separators=(',',':')),encoding='utf-8'); temp.replace(self.state_path)
            self.journal_error=''
        except OSError:self.journal_error='Cloud status could not be saved locally. Project data is retained; check free space and retry cloud save.'

    def enqueue(self, pid):
        if not self.enabled: return
        with self.cv:
            self.pending.add(pid)
            state=self.states.setdefault(pid,{})
            if state.get('error'):
                state.setdefault('errorHistory',[]).append({'time':time.time(),'message':state['error']})
                state['errorHistory']=state['errorHistory'][-16:]
            state.update(status='UPLOADING' if self.active_project==pid else 'PENDING',error='')
            self.persist(); self.cv.notify_all()

    def status(self, pid=None):
        with self.cv:
            return {'enabled':self.enabled,'provider':self.provider if self.enabled else 'Local helper',
                    'publisherCompatible':self.publisher_compatible,
                    'workingCache':True,'projects':copy.deepcopy(self.states if pid is None else {pid:self.states.get(pid,{})}),
                    'pending':len(self.pending),'error':self.configuration_error or self.journal_error}

    def manifest(self, pid, refresh=False):
        self.store.folder(pid)  # Validate stable identity before forming an object key.
        if refresh or pid not in self.manifests:
            data, etag = self.objects.read(f'studio/manifests/{pid}.json')
            self.manifests[pid] = (json.loads(data) if data else None, etag)
        return self.manifests[pid]

    def changed_since_shared_project(self, pid, project):
        """Revision counters can advance independently on two offline helpers."""
        with self.cv:
            state = self.states.get(pid, {})
            fingerprint = state.get('sharedProjectSHA256')
            revision = state.get('revision')
        if fingerprint:
            return fingerprint != digest(project)
        # Existing upload journals record the last acknowledged revision.
        return type(revision) is int and revision != project['revision']

    def sync(self, pid):
        folder = self.store.folder(pid)
        with self.store.lock:
            project = self.store.load_local(pid)
            snapshot = (folder/'project.json').read_bytes()
        old, etag = self.manifest(pid, True)
        if old and old['project']['revision'] > project['revision']:
            raise ValueError('Cloud project is newer. Reload it before overwriting; both copies retained.')
        if old and old['project'] != project and (old['project']['revision'] == project['revision']
                or self.changed_since_shared_project(pid, old['project'])):
            raise ValueError('Cloud and helper revisions conflict. Both copies retained for review.')
        records = dict(old.get('files',{})) if old else {}
        video_references=project_video_paths(project)
        paths=[path for path in sorted(local_media(folder))
            if not render_scratch(project,path.relative_to(folder).as_posix(),video_references)
            and path.name not in ('project.json','revision.json','project.previous.json')]
        relative_paths={path.relative_to(folder).as_posix() for path in paths}
        with self.cv:
            staged=self.staged_assets.get(pid,{})
            records.update({relative:record for relative,record in staged.items()
                            if relative in relative_paths})
        def progress(processed,total,uploaded):
            with self.cv:
                if self.active_project==pid:
                    self.states[pid]['syncProgress']={'filesProcessed':processed,'totalFiles':total,'uploadedBytes':uploaded}
        owner_is_worker=threading.current_thread() is self.thread
        def cancelled():
            # Explicit direct/offline sync remains available after close(); only
            # the owner worker is cancelled by shutdown of its background loop.
            return self.stopped and owner_is_worker
        workers=getattr(self.objects,'upload_workers',1) if self.provider=='Google Cloud Storage' else 1
        records,uploaded=stage_immutable_assets(self.objects,pid,folder,paths,records,
            lambda relative:self.store.asset(pid,relative),progress,workers,cancelled)
        with self.cv:
            self.staged_assets.pop(pid,None)
            self.staged_assets[pid]={relative:records[relative]
                for relative in sorted(relative_paths)[:4096]}
            while len(self.staged_assets)>8:
                self.staged_assets.pop(next(iter(self.staged_assets)))
        manifest = {'version':1,'project':project,'files':records,'savedAt':time.time()}
        if old and old.get('renderCache'):
            # Cloud render aliases belong to immutable content-keyed outputs;
            # an ordinary project edit must not discard their reuse index.
            manifest['renderCache']=copy.deepcopy(old['renderCache'])
        # All immutable assets finish before publishing a new loadable project.
        with self.store.lock:
            if (folder/'project.json').read_bytes() != snapshot:
                self.enqueue(pid); return False
        # Snapshot + immutable assets are already complete. Network requests
        # must not hold the project lock and stall edits/generation commits.
        # The cloud's condition still rejects concurrent remote revisions.
        if (old and old['project']==project and old.get('files')==records
                and type(old.get('savedAt')) in (int,float) and math.isfinite(old['savedAt'])):
            manifest['savedAt']=old['savedAt']
        else:
            history=digest({'project':project,'files':records})[:16]
            if cancelled():raise RuntimeError('Cloud archive stopped before publication; local files retained.')
            self.objects.put_json(f'studio/history/{pid}/{project["revision"]}-{history}.json',manifest)
            if cancelled():raise RuntimeError('Cloud archive stopped before publication; local files retained.')
            self.objects.put_json(f'studio/manifests/{pid}.json',manifest,etag,create=old is None)
        shared_fingerprint = digest(project)
        self.manifests.pop(pid,None)
        with self.cv:self.staged_assets.pop(pid,None)
        # Invalidate after any concurrent catalogue refresh finishes; otherwise
        # that refresh could overwrite this invalidation with its new timestamp.
        with self.catalogue_lock:self.catalogue_at = 0
        with self.store.lock:
            changed = (folder/'project.json').read_bytes() != snapshot
            with self.cv:
                self.states[pid] = {'status':'PENDING' if changed else 'SYNCED','revision':project['revision'],'sharedProjectSHA256':shared_fingerprint,'savedAt':manifest['savedAt'],
                    'files':len(records),'bytes':sum(x['bytes'] for x in records.values()),'lastUploadBytes':uploaded,'error':''}
                self.persist()
            if changed:self.enqueue(pid)
        return not changed

    def restore(self, pid):
        manifest,_ = self.manifest(pid,True)
        if not manifest:
            from studio_data import ProjectNotFound
            raise ProjectNotFound('Project not found in cloud storage.')
        from studio_data import validate_project
        project = validate_project(manifest['project'])
        if project['id'] != pid: raise ValueError('Cloud project identity does not match.')
        folder = self.store.folder(pid); folder.mkdir(exist_ok=True)
        with self.store.lock:
            local=folder/'project.json'
            if local.exists():
                current=self.store.load_local(pid)
                if current != project and (current['revision'] >= project['revision'] or self.changed_since_shared_project(pid, current)):
                    raise ValueError('Unsaved or conflicting helper changes exist. Both copies retained; cloud reload was cancelled.')
            temp=folder/'project.cloud.tmp'; temp.write_text(json.dumps(project,ensure_ascii=False),encoding='utf-8')
            temp.replace(folder/'project.json')
            (folder/'revision.json').write_text(json.dumps({'revision':project['revision'],'updated':project['updated']}),encoding='utf-8')
            with self.cv:
                self.states.setdefault(pid, {})['sharedProjectSHA256'] = digest(project)
                self.persist()
        return project

    def asset_record(self, pid, name):
        """Verified immutable identity from the published manifest; no media download.

        This is metadata availability, not a new visual inspection. Actual reads
        still verify the downloaded bytes against this identity before use.
        """
        self.store.asset_local(pid,name) # Path and media-extension validation.
        if not self.enabled:return None
        manifest,_=self.manifest(pid)
        record=(manifest or {}).get('files',{}).get(name.replace('\\','/'))
        if record is None:return None
        if (not isinstance(record,dict) or not isinstance(record.get('sha256'),str) or not re.fullmatch(r'[a-f0-9]{64}',record.get('sha256',''))
                or record.get('key') != f'studio/assets/{pid}/{record["sha256"]}/{name.replace(chr(92),"/")}'
                or isinstance(record.get('bytes'),bool) or not isinstance(record.get('bytes'),int)
                or record['bytes']<0):
            raise ValueError('Invalid cloud asset identity.')
        return dict(record)

    def fetch_asset(self, pid, name):
        target = self.store.asset_local(pid,name)
        # Simultaneous preview/render requests must share one restore rather
        # than overwrite each other's temporary file or an existing local edit.
        with self.asset_locks[hash((pid,name.replace('\\','/'))) % len(self.asset_locks)]:
            if target.exists(): return target
            return self._fetch_asset(pid,name,target)

    def _fetch_asset(self, pid, name, target):
        manifest,_ = self.manifest(pid)
        record = (manifest or {}).get('files',{}).get(name.replace('\\','/'))
        if not record: return target
        if not re.fullmatch(r'[a-f0-9]{64}',record.get('sha256','')) or record.get('key') != f'studio/assets/{pid}/{record["sha256"]}/{name.replace(chr(92),"/")}':
            raise ValueError('Invalid cloud asset identity.')
        target.parent.mkdir(parents=True,exist_ok=True); tmp=target.with_suffix(target.suffix+'.cloud-partial')
        self.objects.download(record['key'],tmp)
        if tmp.stat().st_size != record['bytes'] or sha(tmp)!=record['sha256']:
            tmp.unlink(missing_ok=True); raise ValueError('Cloud asset checksum failed. Existing assets preserved.')
        tmp.replace(target); return target

    def media_url(self, pid, name, download_name=None):
        manifest,_=self.manifest(pid)
        record=(manifest or {}).get('files',{}).get(name.replace('\\','/'))
        local=self.store.asset_local(pid,name)
        if not record or (local.exists() and record.get('stamp')!=list(stable_file(local))): return None
        if not re.fullmatch(r'[a-f0-9]{64}',record.get('sha256','')) or record.get('key') != f'studio/assets/{pid}/{record["sha256"]}/{name.replace(chr(92),"/")}':
            raise ValueError('Invalid cloud asset identity.')
        return self.objects.url(record['key'],download_name=download_name) if download_name is not None else self.objects.url(record['key'])

    def files(self, pid, refresh=False):
        """Credential-free dashboard data; URLs are created only on request."""
        from studio_file_locations import located_files,media_category
        if not self.enabled:
            folder=self.store.folder(pid); rows=[]
            for path in local_media(folder):
                name=path.relative_to(folder).as_posix()
                self.store.asset_local(pid,name)
                rows.append({'path':name,'bytes':path.stat().st_size,'cloud':False,
                    'category':media_category(name)})
            return {'files':located_files(self.store,pid,rows), 'cloud':False}
        manifest,_=self.manifest(pid,refresh)
        rows={}
        for name,r in (manifest or {}).get('files',{}).items():
            self.store.asset_local(pid,name)
            rows[name]={'path':name,'bytes':r['bytes'],'sha256':r['sha256'],'cloud':True,
                        'category':media_category(name)}
        # A cloud connection must not hide newly generated or edited files while
        # the immutable snapshot is still uploading. Show their local status.
        folder=self.store.folder(pid)
        for path in local_media(folder):
            name=path.relative_to(folder).as_posix()
            if path.name in ('project.json','revision.json','project.previous.json'):continue
            self.store.asset_local(pid,name)
            record=(manifest or {}).get('files',{}).get(name,{})
            if record.get('stamp')==list(stable_file(path)):continue
            rows[name]={'path':name,'bytes':path.stat().st_size,'cloud':False,
                        'category':media_category(name)}
        return {'files':located_files(self.store,pid,list(rows.values()),True,
                    self.states.get(pid,{}).get('status')),'cloud':True,'revision':(manifest or {}).get('project',{}).get('revision')}

    def list_projects(self):
        with self.catalogue_lock:
            if self.catalogue is not None and time.monotonic()-self.catalogue_at < 30:
                return copy.deepcopy(self.catalogue)
            self.catalogue = self._list_projects()
            self.catalogue_at = time.monotonic()
            return copy.deepcopy(self.catalogue)

    def _list_projects(self):
        keys=[key for key in self.objects.keys('studio/manifests/')
              if re.fullmatch(r'studio/manifests/pr-[a-f0-9]{16}\.json',key)]
        def summary(key):
            pid=key.rsplit('/',1)[-1].removesuffix('.json')
            try:
                # Listing needs metadata only. Do not retain every novel's full
                # manifest in the asset cache or restore its media to the laptop.
                raw,_=self.objects.read(key)
                if raw is None:return None # Removed after the listing snapshot.
                p=json.loads(raw)['project']
                if (p['id']!=pid or not isinstance(p['name'],str)
                    or type(p['revision']) is not int or p['revision']<0
                    or type(p['updated']) not in (int,float) or not math.isfinite(p['updated'])
                    or not isinstance(p['chapters'],list)):
                    raise ValueError('Invalid cloud project summary')
                return {k:p[k] for k in ('id','name','revision','updated')} | {'chapters':len(p['chapters'])}
            except Exception:
                # Preserve visibility and never expose raw SDK/credential text.
                return {'id':pid,'name':'Cloud project needs recovery','revision':0,
                    'updated':0,'chapters':0,
                    'loadError':'Cloud project metadata could not be read. Its saved files are retained; retry or recover a saved snapshot.'}
        with ThreadPoolExecutor(max_workers=4,thread_name_prefix='studio-project-list') as pool:
            return [row for row in pool.map(summary,keys) if row is not None]

    def worker(self):
        while True:
            with self.cv:
                if self.stopped: return
                if not self.pending: self.cv.wait(3); continue
                pid=self.pending.pop(); self.active_project=pid
                self.states.setdefault(pid,{})['status']='UPLOADING'; self.persist()
            try: self.sync(pid)
            except Exception:
                # SDK errors may contain credential-adjacent URLs. Never return their raw text.
                with self.cv:
                    self.states[pid].update(status='FAILED',error='Cloud save failed. Local work is retained. Check access, connection and revision conflicts; retry cloud save.')
                    self.persist()
            finally:
                with self.cv:self.active_project=None

    def close(self):
        with self.cv: self.stopped=True; self.cv.notify_all()
        if self.thread:self.thread.join(5)
