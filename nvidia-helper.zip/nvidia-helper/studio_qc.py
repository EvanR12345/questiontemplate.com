"""Production decisions separate from preserved AI quality-review evidence."""
import copy
import hashlib
import math
import re
import time
from studio_data import digest, get_chapter, get_shot

POLICIES = ('practical', 'strict')
CHECK_LEVELS = ('off', 'sampled', 'practical', 'strict')

def check_level(settings):
    # Missing key preserves saved projects' existing MAX QUALITY behavior.
    if 'qcCheckLevel' in settings:
        return settings['qcCheckLevel']
    if settings.get('visionQC') or settings.get('generationMode') == 'MAX QUALITY':
        return settings.get('qcPolicy', 'practical')
    return 'off'

def should_check(project, shot, context=None):
    level = check_level(project['settings'])
    if level == 'off': return False
    if level != 'sampled': return True
    interval = project['settings'].get('qcSampleEvery', 5)
    identity=shot.get('id')
    # A context belongs to one unchanged project scan. Build its small first-
    # shot index once, never keep it between requests or production mutations.
    first = context.get('sampleFirstShots') if context is not None else None
    if first is None:
        intro = project.get('intro', {}).get('shots', [])
        first = {intro[0].get('id')} if intro else set()
        for chapter in project['chapters']:
            for scene in chapter.get('scenes',[]):
                if scene['shots']:
                    first.add(scene['shots'][0].get('id'));break
        if context is not None:context['sampleFirstShots']=first
    if identity in first:return True
    key = project['id'] + ':' + shot['id']
    return int(hashlib.sha256(key.encode()).hexdigest()[:16], 16) % interval == 0

def validate_checks(settings):
    if settings.get('qcClothingContinuity', 'required') not in ('required', 'advisory'):
        raise ValueError('Choose Required or Advisory clothing continuity.')
    if 'unattendedProduction' in settings and type(settings['unattendedProduction']) is not bool:
        raise ValueError('Unattended production must be enabled or disabled.')
    if settings.get('qcRepairBudgetMode', 'overhead') not in ('overhead', 'project-cap'):
        raise ValueError('Choose measured overhead or the saved project cap for repairs.')
    if settings.get('qcCheckLevel', 'off') not in CHECK_LEVELS:
        raise ValueError('Choose Off, Sampled, Practical or Strict checks.')
    interval = settings.get('qcSampleEvery', 5)
    if isinstance(interval, bool) or not isinstance(interval, int) or not 2 <= interval <= 20:
        raise ValueError('Sample every 2â€“20 images.')

def policy(settings):
    level = settings.get('qcCheckLevel')
    return level if level in ('practical', 'strict') else settings.get('qcPolicy', 'practical')

def review_settings_signature(settings):
    """Only inputs that change the review, not cadence/retry scheduling."""
    director=settings.get('director',{})
    fields={'version':1,'policy':policy(settings),
        'continuity':settings.get('continuityStrictness'),
        'style':settings.get('style'),
        'constraints':settings.get('imageVisualConstraints',settings.get('visualConstraints','')),
        'provider':director.get('provider'),'model':director.get('model'),
        'reasoning':director.get('qcReasoning') or ('High' if settings.get('generationMode')=='MAX QUALITY' else 'Fast')}
    # Preserve the historical signature byte-for-byte for the default policy.
    if settings.get('qcClothingContinuity')=='advisory':
        fields['clothingContinuity']='advisory'
    return digest(fields)


def review_settings_stale(project, shot, context=None):
    signature=shot.get('qc',{}).get('reviewSettingsSignature')
    if not signature:return False
    current=context.get('reviewSettingsSignature') if context is not None else None
    if current is None:
        current=review_settings_signature(project['settings'])
        if context is not None:context['reviewSettingsSignature']=current
    return signature!=current


def retain_review_settings(project, previous_settings):
    """Legacy evidence keeps its old policy when settings change; assets stay put."""
    previous=review_settings_signature(previous_settings)
    if previous==review_settings_signature(project['settings']):return
    shots=[s for c in project['chapters'] for sc in c['scenes'] for s in sc['shots']]
    shots+=project.get('intro',{}).get('shots',[])
    for shot in shots:
        qc=shot.get('qc',{})
        if type(qc.get('pass')) is bool:qc.setdefault('reviewSettingsSignature',previous)


def asset_hash(store, pid, name, context=None):
    """Memoize only inside one view request; later requests recheck changed bytes."""
    key = (pid, name)
    if context is not None and key in context['files']:
        return context['files'][key]
    value = store.asset_digest(pid, name)
    if context is not None: context['files'][key] = value
    return value

def review_signature(project, shot, store, context=None):
    """Bind manual decisions to story/identity inputs as well as image bytes."""
    fields = ('prompt','negativePrompt','imageProvider','imageModel','workflow','characters',
              'camera','location','action','pose','expression','lighting','narrationSegment',
              'continuity','intentionalAppearanceChanges','generationSettings')
    if context is not None and shot['id'] in context['reviews']:
        return context['reviews'][shot['id']]
    is_intro = (shot['id'] in context['intro'] if context is not None else any(s.get('id')==shot.get('id') for s in project.get('intro',{}).get('shots',[])))
    chapter = None if is_intro else (context['chapters'][shot['chapterId']] if context is not None else get_chapter(project, shot['chapterId']))
    selected = {c['id'] for c in shot.get('characters', [])}
    people = [c for c in project['characters']+(chapter.get('people', []) if chapter else []) if c['id'] in selected]
    references = [r for c in people for r in c.get('references', [])]
    references += [r for loc in project.get('locations', []) if loc['id']==shot.get('locationId') for r in loc.get('references', [])]
    references += project.get('styleReferences', [])
    if shot.get('manual', {}).get('referenceImages'): references += shot.get('referenceImages', [])
    fingerprints = []
    for ref in references:
        if ref.get('path'):
            fingerprints.append({'path':ref['path'], 'sha256':asset_hash(store,project['id'],ref['path'],context)})
    source = ({k:project['intro'].get(k) for k in ('voiceText','sourceBrief','duration')} if is_intro else chapter.get('sourceText',''))
    value = digest({'shot':{k:shot.get(k) for k in fields}, 'source':source,
                   'people':[{k:c.get(k) for k in ('id','description','permanentIdentity','references')} for c in people],
                   'references':fingerprints, 'style':project['settings'].get('style'),
                   'constraints':project['settings'].get('imageVisualConstraints', project['settings'].get('visualConstraints',''))})
    if context is not None: context['reviews'][shot['id']] = value
    return value

def valid_acceptance(project, shot, store, context=None):
    override = shot.get('qcOverride', {})
    if (override.get('decision')!='accepted' or shot.get('generationStale')
            or not shot.get('imagePath') or override.get('imagePath')!=shot['imagePath']): return False
    actual = asset_hash(store,project['id'],shot['imagePath'],context)
    return (actual is not None and override.get('imageSHA256')==actual
            and override.get('reviewSpecSignature')==review_signature(project, shot, store,context))

def issue_levels(qc):
    """Structured new findings; narrow fallback for saved older review text."""
    issues = qc.get('issues', [])
    findings = qc.get('findings')
    if isinstance(findings,list) and len(findings)==len(issues) and all(
            isinstance(f,dict) and f.get('issue')==issue and f.get('severity') in ('advisory','major','uncertain')
            for f,issue in zip(findings,issues)):
        return [f['severity'] for f in findings]
    levels = []
    for issue in issues:
        text = str(issue).lower()
        if re.search(r'wrong (?:character|identity|weapon)|(?:bladed weapon|sword|knife).{0,60}(?:rather than|instead of).{0,30}(?:gun|pistol|revolver)',text):
            levels.append('major')
        elif re.search(r'fram(?:ing|ed)|close[- ]?up|composition is wider|looking down at|eyes fixed|eye contact|tiny|small detail|no knives (?:are )?visib|no knives visibly|no knives piercing|standing exposed|staying sheltered|gripping a gun with both hands',text):
            levels.append('advisory')
        else:
            levels.append('uncertain')
    return levels

def clothing_advisory_indices(settings, qc):
    """Use explicit review semantics only; never infer tolerance from issue text."""
    if settings.get('qcClothingContinuity')!='advisory':return []
    issues,findings=qc.get('issues',[]),qc.get('findings')
    if not isinstance(issues,list) or not isinstance(findings,list) or len(findings)!=len(issues):return []
    if not all(isinstance(f,dict) and f.get('issue')==issue
            and f.get('severity') in ('advisory','major','uncertain')
            and type(f.get('clothingOnly')) is bool for f,issue in zip(findings,issues)):return []
    return [index for index,finding in enumerate(findings) if finding['clothingOnly']]

def effective_issue_levels(settings, qc):
    """Decision-only levels; the original findings and raw pass stay untouched."""
    levels=issue_levels(qc)
    for index in clothing_advisory_indices(settings,qc):levels[index]='advisory'
    return levels

def decision(project, shot, store, context=None):
    qc = shot.get('qc', {})
    mode = policy(project['settings'])
    if project['settings'].get('qcCheckLevel')=='off':
        # An explicit user choice disables visual gating, never erases findings
        # or certifies story correctness. File/decoder checks remain separate.
        return {'disposition':'checks_off','blocking':False,'policy':mode}
    if qc.get('status')=='PENDING': return {'disposition':'pending','blocking':True,'policy':mode}
    if valid_acceptance(project, shot, store,context): return {'disposition':'accepted','blocking':False,'policy':mode}
    if review_settings_stale(project,shot,context) and should_check(project,shot,context):
        return {'disposition':'pending','blocking':True,'policy':mode,'reason':'Visual review settings changed; recheck the saved image.'}
    if qc.get('pass') is True: return {'disposition':'passed','blocking':False,'policy':mode}
    if qc.get('pass') is not False:
        # Preserve prior semantics for deliberately disabled/unavailable vision.
        return {'disposition':'unreviewed','blocking':False,'policy':mode}
    levels = effective_issue_levels(project['settings'],qc)
    clothing=clothing_advisory_indices(project['settings'],qc)
    if levels and len(clothing)==len(levels):
        return {'disposition':'advisory','blocking':False,'policy':mode,'issueLevels':levels,
                'clothingAdvisoryCount':len(clothing),
                'warning':'Clothing-only findings are advisory under this project setting; original findings remain unchanged.'}
    if mode == 'practical' and project['settings'].get('unattendedProduction') and levels and 'major' not in levels:
        return {'disposition':'advisory','blocking':False,'policy':mode,'issueLevels':levels,
                'warning':'Unattended Practical mode retains minor/uncertain findings as warnings.'}
    if mode=='strict':
        return {'disposition':'review','blocking':bool(project['settings'].get('unattendedProduction')) or qc.get('action')!='review','policy':mode,'issueLevels':levels}
    minor = bool(levels) and all(level=='advisory' for level in levels)
    return {'disposition':'advisory' if minor else 'review','blocking':not minor,'policy':mode,'issueLevels':levels}

def production_status(project, shot, store):
    assessment = decision(project, shot, store)
    if assessment['blocking']: return 'FAILED' if assessment['disposition']!='pending' else 'QC'
    return 'PASSED' if shot.get('qc', {}).get('pass') is True else 'COMPLETE'

def automatic_repairs(settings, qc=None):
    # Explicit Off disables repairs. A missing check-level key preserves the
    # existing saved-project semantics of an explicit automaticRepair toggle.
    enabled = (settings.get('qcCheckLevel') != 'off' and bool(settings.get('automaticRepair'))
               and int(settings.get('maxImageRetries',2))>0 and repair_budget_reason(settings) is None)
    if not enabled or qc is None: return enabled
    if qc.get('pass') is not False: return False
    levels=effective_issue_levels(settings,qc)
    if levels and len(clothing_advisory_indices(settings,qc))==len(levels):return False
    if qc.get('action') not in ('image_edit','regenerate') and not (
            settings.get('unattendedProduction') and 'major' in levels): return False
    if policy(settings)=='strict': return True
    # Practical/Sampled mode can fix a confirmed major defect, never spend on
    # advisory/uncertain discrepancies or a manual-review-only instruction.
    return 'major' in levels

def repair_budget_reason(settings):
    """Unknown combined overhead never authorizes spending to find it out.

    A future measured estimate must cover all configured retries, rechecks and
    incremental rental. Existing API/GPU absolute caps still govern dispatch.
    """
    if int(settings.get('maxImageRetries',2))<1:
        return 'Image repairs are disabled by the zero-retry limit.'
    if settings.get('qcRepairBudgetMode') == 'project-cap':
        from studio_automation import project_cap_reason
        return project_cap_reason(settings)
    estimate = settings.get('qcCostEstimate', {})
    if not isinstance(estimate,dict) or not all(estimate.get(k) is True for k in (
            'baselineControlled','includesAPI','includesIncrementalRental','includesRechecks')):
        return 'Repair cost is unverified: a comparable generation baseline plus QC, rechecks and incremental rental is required before spending.'
    baseline = estimate.get('baselineGenerationUSD')
    upper = estimate.get('combinedQCAndReplacementUpperUSD')
    limit = settings.get('qcOverheadLimitPercent', 10)
    if any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v)
           for v in (baseline,upper,limit)) or baseline<=0 or upper<0 or not 0<=limit<=10:
        return 'Repair cost estimate or overhead limit is invalid.'
    covered = estimate.get('maxImageRetriesCovered')
    if isinstance(covered,bool) or not isinstance(covered,int) or covered<int(settings.get('maxImageRetries',2)):
        return 'Repair estimate does not cover all configured replacements and rechecks.'
    if upper>baseline*limit/100:
        return 'Combined QC and replacement estimate exceeds the 10% cost ceiling.'
    return None

def project_view(store, pid):
    project = store.load(pid)
    context = {'files':{},'reviews':{},'chapters':{c['id']:c for c in project['chapters']},'intro':{s['id'] for s in project.get('intro',{}).get('shots',[])}}
    for chapter in project['chapters']:
        for scene in chapter['scenes']:
            for shot in scene['shots']:
                shot['qcDecision'] = decision(project,shot,store,context)
                if shot.get('imagePath'):shot['qcReviewSignature']=review_signature(project,shot,store,context)
    for shot in project.get('intro',{}).get('shots',[]):
        shot['qcDecision'] = decision(project,shot,store,context)
        if shot.get('imagePath'):shot['qcReviewSignature']=review_signature(project,shot,store,context)
    reason=repair_budget_reason(project['settings'])
    project['qcRepairBudget']={'allowed':reason is None,'reason':reason,'overheadLimitPercent':project['settings'].get('qcOverheadLimitPercent',10),
                              'enabled':automatic_repairs(project['settings']),
                              'scope':'major errors only' if policy(project['settings'])=='practical' else 'confirmed repair findings'}
    return project

def accept_image(store, pid, chid, sid, options):
    """Explicit current-image acceptance without replacing any AI finding."""
    def apply(project):
        shot = next((s for s in project.get('intro',{}).get('shots',[]) if s['id']==sid), None)
        if shot is None: shot = get_shot(project,chid,sid)
        if not shot.get('imagePath') or options.get('imagePath')!=shot['imagePath']:
            raise ValueError('The selected image changed. Refresh and review the current image before accepting it.')
        path = store.asset(pid,shot['imagePath'])
        if not path.is_file(): raise ValueError('The selected image is missing.')
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if options.get('imageSHA256') and options['imageSHA256']!=actual:
            raise ValueError('The image bytes changed. Refresh and review the current image before accepting it.')
        if shot.get('generationStale'): raise ValueError('Shot inputs changed. Review or regenerate the current image before accepting it.')
        signature = review_signature(project,shot,store)
        if options.get('reviewSpecSignature')!=signature:
            raise ValueError('Shot or reference inputs changed. Refresh and review the current image before accepting it.')
        if shot.get('qcOverride'):shot.setdefault('qcOverrideHistory', []).append(copy.deepcopy(shot['qcOverride']))
        shot['qcOverride'] = {'decision':'accepted','reviewer':'USER','reviewedAt':time.time(),
            'imagePath':shot['imagePath'],'imageSHA256':actual,'reviewSpecSignature':signature,
            'reason':str(options.get('reason') or 'User accepts this image for production')[:1000]}
        # QC can still be pending: retain that status until its actual result saves.
        if shot.get('qc',{}).get('status')!='PENDING':shot['status']=production_status(project,shot,store)
        shot['generationError']=''
        if not any(s.get('id')==sid for s in project.get('intro',{}).get('shots',[])):
            get_chapter(project,chid)['renderStale']=True
        project['renderStale']=True
    store.mutate(pid,apply)
    return project_view(store,pid)
