import {setupAudioModels} from './audio-model-picker.mjs?v=opus-only-20261026';
import { countWords, duration, wavBlob, SAMPLE_RATE, estimatedBytes, recordedSeconds } from './audio-core.mjs?v=speech-3';
import { speechText } from './pronunciation.mjs?v=speech-3';
import { GenerationEstimate, measuredPace, narrationEstimate } from './speech-progress.mjs?v=speech-3';
import { beginSession, checkpointVersion, loadCheckpointVersion, savePart, saveJob, loadSession } from './session-store.mjs?v=audio-checkpoint-2';
import { nativeHealth } from './native-client.mjs?v=queue-1';
import { pairingKey } from './helper-connection.mjs?v=queue-1';
const $ = selector => document.querySelector(selector);
const script = $('#text'), synth = window.speechSynthesis;
let worker, busy = false, run, urls = [], deviceVoices = [], previewId = 0, activeUtterance;
let nativeKey = pairingKey();
let nativeConnected = false, connectingNative = false;
let history = [];
let voicePaces = {};
try { voicePaces = JSON.parse(localStorage.getItem('tts-voice-paces') || '{}') || {}; } catch {}
function paceKey(voice = $('#studioVoice').value, engine = $('#engine').value) { return engine + ':' + voice; }
function scriptEstimate() { return narrationEstimate(countWords(script.value), Number($('#rate').value), voicePaces[paceKey()]); }
function estimateRange(estimate) { return duration(estimate.low) + '–' + duration(estimate.high); }
try { const saved = JSON.parse(localStorage.getItem('tts-history') || '[]'); if (Array.isArray(saved)) history = saved.filter(x => typeof x === 'string').slice(0, 6); } catch {}
const examples = {
  intro: 'You are not ready for what happens next. Today, we are testing the biggest challenge we have ever built!',
  ad: 'Meet the faster way to turn your ideas into clear, expressive audio. Try it in your browser today.',
  story: 'The lights went out at exactly midnight. That was when Maya heard three slow knocks at the door. She had been warned never to open it after dark. Tonight, someone on the other side knew her name.',
};
function status(message) { $('#status').textContent = message; }
function updateCounts() {
  const words = countWords(script.value), estimate = scriptEstimate();
  $('#count').textContent = script.value.length.toLocaleString();
  $('#words').textContent = words.toLocaleString();
  $('#targetWpm').textContent = '≈ ' + Math.round(estimate.wpm);
  $('#estimate').textContent = words ? estimateRange(estimate) : '0:00';
  if($('#audioVoiceModel')?.value && $('#audioVoiceModel').value!=='kokoro-82m'){ $('#estimate').textContent='Unmeasured'; $('#targetWpm').textContent='—'; }
  $('#estimate').title = estimate.measured ? 'Based on audio measured for this voice, including pauses. Story punctuation can change the pace.' : 'Rough range until a voice preview measures your narration pace.';
}
function outputs() {
  $('#rateOut').textContent = Number($('#rate').value).toFixed(2) + '×';
  $('#pitchOut').textContent = Number($('#pitch').value).toFixed(2);
  $('#volumeOut').textContent = Math.round($('#volume').value * 100) + '%';
  updateCounts(); formatOutputs();
}
function renderHistory() {
  const box = $('#recent'); box.replaceChildren();
  if (!history.length) { box.textContent = 'Your recent scripts will appear here.'; return; }
  for (const value of history) {
    const button = document.createElement('button'), span = document.createElement('span'), label = document.createElement('small');
    span.textContent = value.slice(0, 120); label.textContent = 'Use again'; button.append(span, label);
    button.onclick = () => { if (!busy) { script.value = value; updateCounts(); script.focus(); } };
    button.disabled = busy; box.append(button);
  }
}
function remember(value) {
  history = [value, ...history.filter(x => x !== value)].slice(0, 6);
  try { localStorage.setItem('tts-history', JSON.stringify(history)); } catch {
    // Storage quotas never limit speech generation. Scripts remain available in this tab.
  }
  renderHistory();
}
function controls(generating) {
  busy = generating;
  for (const el of document.querySelectorAll('#generate,#sample,#audioVoiceModel,#studioVoice,#rate,#volume,#text,#clear,#importScript,#format,#bitrate,#engine,#restore,#resumeSaved,#pronunciation,#connectNative,[data-example],[data-voice]')) el.disabled = generating;
  $('#generationControls').hidden = !generating;
  if (generating) $('#performance').hidden = false;
  $('#cancel').disabled = !generating;
  $('#pauseGeneration').disabled = !generating;
  $('#bitrate').disabled = generating || $('#format').value === 'wav';
  renderHistory();
}
function selectVoice(id) {
  $('#studioVoice').value = id;
  $('#selectedVoice').textContent = $('#studioVoice').selectedOptions[0].textContent;
  document.querySelectorAll('[data-voice]').forEach(b => {
    const selected = b.dataset.voice === id;
    b.classList.toggle('active', selected); b.setAttribute('aria-pressed', String(selected));
  });
  updateCounts(); formatOutputs();
}
function revokeUrls() { urls.forEach(url => URL.revokeObjectURL(url)); urls = []; }
function urlFor(blob) { const url = URL.createObjectURL(blob); urls.push(url); return url; }
function recordingDuration() { return recordedSeconds(run.frames, run.bytes, run.format, run.bitrate); }
function activeSeconds(now = performance.now()) {
  if (!run.generationStart) return 0;
  now = run.finishedAt || now;
  return Math.max(0, (now - run.generationStart - run.pausedMs - (run.pauseStart ? now - run.pauseStart : 0)) / 1000);
}
function performanceStats() {
  if (!run) return;
  const now = run.finishedAt || performance.now();
  $('#elapsed').textContent = duration((now - run.wallStart) / 1000);
  if (!run.generationStart) return;
  const active = Math.max(.001, activeSeconds(now));
  const audio = (run.frames - run.startFrames) / SAMPLE_RATE;
  $('#generationSpeed').textContent = audio ? (audio / active).toFixed(2) + '× realtime' : '—';
  const estimate = run.estimator.remaining(run.totalWords - run.words, active);
  $('#timeLeft').textContent = run.pauseStart ? 'Paused' : run.finishedAt ? (run.processed >= run.text.length ? 'Complete' : 'Stopped') : !estimate ? 'Measuring…' : estimate.delayed ? 'Waiting for current section…' : estimate.seconds ? '≈ ' + duration(estimate.seconds) : 'Finishing…';
}
function updateRecording() {
  const seconds = recordingDuration();
  $('#actualDuration').textContent = duration(seconds);
  $('#actualWpm').textContent = seconds ? Math.round(run.words / seconds * 60).toLocaleString() : '—';
  $('#size').textContent = ((run.bytes + (run.format === 'wav' ? 44 : 0)) / 1e6).toFixed(1) + ' MB';
  performanceStats();
}
function jobData(complete = false) {
  return { text: run.text, voice: run.voice, voiceName: run.voiceName, speed: run.speed, volume: run.volume,
    format: run.format, bitrate: run.bitrate, engine: run.engine, pronunciation: run.pronunciation || '', processed: run.checkpoint || 0, complete, updated: Date.now(), checkpointId: crypto.randomUUID() };
}
function storageFailure(message = 'Checkpoint storage is unavailable or full. Download completed parts before closing this tab.') {
  run.persist = false;
  $('#engineStatus').textContent = message;
}
async function saveCheckpoint(part, complete = false) {
  try {
    const expected = await run.checkpointBase;
    if (!run.persist) return;
    const job = jobData(complete);
    let saved;
    if (!part) saved = await saveJob(job, expected);
    // Replace the earlier recovery slot only when new audio can take its place.
    else if (part.index === 0) saved = await beginSession(job, part, expected);
    else saved = await savePart(job, part, expected);
    if (saved) run.checkpointBase = Promise.resolve(job.checkpointId);
    else storageFailure('Another Audio tab updated the saved recording. Download completed parts before closing this tab.');
  } catch { storageFailure(); }
}
function appendPart(part) {
  const blob = run.format === 'wav' ? wavBlob([part.blob], part.frames) : new Blob([part.blob], { type: run.format === 'opus' ? 'audio/ogg; codecs=opus' : 'audio/mpeg' });
  const url = urlFor(blob), index = run.parts.indexOf(part) + 1;
  const card = document.createElement('section'); card.className = 'part';
  const header = document.createElement('header'), title = document.createElement('h3'), download = document.createElement('a');
  title.textContent = (run.sample ? 'Voice preview' : 'Part ' + index) + ' · ' + duration(recordedSeconds(part.frames, part.blob.size, run.format, run.bitrate));
  download.textContent = '↓ Download ' + run.format.toUpperCase(); download.href = url;
  download.download = run.voice + '-part-' + String(index).padStart(3, '0') + '.' + run.format;
  header.append(title, download);
  const audio = document.createElement('audio'); audio.controls = true; audio.preload = 'none'; audio.src = url;
  card.append(header, audio); $('#parts').append(card);
}
async function finishPart(processed) {
  if (!run.partFrames) return;
  const part = { index: run.parts.length, blob: new Blob(run.current), frames: run.partFrames, processed };
  run.parts.push(part); run.current = []; run.partFrames = 0; run.checkpoint = processed;
  appendPart(part);
  if (run.persist) await saveCheckpoint(part);
}
function setFullDownload(partial = false) {
  if (!run.parts.length) return;
  try {
    const blob = run.format === 'wav' ? wavBlob(run.parts.map(part => part.blob), run.frames)
      : new Blob(run.parts.map(part => part.blob), { type: run.format === 'opus' ? 'audio/ogg; codecs=opus' : 'audio/mpeg' });
    const link = $('#downloadAll'); link.href = urlFor(blob);
    link.download = run.voice + '-' + (partial ? 'partial-' : '') + 'recording.' + run.format;
    link.textContent = (run.sample ? '↓ Download preview ' : '↓ Download full ') + run.format.toUpperCase(); link.setAttribute('aria-disabled', 'false');
  } catch { $('#recordingNote').textContent = 'Download individual parts; this recording exceeds the WAV format size limit.'; }
}
async function offerSavedRecording(message) {
  const currentRun = run;
  try {
    const saved = await loadSession();
    if (busy || run !== currentRun || !saved?.parts.length) return;
    $('#recoveryText').textContent = message;
    $('#recovery').hidden = false;
  } catch {}
}
async function complete(message, partial = false) {
  run.finishedAt = performance.now();
  $('#progress').hidden = true;
  if (run.frames) {
    setFullDownload(partial);
    $('#recordingNote').textContent = partial ? 'Partial recording. Completed sections are downloadable; resume to continue.'
      : run.sample ? 'A short sample of your script. Generate audio to record the entire script.'
      : run.words.toLocaleString() + ' words recorded · ' + run.voiceName + ' · ' + run.speed.toFixed(2) + '× speed. Actual WPM includes pauses.';
  } else $('#recordingNote').textContent = 'No audio generated yet.';
  if (run.persist && run.parts.length) await saveCheckpoint(null, !partial);
  $('#resumeSaved').hidden = !partial || run.processed >= run.text.length || run.sample;
  clearInterval(run.timer); updateRecording(); controls(false); status(message);
  if (!run.persist || !run.parts.length) {
    void offerSavedRecording(run.sample ? 'Your earlier recording is still saved.' : 'A saved recording is available on this device.');
  }
  await wakeLock?.release().catch(() => {}); wakeLock = null;
  if (run.sample && run.frames && !partial) {
    const audio = $('#parts audio');
    $('#downloads').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    try { await audio.play(); status('Voice preview ready. Generate audio to record your whole script.'); }
    catch { status('Voice preview ready. Press play below to listen.'); }
  }
}
function advance(processed) {
  run.processed = processed;
  while (!run.nextWord.done && run.nextWord.value.index + run.nextWord.value[0].length <= processed) {
    run.words++; run.nextWord = run.wordIterator.next();
  }
}
function fail(message) {
  worker?.terminate(); worker = null;
  // An abrupt worker failure may leave the last encoder buffer unfinished.
  // Only previously flushed parts are safe checkpoints.
  run.current = []; run.partFrames = 0;
  run.frames = run.parts.reduce((sum, part) => sum + part.frames, 0);
  run.bytes = run.parts.reduce((sum, part) => sum + part.blob.size, 0);
  resetWords(run.checkpoint || 0);
  void complete('Could not finish: ' + message + '. Completed parts are safe to download or resume.', true);
}
async function receive({ data }) {
  if (!busy || !run) return;
  if (data.type === 'loading') {
    const p = data.progress;
    status(p.status === 'progress' ? 'Loading model: ' + (p.file || 'file') + ' · ' + Math.round(p.progress || 0) + '%.' : 'Preparing the local voice engine…');
    return;
  }
  if (data.type === 'notice') { status(data.message); return; }
  if (data.type === 'ready') {
    run.ready = true; run.generationStart ||= performance.now();
    $('#engineStatus').textContent = (data.backend === 'cuda' ? 'NVIDIA CUDA · ' + data.gpu : data.backend === 'webgpu' ? 'Browser GPU acceleration' : 'CPU · smaller model') + ' · ' + run.format.toUpperCase() + (run.format !== 'wav' ? ' ' + run.bitrate + ' kbps mono' : '');
    status('Generating locally. Completed parts are saved automatically.'); return;
  }
  if (data.type === 'backend') { $('#engineStatus').textContent = 'CPU · smaller model · ' + run.format.toUpperCase(); return; }
  if (data.type === 'paused') { run.pauseStart ||= performance.now(); status('Generation paused. Resume whenever you are ready.'); return; }
  if (data.type === 'resumed') { if (run.pauseStart) run.pausedMs += performance.now() - run.pauseStart; run.pauseStart = 0; status('Generation resumed.'); return; }
  if (data.type === 'chunk' || data.type === 'progress') {
    advance(data.processed);
    if (data.type === 'chunk') {
      if (data.bytes.byteLength) { run.current.push(new Blob([data.bytes])); run.bytes += data.bytes.byteLength; }
      run.partFrames += data.frames; run.frames += data.frames;
      if (data.frames > 0) {
        run.estimator.record(run.words - run.startWords, activeSeconds());
        const pace = measuredPace(run.words - run.startWords, (run.frames - run.startFrames) / SAMPLE_RATE, run.speed);
        if (pace) {
          voicePaces[paceKey(run.voice, run.engine)] = pace;
          try { localStorage.setItem('tts-voice-paces', JSON.stringify(voicePaces)); } catch {}
          updateCounts(); formatOutputs();
        }
      }
    }
    const percent = Math.min(100, run.processed / run.text.length * 100);
    $('#progress').value = percent;
    status('Generating ' + Math.floor(percent) + '% · ' + duration(recordingDuration()) + ' recorded · ' + run.words.toLocaleString() + ' words.');
    updateRecording(); return;
  }
  if (data.type === 'partEnd') {
    await finishPart(data.processed);
    worker?.postMessage({ type: 'ack' }); return;
  }
  if (data.type === 'done') {
    run.checkpoint = run.processed;
    const message = !run.frames ? 'No audio was generated. Check the script and pronunciation fixes, then try again.'
      : run.sample ? 'Voice sample ready. Press play below.' : 'Recording ready. Download the full track or individual parts.';
    await complete(message);
  }
  if (data.type === 'canceled') await complete('Stopped safely. Completed audio is downloadable. Resume to continue.', true);
  if (data.type === 'error') await complete('Could not finish: ' + data.message.replace(/[.\s]+$/, '') + '. Completed sections are downloadable.', true);
}
function resetWords(processed = 0) {
  run.wordIterator = run.text.matchAll(/[\p{L}\p{N}]+(?:['’][\p{L}\p{N}]+)*/gu);
  run.nextWord = run.wordIterator.next(); run.words = 0; advance(processed);
}
function initializeRun(job, parts = []) {
  stopPreview(); document.querySelectorAll('audio').forEach(audio => audio.pause()); revokeUrls();
  run = { ...job, frames: parts.reduce((sum, part) => sum + part.frames, 0), bytes: parts.reduce((sum, part) => sum + part.blob.size, 0),
    current: [], parts: [...parts], partFrames: 0, checkpoint: job.processed || 0, wallStart: performance.now(),
    generationStart: 0, pausedMs: 0, pauseStart: 0, persist: !job.sample, ready: false,
    checkpointBase: Promise.resolve(parts.length ? checkpointVersion(job) : null) };
  run.startFrames = run.frames; run.startOffset = job.processed || 0;
  resetWords(job.processed || 0);
  run.startWords = run.words; run.totalWords = countWords(run.text); run.estimator = new GenerationEstimate();
  $('#generationSpeed').textContent = '—'; $('#timeLeft').textContent = 'Measuring…';
  $('#parts').replaceChildren(); $('#downloads').hidden = false; $('#downloadAll').removeAttribute('href'); $('#downloadAll').setAttribute('aria-disabled', 'true');
  $('#recordingHeading').textContent = run.sample ? 'Voice preview' : 'Your recording';
  $('#downloadAll').textContent = (run.sample ? '↓ Download preview ' : '↓ Download full ') + run.format.toUpperCase();
  $('#resumeSaved').hidden = true;
  parts.forEach(appendPart); updateRecording();
}
let wakeLock;
async function keepAwake() { try { wakeLock = await navigator.wakeLock?.request('screen'); } catch {} }
async function startWorker() {
  await keepAwake();
  run.timer = setInterval(performanceStats, 1000);
  $('#progress').hidden = false; $('#progress').value = run.processed / run.text.length * 100;
  $('#pauseGeneration').textContent = 'Ⅱ Pause generation'; run.pauseRequested = false;
  status('Preparing the local voice engine…');
  try {
    if (!worker) { worker = new Worker('./tts.worker.js?v=opus-only-20261026', { type: 'module' }); worker.onmessage = receive;
      worker.onerror = event => { event.preventDefault(); fail(event.message || 'Voice engine failed'); }; }
    worker.postMessage({ type: 'generate', text: run.text, voice: run.voice, speed: run.speed, volume: run.volume,
      format: run.format, bitrate: run.bitrate, engine: run.engine, pronunciation: run.pronunciation || '', offset: run.processed,
      nativeKey: run.engine === 'native' ? nativeKey : undefined });
  } catch (error) { fail(error.message); }
}
async function generate(sample = false) {
  if (busy || connectingNative) return;
  if (audioModels.remote()) { await audioModels.generate(); return; }
  if ($('#engine').value === 'native' && (!nativeKey || !nativeConnected)) { $('#nativeSetup').open = true; status('Connect the NVIDIA helper before generating.'); $('#connectNative').focus(); return; }
  const full = script.value.trim();
  if (!full || !countWords(full)) { status('Add some words to your script first.'); script.focus(); return; }
  if (!window.Worker || !window.WebAssembly) { status('Use a current browser for downloadable audio.'); return; }
  let value = full;
  if (sample && full.length>1800) {
    const tokens = []; for (const match of full.matchAll(/\S+\s*/g)) { tokens.push(match[0]); if (tokens.length === 35) break; }
    value = tokens.join('').trim();
  }
  initializeRun({ text: value, voice: $('#studioVoice').value, voiceName: $('#studioVoice').selectedOptions[0].textContent,
    speed: Number($('#rate').value), volume: Number($('#volume').value), format: 'opus',
    bitrate: Number($('#bitrate').value), engine: $('#engine').value, pronunciation: $('#pronunciation').value, sample, processed: 0 });
  controls(true); remember(full); $('#recovery').hidden = true;
  $('#recordingNote').textContent = 'Parts appear as they finish. Raw audio is compressed immediately for compact downloads.';
  if (run.persist) {
    const currentRun = run;
    run.checkpointBase = loadCheckpointVersion().catch(() => {
      if (run === currentRun) storageFailure();
      return null;
    });
  }
  await startWorker();
}
async function resumeSaved() {
  if (busy || !run || run.processed >= run.text.length) return;
  if (run.format !== 'opus') { status('Old recording parts are preserved. Start a new Opus recording for the remaining text; old and new codecs cannot be joined directly.'); return; }
  if (run.engine === 'native' && (!nativeKey || !nativeConnected)) { $('#nativeSetup').open = true; status('Reconnect the NVIDIA helper, then resume your saved recording.'); return; }
  document.querySelectorAll('audio').forEach(audio => audio.pause());
  run.startFrames = run.frames; run.startOffset = run.processed; run.wallStart = performance.now();
  run.generationStart = 0; run.pausedMs = run.pauseStart = 0; run.ready = false;
  run.finishedAt = 0; run.startWords = run.words; run.estimator = new GenerationEstimate();
  $('#resumeSaved').hidden = true; $('#downloadAll').setAttribute('aria-disabled', 'true');
  controls(true); await startWorker();
}
async function restore() {
  if (busy) return;
  try {
    const saved = await loadSession(); if (!saved?.parts.length) { status('No completed parts are saved yet.'); return; }
    const { job, parts } = saved;
    script.value = job.text; $('#studioVoice').value = job.voice; selectVoice(job.voice);
    $('#rate').value = job.speed; $('#volume').value = job.volume; $('#format').value = 'opus'; $('#bitrate').value = [64, 128, 256].includes(job.bitrate) ? job.bitrate : 64; $('#engine').value = job.engine;
    $('#pronunciation').value = job.pronunciation || '';
    initializeRun(job, parts); outputs(); formatOutputs(); $('#recovery').hidden = true; setFullDownload(!job.complete);
    const canResume = !job.complete && job.processed < job.text.length && job.format === 'opus';
    $('#resumeSaved').hidden = !canResume;
    if (job.complete) $('#recordingNote').textContent = 'Saved recording restored. Your downloads are ready.';
    else if (canResume) $('#recordingNote').textContent = 'Saved parts restored. Resume to generate the remaining text.';
    else if (job.format !== 'opus') $('#recordingNote').textContent = 'Your original parts are ready to download. Use the remaining text for a new Opus recording.';
    else $('#recordingNote').textContent = 'Your saved parts are ready to download.';
    status('Saved recording restored.'); updateRecording();
  } catch { status('Saved recording could not be opened.'); }
}
function formatOutputs() {
  updateCounts();
  const format = $('#format').value, bitrate = Number($('#bitrate').value);
  $('#bitrate').disabled = busy || format === 'wav';
  const mb = seconds => (estimatedBytes(seconds, format, bitrate) / 1e6).toFixed(0);
  const estimate = scriptEstimate();
  $('#sizeEstimate').textContent = (format === 'opus' ? 'Variable bitrate estimate: ' : '') + '90–120 min ≈ ' + mb(5400) + '–' + mb(7200) + ' MB. Your script ≈ ' + mb(estimate.low) + '–' + mb(estimate.high) + ' MB.';
}
function stopPreview() { previewId++; synth?.cancel(); activeUtterance = null; }
function loadVoices() {
  const selected = $('#voice').selectedOptions[0]?.textContent;
  deviceVoices = synth?.getVoices() || []; $('#voice').replaceChildren();
  if (!deviceVoices.length) $('#voice').append(new Option('Default device voice', ''));
  deviceVoices.forEach((voice, i) => $('#voice').append(new Option(voice.name + ' · ' + voice.lang, i)));
  const match = [...$('#voice').options].find(option => option.textContent === selected); if (match) match.selected = true;
}
async function devicePreview() {
  if (!synth) { status('Device preview is not supported in this browser.'); return; }
  const value = script.value.trim(); if (!value) { status('Type something first.'); return; }
  stopPreview(); const id = previewId;
  // Smaller utterances avoid browser speech engines dropping long scripts.
  const { splitText } = await import('./audio-core.mjs?v=speech-3');
  const chunks = splitText(value);
  function next() {
    if (id !== previewId) return;
    const chunk = chunks.next(); if (chunk.done) { if (!busy) status('Device preview finished.'); return; }
    const spoken = speechText(chunk.value, [], false);
    if (!spoken) { next(); return; }
    const utterance = new SpeechSynthesisUtterance(spoken); activeUtterance = utterance;
    const voice = deviceVoices[Number($('#voice').value)]; if (voice) utterance.voice = voice;
    utterance.rate = Number($('#rate').value); utterance.pitch = Number($('#pitch').value); utterance.volume = Number($('#volume').value);
    utterance.onend = next; utterance.onerror = event => { if (id === previewId && event.error !== 'canceled' && !busy) status('Device preview failed. Try another device voice.'); };
    synth.speak(utterance);
  }
  if (!busy) status('Playing device preview. This uses your device voice, not the downloadable studio voice.'); next();
}
let context;
function audioContext() { return context ||= new (window.AudioContext || window.webkitAudioContext)(); }
function tone(freq, length, type = 'sine', gain = .16, slide = 0, delay = 0) {
  const c = audioContext(), oscillator = c.createOscillator(), envelope = c.createGain(), now = c.currentTime + delay;
  oscillator.type = type; oscillator.frequency.setValueAtTime(freq, now);
  if (slide) oscillator.frequency.exponentialRampToValueAtTime(Math.max(30, freq + slide), now + length);
  envelope.gain.setValueAtTime(.001, now); envelope.gain.exponentialRampToValueAtTime(gain, now + .015); envelope.gain.exponentialRampToValueAtTime(.001, now + length);
  oscillator.connect(envelope).connect(c.destination); oscillator.start(now); oscillator.stop(now + length + .02);
}
function sound(name) {
  audioContext().resume();
  if (name === 'ding') { tone(660, .18); tone(990, .35, 'sine', .14, 0, .12); }
  if (name === 'pop') tone(180, .1, 'sine', .24, 500);
  if (name === 'laser') tone(1200, .4, 'sawtooth', .12, -1050);
  if (name === 'buzz') { tone(90, .35, 'square', .09); tone(110, .35, 'square', .06); }
  if (name === 'win') [523, 659, 784, 1046].forEach((freq, i) => tone(freq, .25, 'triangle', .13, 0, i * .11));
  if (name === 'whoosh') {
    const c = audioContext(), buffer = c.createBuffer(1, c.sampleRate * .48, c.sampleRate), data = buffer.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / data.length);
    const source = c.createBufferSource(), filter = c.createBiquadFilter(), gain = c.createGain(); filter.type = 'lowpass'; filter.frequency.value = 1600; gain.gain.value = .25;
    source.buffer = buffer; source.connect(filter).connect(gain).connect(c.destination); source.start();
  }
}
let countTimer; script.addEventListener('input', () => { clearTimeout(countTimer); countTimer = setTimeout(() => { updateCounts(); formatOutputs(); }, 150); });
$('#generate').onclick = () => generate(); $('#sample').onclick = () => generate(true);
$('#connectNative').onclick = async () => {
  if (busy || connectingNative) return;
  connectingNative = true; $('#connectNative').disabled = true;
  $('#nativeStatus').textContent = 'Connecting to your NVIDIA helper…';
  try {
    const info = await nativeHealth(nativeKey);
    nativeConnected = true; $('#engine').value = 'native';
    try { localStorage.setItem(LOCAL_HELPER_KEY, nativeKey); } catch {}
    $('#nativeStatus').textContent = 'Connected · ' + info.gpu + ' · CUDA · full precision';
    $('#engineStatus').textContent = 'NVIDIA CUDA ready · ' + info.gpu;
    status('NVIDIA connected. Preview your script to measure generation speed.');
  } catch (error) { nativeConnected = false; $('#nativeStatus').textContent = error.message; }
  finally { connectingNative = false; $('#connectNative').disabled = busy; }
};
$('#importScript').onclick = () => $('#scriptFile').click();
$('#scriptFile').onchange = async event => {
  const file = event.target.files[0];
  if (!file || busy) return;
  try {
    const value = await file.text();
    if (busy) return;
    script.value = value; outputs(); status('Script imported. Choose a voice or preview it.'); script.focus();
  } catch { status('Could not read this file. Please paste its text instead.'); }
  finally { event.target.value = ''; }
};
$('#cancel').onclick = () => {
  if (!run.ready) { worker?.terminate(); worker = null; void complete('Stopped before generation. No completed audio was lost.', true); return; }
  worker?.postMessage({ type: 'cancel' }); $('#cancel').disabled = true; $('#pauseGeneration').disabled = true;
  status('Stopping after the current section and saving its audio…');
};
$('#pauseGeneration').onclick = () => {
  run.pauseRequested = !run.pauseRequested;
  worker?.postMessage({ type: run.pauseRequested ? 'pause' : 'resume' });
  $('#pauseGeneration').textContent = run.pauseRequested ? '▶ Resume generation' : 'Ⅱ Pause generation';
  status(run.pauseRequested ? 'Pausing after the current section…' : 'Resuming generation…');
};
$('#restore').onclick = restore; $('#resumeSaved').onclick = resumeSaved;
['format', 'bitrate', 'engine'].forEach(id => $('#' + id).onchange = formatOutputs);
document.addEventListener('visibilitychange', () => { if (busy && document.visibilityState === 'visible') void keepAwake(); });
void offerSavedRecording('A previous recording is saved on this device.');
$('#preview').onclick = devicePreview;
$('#pause').onclick = () => { synth?.pause(); document.querySelectorAll('audio').forEach(audio => audio.pause()); if (!busy) status('Playback paused.'); };
$('#resume').onclick = () => { synth?.resume(); if (!busy) status('Device preview resumed. Use each recording’s play button for generated audio.'); };
$('#stop').onclick = () => { stopPreview(); document.querySelectorAll('audio').forEach(audio => { audio.pause(); audio.currentTime = 0; }); if (!busy) status('Playback stopped.'); };
$('#clear').onclick = () => { stopPreview(); script.value = ''; updateCounts(); script.focus(); };
$('#clearHistory').onclick = () => { history = []; try { localStorage.removeItem('tts-history'); } catch {} renderHistory(); };
document.querySelectorAll('[data-example]').forEach(button => button.onclick = () => { script.value = button.dataset.example==='story'?audioModels.defaultScript:examples[button.dataset.example]; updateCounts(); });
document.querySelectorAll('[data-voice]').forEach(button => button.onclick = () => selectVoice(button.dataset.voice));
document.querySelectorAll('[data-sound]').forEach(button => button.onclick = () => sound(button.dataset.sound));
$('#studioVoice').onchange = () => selectVoice($('#studioVoice').value);
['rate', 'pitch', 'volume'].forEach(id => $('#' + id).oninput = outputs);
window.addEventListener('beforeunload', event => { if (busy) { event.preventDefault(); event.returnValue = ''; } });
if (synth) { loadVoices(); synth.onvoiceschanged = loadVoices; }
const audioModels=setupAudioModels({document,status,onChange:selectVoice,isBusy:()=>busy});
selectVoice($('#studioVoice').value); outputs(); formatOutputs(); renderHistory();
if (nativeKey) setTimeout(() => $('#connectNative').click(), 120);

setInterval(() => { if(nativeKey && !nativeConnected && !busy && !connectingNative) $('#connectNative').click(); }, 10000);
