import {completedProductionEvidence,productionCalibrationSummary} from './pipeline-production-calibration.mjs?v=production-components-20261031';
import {qualityBlockedProductionEvidence} from './pipeline-production-components.mjs?v=production-components-20261031';
import {migrateDirectorForecast,directorProfileOptions,directorTimingLabel} from './pipeline-director-calibration.mjs?v=production-components-20261031';
import {createWorkerRequest} from './pipeline-worker-request.mjs?v=pipeline-admission-pilot-20261011';
import {indexTasks,dependsOnTask} from './pipeline-task-index.mjs?v=long-graph-20261009';
import {PREPARATION_GROUP,preparationGroup,compactPreparation,preparationMoves} from './pipeline-preparation-group.mjs?v=group-20261009';
import {PRICING_DATE,PRICING_URL} from './pipeline-pricing.mjs?v=pricing-20261009';
import {mountStartupTradeoffs,mountObservedRuns,mountFunctionIndex,startupApplyConfig} from './pipeline-detail-ui.mjs?v=production-components-20261031';
import {DEFAULTS,CATALOG,LANES,VERSION,buildPlan,schedule,formatTime,explainMove,importSnapshot} from './pipeline-engine.mjs?v=production-components-20261031';
import {mountConcurrencyLab} from './pipeline-lab.mjs?v=production-components-20261031';
import {serverlessHTML} from './pipeline-serverless.mjs';
import {matchedHTML} from './pipeline-matched.mjs?v=production-components-20261031';
import {gpuChoices,selectGPUConfig,executionLabel,generationSpeed,productionModeNote,plannerSourceState} from './pipeline-config.mjs?v=production-components-20261031';
import {mountGPUExplorer} from './pipeline-gpu-explorer.mjs?v=production-components-20261031';
import {pairingKey,helperJson} from './helper-connection.mjs?v=connection-20261009';
import {plannerSettings,profileSummary} from './studio-planner-profile.mjs?v=zero-retry-20261118';
import {realisticPlanningConfig,selectScenarioGPUConfig,reviewPolicyNote} from './pipeline-realistic.mjs?v=production-components-20261031';
import {denseActive,denseLeaseRetained,imageRentalPercent} from './pipeline-dense.mjs?v=production-components-20261031';
import {STRATEGIES} from './studio-generation-plan.mjs?v=dense-lease-20261118';
const strategyLabel=value=>STRATEGIES.find(([id])=>id===value)?.[1]||value;
const $=id=>document.getElementById(id), esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money=n=>'$'+n.toFixed(2), sec=n=>n<60?n.toFixed(1)+'s':(n/60).toFixed(1)+'m';
const STORE='questiontemplate-production-planner-v1';
const keys=Object.keys(DEFAULTS),booleans=keys.filter(k=>typeof DEFAULTS[k]==='boolean');
let gpuExplorer;
let studioFollowing=true,studioProject='',studioRevision=null,studioLoading=false,studioNeedsRefresh=false;
let studioAppliedProfile=null;
function studioManual(){studioFollowing=false;studioAppliedProfile=null;$('followStudio').checked=false;$('studioProfileStatus').textContent='Manual planning scenario · saved Studio settings are unchanged.';persist();}
async function loadStudioSettings({refresh=false,initial=false}={}){
  if(studioLoading){studioNeedsRefresh=true;return;}studioLoading=true;
  try{
    const key=pairingKey();if(!key)throw Error('Open Studio and connect the shared helper to load saved settings. Practical checks remain the default scenario.');
    const projects=await helperJson('/studio/projects',key);
    const requested=(initial?new URLSearchParams(location.search).get('project'):null)||$('studioProject').value||studioProject||localStorage.getItem('qt-production-project');
    studioProject=projects.some(p=>p.id===requested)?requested:projects[0]?.id;
    if(!studioProject)throw Error('No saved Studio project. Practical checks remain the default scenario.');
    $('studioProject').replaceChildren(...projects.map(p=>new Option(p.name,p.id,p.id===studioProject,p.id===studioProject)));
    const requestedId=studioProject;
    const profile=await helperJson('/studio/planner-profile?project='+encodeURIComponent(requestedId),key);
    if(requestedId!==studioProject)return;
    const previous=profile.lastProductionStrategy ? ` · last recorded run: ${strategyLabel(profile.lastProductionStrategy)}` : '';
    $('studioProfileSummary').textContent=profileSummary(profile)+` · next run: ${strategyLabel(profile.generationStrategy ?? 'align')}${previous}`;
    const mapped=plannerSettings(config,profile,evidence);
    $('studioProfileWarnings').textContent=mapped.warnings.join(' ');
    if(studioFollowing&&(refresh||profile.revision!==studioRevision||!studioAppliedProfile)){
      const installedQueue=profile.imageExecution?.backend==='comfyui-api' && [1,2].includes(profile.imageExecution.gpuLanes);
      let next=installedQueue ? {...mapped.config,gpuStartSeconds:0} : selectGPUConfig({...mapped.config,gpuStartSeconds:0},evidence,config.gpu);
      buildPlan(next,evidence);
      if(profile.generationStrategy==='align'&&profile.timedHistoryReady){
        const search=await studioScheduleRequest.run({type:'startup',config:next,evidence,searchPolicy:next.policy});
        if(!studioFollowing||requestedId!==studioProject||!search)return;
        const aligned=search.values.find(v=>v.balanced&&v.keepFastestVideo===false);
        if(aligned)next={...next,readyChapters:aligned.readyChapters,gpuStartSeconds:aligned.gpuStartSeconds};
      }
      if(!studioFollowing||requestedId!==studioProject)return;
      if(!initial)checkpoint(false);
      config=next;preferences={};selected=null;setControls();await rebuild();
      if(renderedGeneration!==computeGeneration)throw Error('The saved setup could not finish calculating. The displayed scenario is not verified against this project.');
      if(studioFollowing&&requestedId===studioProject)studioAppliedProfile={project:requestedId,revision:profile.revision};
    }
    studioRevision=profile.revision;
    $('studioProfileStatus').textContent=studioFollowing?`Following saved Studio setup · visual checks ${profile.settings.qcCheckLevel} · revision ${profile.revision}. No paid work started.`:'Saved setup available · manual scenario retained. Enable Follow to apply it.';
  }catch(error){studioAppliedProfile=null;$('studioProfileStatus').textContent='Saved setup not applied: '+error.message;$('studioProfileWarnings').textContent='The retained scenario is not following this saved project. Its local narration timings do not estimate Kaggle voices.';}
  finally{studioLoading=false;persist();if(studioNeedsRefresh){studioNeedsRefresh=false;void loadStudioSettings({refresh:true});}}
}
let renderResearchStarted=false;
let directorStudy,directorStudyLoading=false;
async function loadDirectorStudy(){
  if(directorStudyLoading||directorStudy)return;directorStudyLoading=true;
  try{
    const {mountDirectorStudy}=await import('./pipeline-director-study.mjs?v=decisions-evidence-20261010b');
    directorStudy=await mountDirectorStudy($('directorResearch'),config.minutes);
  }catch{$('directorResearch').textContent='Director study unavailable. The existing planner remains usable.';}
  finally{directorStudyLoading=false;}
}
async function loadRenderResearch(){
  if(renderResearchStarted)return;renderResearchStarted=true;
  try{const {mountRenderResearch}=await import('./pipeline-render-research.mjs?v=render-research-20261009');await mountRenderResearch($('renderResearch'));}
  catch{$('renderResearch').textContent='Video-render research unavailable. Existing planner remains usable.';}
}
let mountGPUPanels=()=>{},loadOptionalPanels=()=>{},optionalPanelsStarted=false;
let taskLookup=new Map();
let preparation,preparationCompact=true;
const plannerRequest=createWorkerRequest(()=>new Worker(new URL('./pipeline-worker.mjs?v=production-components-20261031',import.meta.url),{type:'module'}));
const comparisonRequest=createWorkerRequest(()=>new Worker(new URL('./pipeline-worker.mjs?v=production-components-20261031',import.meta.url),{type:'module'}));
const studioScheduleRequest=createWorkerRequest(()=>new Worker(new URL('./pipeline-worker.mjs?v=production-components-20261031',import.meta.url),{type:'module'}));
let comparisonKey='',comparisonPendingKey='',comparisonSummary;
let computeGeneration=0,renderedGeneration=-1,controlTimer;
let evidence,config={...DEFAULTS},preferences={},plan,result,serial,selected=null,uncertainty=20,history=[],view='schedule',focus='all',scale=1,positions=new Map(),playing=false,playAt=0,playStarted=0,playFrame,saveTimer,toastTimer;
const snapshot=()=>({pricingChecked:PRICING_DATE,pricingSource:PRICING_URL,type:'studio-pipeline-plan',version:VERSION,config:{...config},preferences:structuredClone(preferences),uncertainty,studioSource:plannerSourceState(studioProject,studioFollowing,studioAppliedProfile)});
function checkpoint(manual=true){history.push(snapshot());if(history.length>40)history.shift();$('undo').disabled=false;if(manual)studioManual();}
function toast(message){$('toast').textContent=message;$('toast').hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').hidden=true,4500);}
function persist(){clearTimeout(saveTimer);saveTimer=setTimeout(()=>{try{localStorage.setItem(STORE,JSON.stringify(snapshot()));$('saved').textContent='Saved on this device';}catch{$('saved').textContent='Device storage unavailable — export your plan';}},180);}
function setControls(){for(const k of keys){if(!$(k))continue;if(booleans.includes(k))$(k).checked=config[k];else $(k).value=config[k];}$('readyChapters').max=config.chapters;$('uncertainty').value=uncertainty;}
function readControls(){const next={};for(const k of keys){if(!$(k))continue;next[k]=booleans.includes(k)?$(k).checked:typeof DEFAULTS[k]==='number'?Number($(k).value):$(k).value;}return {...config,...next};}
function getTask(id){return id===PREPARATION_GROUP?preparation:taskLookup.get(id);}
function renderGenerationSpeed(){
  const speed=generationSpeed(plan,evidence);
  $('generationRate').value=speed.current===null?'Not measured':speed.current.toFixed(1);
  $('generationRateNote').textContent=plan.currentProductionComponentsUsed?plan.currentProductionComponentsWarning:plan.productionCalibrationUsed?plan.productionCalibrationWarning:plan.sourceBurstProjectionUsed?plan.sourceBurstProjectionWarning:speed.highest===null?'No completed generation-speed measurement for this timing profile. Choose a measured resolution.':
    `Selected setup: ${executionLabel(plan)}. This measured warm rate includes preparation, transfer and saving once, but excludes startup, Luna/QC waiting and rendering. It is not measured full-production throughput.`+
    (speed.isFastest?'':` Fastest benchmark comparison: ${speed.highest.toFixed(1)} images/min; it is not substituted into this schedule.`);
  $('fastestGPU').disabled=speed.highest===null||speed.isFastest;
}
function labelChapter(n){return n===0?'Project / intro':`Chapter ${String(n).padStart(2,'0')}`;}
function switchView(next){view=next;document.querySelectorAll('[data-view]').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.view===next)));for(const name of ['schedule','processes','gpus','observed','evidence'])$(name+'View').hidden=name!==next;if(next==='schedule')renderTimeline();if(['gpus','processes','observed'].includes(next))void loadOptionalPanels();if(next==='evidence')void loadDirectorStudy();if(next==='gpus'){void loadRenderResearch();mountGPUPanels();if(result)renderGPUs();}}
async function rebuild(){
  stopPlay();
  const generation=++computeGeneration;plannerRequest.cancel();comparisonRequest.cancel();comparisonPendingKey='';
  const startupHost=$('startTradeoffs');startupHost._startupGeneration=(startupHost._startupGeneration||0)+1;startupHost._startupWorker?.terminate();startupHost._startupWorker=null;startupHost._startupKey=null;
  $('saved').textContent='Calculating in the background…';
  $('export').disabled=true;$('play').disabled=true;
  $('timeline').inert=true;$('taskInspector').inert=true;
  $('plannerWorkspace').setAttribute('aria-busy','true');
  $('metricTime').textContent='Calculating…';$('metricCost').textContent='—';
  $('metricRange').textContent='Updated estimate pending';
  $('metricCostParts').textContent='Waiting for the current settings';
  try{
    const computed=await plannerRequest.run({type:'plan',config,evidence,preferences});
    if(!computed||generation!==computeGeneration)return;
    ({plan,result,serial}=computed);taskLookup=indexTasks(result.tasks);
    if(result.diagnostics.length)throw Error(result.diagnostics.join('; '));
    $('error').hidden=true;
    config=plan.config;setControls();
    gpuExplorer?.updateProject(config,evidence);
    renderGenerationSpeed();
    const groupHelp='Group size sets the scheduling model’s granularity. It can change projected overlap, time and cost. Production sends the same images and checks.';
    $('batch').nextElementSibling.textContent=plan.groupSize>config.batch
      ? `This timeline uses groups of ${plan.groupSize} images (requested ${config.batch}). ${groupHelp}`
      : groupHelp;
    $('sampleField').hidden=config.qc!=='sampled';$('introFields').hidden=!config.intro;
    $('qcPolicyNote').textContent=reviewPolicyNote(config,result,evidence);
    $('modeNote').textContent=productionModeNote(config);
    const dense=denseActive(config);
    const retained=denseLeaseRetained(config);
    $('readyChapters').disabled=dense;$('earlyGpu').disabled=dense;
    $('repairRoundsField').hidden=!dense||config.retries===0;
    $('repairRounds').max=String(config.productionDenseMaxRepairRounds||1);
    $('repairRounds').nextElementSibling.textContent=retained?'Splits the extra-attempt allowance into assumed rounds on the same paid lease. Required checks and saved retry limits stay unchanged.':'Distributes your extra-attempt allowance across separately billed rentals. It does not change saved retry limits or predict a defect rate.';
    $('scheduleDescription').textContent=`${config.policy==='proposed'?'Proposed':config.policy==='current'?'Installed overlap model':'Sequential baseline'} · ${plan.director.label} · ${config.directorTier} · ${plan.imageCount} images · ${result.tasks.length} operations · ${Object.keys(preferences).length} manual moves`;
    $('metricTime').textContent=formatTime(result.end);
    $('metricRange').textContent=(plan.currentProductionComponentsUsed?'Quality-blocked source · finish unproven · ':plan.director.timingMeasured?'':plan.director.conditionsMatch===false?'Unmeasured saved configuration · ':plan.director.slotsMatch===false?'Unmeasured API-slot timing · ':'Unmeasured tier timing · ')+`${formatTime(result.end*(1-uncertainty/100))}–${formatTime(result.end*(1+uncertainty/100))} assumed sensitivity`;
    const comparable=!plan.currentProductionComponentsUsed&&!plan.productionCalibrationUsed&&!plan.sourceBurstProjectionUsed&&serial.comparisonMatched!==false;
    const saving=comparable?1-result.end/serial.end:null;$('metricSaved').textContent=comparable?(saving*100).toFixed(0)+'% '+(saving>=0?'less time':'more time'):'Not comparable';
    $('metricSerial').textContent=comparable?`${formatTime(serial.end)} fully sequential`:'Sequential reference has a different timing basis; no same-work saving claimed.';
    $('metricCost').textContent=money(result.totalUSD);$('metricCostParts').textContent=`${money(result.gpuUSD)} GPU + ${money(result.directorUSD)} Luna + ${money(result.qcUSD)} QC${plan.productionCalibrationUsed?' + '+money(result.archiveUSD)+' GCS':''} + ${money(result.storageUSD)} storage`;
    $('pricingNote').textContent=plan.gpu.pricing.note;
    $('directorTimingNote').textContent=`${plan.director.label}. ${plan.director.scope} ${directorTimingLabel(plan.director)}`;
    $('flexTimingField').hidden=config.directorTier!=='flex'||plan.director.tierMeasured;
    $('directorTier').querySelector('option[value="flex"]').textContent=config.directorTier==='flex'&&plan.director.tierMeasured?'Flex · measured timing and receipts':'Flex · half token price · unmeasured delay';
    $('apiSlots').disabled=plan.director.aggregated;
    if(plan.director.aggregated)$('apiSlots').value=String(plan.director.slots);
    $('directorSlotsNote').textContent=plan.director.aggregated?`${plan.director.slots} API slots reserved. ${config.directorActualSlots?'Uses the saved production limit; timing at a different slot count is unmeasured.':'Tested concurrency is already included in the observed elapsed time.'} No extra speed multiplier.`:'Historical API pool; individual pass weights are assumptions.';
    if(config.directorCostMode==='measured')$('directorCost').value=plan.director.costPerTwoHours.toFixed(6);
    $('quotedGPUHourly').disabled=config.pricingBasis!=='quote';
    $('metricBusyLabel').textContent=plan.measurement?'Image pipeline / rented':'GPU work / rented';$('metricBusy').textContent=imageRentalPercent(result);
    $('metricImages').textContent=`${formatTime(result.rentalSeconds)} rented · ${plan.attemptCount} image attempts`+(retained?` · ${formatTime(result.heldQCIdleSeconds)} paid QC waiting`:dense?` · ${result.rentalWindows.length} assumed rental ${result.rentalWindows.length===1?'window':'windows'}`:'');
    if(dense)$('modeNote').textContent+=config.retries>0?` Your ${config.retries}% extra-attempt allowance uses ${plan.repairRoundCount} assumed repair rounds ${retained?'on the same paid lease':'with separate startup/stop'}. This is not a measured failure rate.`:` No extra-attempt rate is assumed; unknown repairs ${retained?'and their additional held-lease time':'and their additional rentals'} remain conditional and are excluded from this scenario.`;
    $('taskCount').textContent=`${result.tasks.length} tasks · ${plan.measurement?plan.measurement.workers+' measured workers on one GPU'+(config.executionMode!=='resident'?' · '+plan.measurement.clientSlots+' request slots':''):'one inference lane'}`;
    $('profileScope').textContent=(plan.measurement?`${config.resolution} image pipeline · ${plan.measurement.workers} workers${config.executionMode!=='resident'?' · '+plan.measurement.clientSlots+' request slots':''} · ${config.encodingProfile} conditioning`:'Historical 1344 × 768 images · one worker')+` · video ${config.videoResolution}/${config.videoFps}fps`;
    $('renderTimingNote').textContent=plan.renderScope;
    $('workerField').hidden=config.resolution==='legacy';
    $('workerLabel').textContent=config.executionMode==='resident'?'Model copies on one GPU':'Request slots on one GPU';
    $('workerNote').textContent=config.executionMode==='resident'?'Each worker is a separate model copy, not another GPU. Installed mode keeps the supported single-copy comparison.':`${plan.measurement?.workers||config.productionModelCopies} model copies serve ${plan.measurement?.clientSlots||config.productionRequestSlots} bounded request slots. Slots include queued/preparing requests; they do not mean that many simultaneous model copies or GPUs.`;
    $('currentProductionCalibration').textContent=productionCalibrationSummary(evidence,plan);
    const completedOption=$('productionCalibration').querySelector('option[value="current-production-20261031"]');
    completedOption.disabled=!completedProductionEvidence(evidence);
    completedOption.textContent=completedOption.disabled?'Current completed production · awaiting evidence':'Current complete source · matching cached two-copy setup';
    $('productionCalibration').querySelector('option[value="current-components-20261031"]').disabled=!qualityBlockedProductionEvidence(evidence);
    if(plan.currentProductionComponentsUsed)$('modeNote').textContent+=' '+plan.currentProductionComponentsWarning;
    else if(plan.productionCalibrationUsed)$('modeNote').textContent+=' '+plan.productionCalibrationWarning;
    else if(plan.sourceBurstProjectionUsed)$('modeNote').textContent+=' '+plan.sourceBurstProjectionWarning;
    else if(plan.measurement)$('modeNote').textContent+=` Measured worker groups include image preparation through saving once. Internal stages cannot be moved separately from these aggregate measurements. ${plan.renderScope}`;
    const oldFocus=focus;
    $('chapterFocus').innerHTML='<option value="all">All chapters</option><option value="0">Project / intro</option>'+Array.from({length:config.chapters},(_,i)=>`<option value="${i+1}">Chapter ${String(i+1).padStart(2,'0')}</option>`).join('');
    focus=oldFocus==='all'||Number(oldFocus)<=config.chapters?oldFocus:'all';$('chapterFocus').value=focus;
    if(selected&&!getTask(selected))selected=null;
    renderTimeline();renderBreakdown();renderProcesses();renderPairs();renderEvidence();renderInspector();
    directorStudy?.update(config.minutes);
    mountStartupTradeoffs($('startTradeoffs'),config,evidence,settings=>{checkpoint();config=startupApplyConfig(config,settings);preferences={};setControls();rebuild();toast('GPU startup timing applied to the planner. Production settings remain unchanged.');});
    if(view==='gpus')renderGPUs();persist();
    renderedGeneration=generation;
    $('export').disabled=false;$('play').disabled=false;
    $('timeline').inert=false;$('taskInspector').inert=false;
    $('plannerWorkspace').setAttribute('aria-busy','false');
  }catch(e){if(generation!==computeGeneration)return;$('error').textContent=e.message;$('error').hidden=false;$('metricTime').textContent='Unavailable';$('metricRange').textContent='The current settings could not be calculated';$('plannerWorkspace').setAttribute('aria-busy','false');}
}
function renderTimeline(){
  if(!result||view!=='schedule')return;
  const zoom=Number($('zoom').value),min=Math.max(620,$('timeline').clientWidth-155),usable=min*zoom;
  scale=usable/(result.end*1.04);const width=Math.ceil(usable+155),step=Math.max(result.end>7200?1800:result.end>3600?900:300,Math.ceil(result.end/24/60)*60);
  positions=new Map();let html='<div class="timeline-inner" style="width:'+width+'px"><div class="ruler"><span class="label">Elapsed production time</span>';
  for(let t=0;t<=result.end;t+=step)html+=`<span class="tick" style="left:${155+t*scale}px">${Math.round(t/60)}m</span>`;
  html+='</div>';let top=34;
  const visible=result.tasks.filter(t=>focus==='all'||t.chapter===Number(focus)||['boot','models','health','cold','stop','join','probe','decode','preflight'].includes(t.kind));
  preparation=preparationGroup(visible);
  const display=compactPreparation(visible,preparationCompact);
  const links=selected&&getTask(selected)?new Set([selected,...getTask(selected).deps,...result.tasks.filter(t=>t.deps.includes(selected)).map(t=>t.id)]):new Set();
  for(const [id,name,note] of LANES){
    const laneTasks=display.filter(t=>t.lane===id).sort((a,b)=>a.start-b.start),trackEnds=[];let bars='';
    for(const task of laneTasks){
      const left=155+task.start*scale,bw=Math.max(8,task.duration*scale-1);
      let track=trackEnds.findIndex(n=>n<=left-2);if(track<0)track=trackEnds.length;trackEnds[track]=left+bw;
      const y=11+track*32;positions.set(task.id,{x:left,y:top+y,w:bw,h:27});
      const grouped=task.id===PREPARATION_GROUP,short=grouped?`${task.chapters.length} CH`:task.chapter===0?'P':`C${String(task.chapter).padStart(2,'0')}`;
      const barWidth=grouped?Math.max(bw,125):bw;
      trackEnds[track]=left+barWidth;
      bars+=`<button class="task ${grouped?'preparation-group':''} ${task.manual?'manual':''} ${task.id===selected?'selected':''} ${links.has(task.id)?'related':''}" data-id="${esc(task.id)}" data-lane="${id}" style="left:${left}px;top:${y}px;width:${barWidth}px" aria-label="${esc(grouped?task.name+' · '+task.members.length+' steps · '+task.chapters.length+' chapters':task.name+' · '+labelChapter(task.chapter)+' · '+task.id)}" title="${esc(task.id+' | '+task.name+' | '+formatTime(task.start)+' → '+formatTime(task.end)+' | '+sec(grouped?task.work:task.duration)+(grouped?' total work; span includes gaps. Click to inspect or expand.':''))}">${barWidth>23?`<em>${short}</em>`:''}${barWidth>85?esc(grouped?'Story preparation':task.name):''}</button>`;
    }
    const height=Math.max(53,trackEnds.length*32+20);
    html+=`<div class="lane" style="height:${height}px" data-lane="${id}"><div class="lane-label"><strong>${name}</strong><small>${id==='qc'&&config.qc==='off'?'Vision off · decode stays':note}</small></div>${bars}</div>`;top+=height;
  }
  for(let t=0;t<=result.end;t+=step)html+=`<i class="gridline" style="left:${155+t*scale}px"></i>`;
  let paths='';if(selected&&positions.has(selected)){
    const to=positions.get(selected);
    for(const dep of getTask(selected).deps){const from=positions.get(dep);if(!from)continue;const a=from.x+from.w,b=from.y+13,c=to.x,d=to.y+13;paths+=`<path d="M ${a} ${b} C ${a+18} ${b},${c-18} ${d},${c} ${d}"/>`;}
  }
  html+=`<svg class="dependencies" width="${width}" height="${top}" aria-hidden="true"><g fill="none" stroke="#64826d" stroke-width="1.2" stroke-dasharray="3 3">${paths}</g></svg><i class="playhead" id="playhead" style="left:155px" hidden></i></div>`;
  $('timeline').innerHTML=html;
  for(const button of $('timeline').querySelectorAll('.task')){
    button.addEventListener('click',()=>selectTask(button.dataset.id));
    button.addEventListener('keydown',e=>{
      if(!['ArrowLeft','ArrowRight'].includes(e.key))return;e.preventDefault();const t=getTask(button.dataset.id);moveTask(t.id,t.start+(e.key==='ArrowLeft'?-1:1)*(e.shiftKey?30:1));
      $('timeline').querySelector(`[data-id="${t.id}"]`)?.focus();
    });
    button.addEventListener('pointerdown',beginDrag);
  }
}
function selectTask(id){selected=id;renderInspector();if(view==='schedule')renderTimeline();}
function beginDrag(event){
  if(event.button!==0)return;
  const button=event.currentTarget,id=button.dataset.id,task=getTask(id),startX=event.clientX,scroll=$('timeline').scrollLeft;
  let delta=0,moved=false;button.setPointerCapture(event.pointerId);
  const onMove=e=>{delta=e.clientX-startX+$('timeline').scrollLeft-scroll;if(Math.abs(delta)>4)moved=true;if(moved){button.classList.add('dragging');button.style.transform=`translateX(${delta}px)`;const target=Math.max(0,Math.round(task.start+delta/scale));$('moveFeedback').textContent=`${id} → ${formatTime(target)}. ${id===PREPARATION_GROUP?'All member starts shift together; original dependencies and resource limits remain enforced.':explainMove(plan,result,id,target,taskLookup)}`;}};
  const finish=e=>{button.removeEventListener('pointermove',onMove);button.removeEventListener('pointerup',finish);button.removeEventListener('pointercancel',cancel);if(button.hasPointerCapture(event.pointerId))button.releasePointerCapture(event.pointerId);if(moved){e.preventDefault();moveTask(id,Math.max(0,Math.round(task.start+delta/scale)));}else selectTask(id);};
  const cancel=()=>{button.removeEventListener('pointermove',onMove);button.removeEventListener('pointerup',finish);button.removeEventListener('pointercancel',cancel);renderTimeline();};
  button.addEventListener('pointermove',onMove);button.addEventListener('pointerup',finish);button.addEventListener('pointercancel',cancel);
}
async function moveTask(id,target){
  if(!Number.isFinite(target)||target<0){toast('Choose a finite, nonnegative start time.');return;}
  if(id===PREPARATION_GROUP){checkpoint();preferences=preparationMoves(preparation,target,preferences);selected=id;await rebuild();$('moveFeedback').textContent='Preparation members moved together. Original dependencies and shared-resource checks remain enforced; the span includes any waiting gaps.';return;}
  target=Math.max(0,target);const why=explainMove(plan,result,id,target,taskLookup);checkpoint();preferences[id]={...preferences[id],notBefore:target};selected=id;await rebuild();const moved=getTask(id);if(!moved)return;
  $('moveFeedback').textContent=`${id}: requested ${formatTime(target)}, scheduled ${formatTime(moved.start)}. ${moved.start>target+.1?why+' Dependencies or capacity pushed it later.':'Dependent tasks were re-scheduled; all resource checks pass.'}`;
}
function renderInspector(){
  const task=selected&&getTask(selected);if(!task)return;
  if(task.id===PREPARATION_GROUP){renderPreparationInspector(task);return;}
  const meta=CATALOG.find(m=>m.id===task.kind);
  $('inspectorLabel').textContent=task.manual?'MANUAL START':'SCHEDULED';
  const resources=Object.entries(task.resources).map(([r,n])=>`<span class="res-tag">${esc(r)} · ${n} / ${plan.capacities[r]}</span>`).join('')||'<span class="res-tag">No exclusive resource</span>';
  $('taskInspector').innerHTML=`<h3 class="task-title">${esc(task.name)}</h3><div class="task-id">${esc(task.id)} · ${labelChapter(task.chapter)}</div><p class="task-desc">${esc(meta.description)}</p><div class="task-times"><div><span>Starts</span><strong>${formatTime(task.start)}</strong></div><div><span>Ends</span><strong>${formatTime(task.end)}</strong></div><div><span>Work</span><strong>${sec(task.duration)}</strong></div></div><div class="inspect-section"><h3>Resources reserved</h3>${resources}<p style="margin-top:7px">Units are scheduling constraints, not measured CPU utilization.</p></div><div class="inspect-section"><h3>Must finish first · ${task.deps.length}</h3>${task.deps.slice(0,12).map(id=>{const dep=getTask(id);return `<button class="dep" data-select="${esc(id)}">${esc(id)}<br>${esc(dep.name)} · ends ${formatTime(dep.end)}</button>`;}).join('')||'<p>No preceding task.</p>'}${task.deps.length>12?`<p>${task.deps.length-12} more dependencies are in the JSON below and exported plan.</p>`:''}</div><div class="inspect-section"><h3>Can run alongside</h3><p>${esc(meta.parallel)}</p></div><div class="inspect-section"><h3>Timing evidence</h3><p>${esc(task.basis||meta.basis)}</p>${task.images?`<p>${task.images} ${task.workers?task.workers+' worker':'sequential'} image${task.images===1?'':'s'} in this group.</p>`:''}<p>${denseActive(config)?'Each Boot → Stop window bills continuously, including its setup and gaps. Confirmed powered-off QC gaps between dense windows are not rented.':'GPU rental bills continuously from Boot through Stop, including idle gaps.'}</p></div><div class="task-fields"><label>Requested start · seconds<input id="taskStart" type="number" min="0" step="1" value="${Math.round(task.start)}"></label><button class="button" id="applyMove">Move this task</button><label>Scheduling priority<input id="taskPriority" type="number" min="-1000000" max="1000000" step="1" value="${preferences[task.id]?.priority??task.priority}"><small>Lower values go first among equally ready work. Dependencies still apply.</small></label><button class="button" id="applyPriority">Set priority</button><button class="button" id="clearMove" ${task.manual?'':'disabled'}>Clear manual start</button></div><details class="inspect-section"><summary>All task data</summary><pre style="font:9px/1.5 var(--mono);white-space:pre-wrap;overflow-wrap:anywhere">${esc(JSON.stringify(task,null,2))}</pre></details>`;

  if(task.includedStages?.length)$('taskInspector').insertAdjacentHTML('beforeend',`<details class="inspect-section"><summary>Included measured Luna passes</summary><p class="caption">These pass observations are already inside the chapter block. Call work overlaps; it is not added again or independently movable from this aggregate.</p>${task.includedStages.map(p=>`<p>${esc(p.name)} · ${p.calls} calls · ${sec(p.activeSeconds)} active · ${sec(p.callWorkSeconds)} call work · ${money(p.estimatedUSD)}</p>`).join('')}</details>`);
  $('applyMove').onclick=()=>moveTask(task.id,Number($('taskStart').value));
  $('applyPriority').onclick=()=>{const value=Number($('taskPriority').value);if(!Number.isFinite(value)||Math.abs(value)>1000000){toast('Priority must be between −1000000 and 1000000.');return;}checkpoint();preferences[task.id]={notBefore:preferences[task.id]?.notBefore||0,priority:value};rebuild();};
  $('clearMove').onclick=()=>{checkpoint();delete preferences[task.id];rebuild();};
  $('taskInspector').querySelectorAll('[data-select]').forEach(b=>b.onclick=()=>selectTask(b.dataset.select));
}
function renderPreparationInspector(group){
  $('inspectorLabel').textContent='COMPACT GROUP';
  $('taskInspector').innerHTML=`<h3 class="task-title">Load story state + clean narration</h3><p class="task-desc">${group.members.length} original steps across ${group.chapters.length} chapters, displayed as one block. No work, timing or costs have been removed.</p><div class="task-times"><div><span>Starts</span><strong>${formatTime(group.start)}</strong></div><div><span>Ends</span><strong>${formatTime(group.end)}</strong></div><div><span>Actual work</span><strong>${sec(group.work)}</strong></div></div><p class="caption">The displayed span includes gaps. Its minimum readable width does not extend the actual timing. Dragging shifts all member start constraints; dependencies can push individual members later.</p><label>Group start · seconds<input id="preparationStart" type="number" min="0" step="1" value="${group.start}"></label><button id="movePreparation" class="button">Move preparation group</button><button id="expandPreparation" class="button">Show individual steps</button><details class="inspect-section"><summary>All ${group.members.length} member steps</summary><div class="preparation-members">${group.members.map(t=>`<button class="dep" data-preparation-member="${esc(t.id)}">${esc(t.id)} · ${esc(t.name)}<br>${formatTime(t.start)} → ${formatTime(t.end)} · ${sec(t.duration)}</button>`).join('')}</div></details>`;
  $('movePreparation').onclick=()=>moveTask(PREPARATION_GROUP,Number($('preparationStart').value));
  $('expandPreparation').onclick=()=>{$('compactPreparation').checked=false;preparationCompact=false;renderTimeline();};
  $('taskInspector').querySelectorAll('[data-preparation-member]').forEach(b=>b.onclick=()=>{preparationCompact=false;$('compactPreparation').checked=false;selectTask(b.dataset.preparationMember);});
}
function renderBreakdown(){
  const groups=[['Directing',t=>t.lane==='director'],['Narration',t=>t.lane==='audio'],[plan.measurement?'Measured image pipeline':'Cloud GPU work',t=>t.resources.remote],['Preparation & transfer',t=>['prepare','transfer'].includes(t.lane)],['Vision QC',t=>t.lane==='qc'],['Save & state',t=>t.lane==='save'],['Rendering',t=>t.lane==='render'],['Setup & delivery',t=>['setup','finish'].includes(t.lane)]];
  const vals=groups.map(([label,predicate])=>({label,value:result.tasks.filter(t=>t.kind!=='qcBoundary'&&predicate(t)).reduce((n,t)=>n+t.duration,0)})),max=Math.max(...vals.map(v=>v.value));
  $('workBreakdown').innerHTML=vals.map(v=>`<div class="workrow"><span>${v.label}</span><div class="bar"><i style="width:${v.value/max*100}%"></i></div><span class="time">${sec(v.value)}</span></div>`).join('')+'<p class="caption">These are task work totals. Overlap makes their sum exceed elapsed production time. QC boundary spans are timing constraints and are excluded from these work sums. Cold loading belongs to image work. Measured worker groups also include transfer and saving; this is not GPU utilization.</p>';
  const windows=denseActive(config)?result.rentalWindows.map(w=>[w.phase==='continuous'?'One lease · images, QC and repairs':w.phase==='initial'?'Initial image rental':`Assumed repair rental ${w.round}`,`${formatTime(w.end-w.start)} · ${money((w.end-w.start)/3600*plan.gpu.hourly)}`]):[];
  $('costBreakdown').innerHTML=[['GPU + running container rental',money(result.gpuUSD)],...windows,['Rental time',formatTime(result.rentalSeconds)],['GPU idle/setup time',formatTime(result.gpuIdleSeconds)],...(denseLeaseRetained(config)?[['Paid QC waiting · included in rental',`${formatTime(result.heldQCIdleSeconds)} · ${money(result.heldQCIdleUSD)}`]]:[]),['Luna / QC estimate',money(result.apiUSD)],...(plan.productionCalibrationUsed?[[`Google archive · ${plan.productionCalibration.archiveCostBasis}`,money(result.archiveUSD)]]:[]),['Run estimate · before shared storage',money(result.productionUSD)],[`Shared storage · ${config.storageDays} days`,money(result.storageUSD)],['Total with allocated storage',money(result.totalUSD)]].map(([k,v])=>`<div class="costrow"><span>${k}</span><strong>${v}</strong></div>`).join('');
}
function renderProcesses(){
  $('processCount').textContent=CATALOG.length;const query=$('processSearch').value.toLowerCase();
  $('processList').innerHTML=CATALOG.filter(m=>(m.name+' '+m.description+' '+m.basis).toLowerCase().includes(query)).map(m=>{
    const tasks=result.tasks.filter(t=>t.kind===m.id),duration=tasks.reduce((n,t)=>n+t.duration,0);
    const index=CATALOG.indexOf(m)+1;
    return `<div class="process-row"><span>${String(index).padStart(2,'0')}</span><div><button data-process="${m.id}">${esc(m.name)}</button><p>${esc(m.description)}</p></div><div class="resource">${esc(LANES.find(l=>l[0]===m.lane)[1])}<p>${tasks.length?sec(duration)+(m.id==='qcBoundary'?' boundary spans · ':' work · ')+tasks.length+' tasks':'Nested / conditional'}</p></div><span class="basis">${m.id==='qcBoundary'?'Constraint, not extra work':['introPlan','vision','decode','repair','retryJSON'].includes(m.id)?'Optional / conditional':tasks.length?'Scheduled parent':'Nested, not extra work'}</span></div>`;
  }).join('')||'<div class="inline-note">No processes match. Try “voice”, “reference” or “render”.</div>';
  $('processList').querySelectorAll('[data-process]').forEach(b=>b.onclick=()=>{
    const m=CATALOG.find(x=>x.id===b.dataset.process),task=result.tasks.find(t=>t.kind===m.id);
    if(task){selectTask(task.id);}else{
      $('inspectorLabel').textContent='NESTED / CONDITIONAL';$('taskInspector').innerHTML=`<h3 class="task-title">${esc(m.name)}</h3><p class="task-desc">${esc(m.description)}</p><div class="inspect-section"><h3>Requires</h3><p>${esc(m.requires)}</p></div><div class="inspect-section"><h3>Parallelism</h3><p>${esc(m.parallel)}</p></div><div class="inspect-section"><h3>Accounting</h3><p>${esc(m.basis)}</p></div>`;
    }
  });
}
function renderPairs(){
  const options=result.tasks.map(t=>`<option value="${t.id}">${esc(t.id+' · '+t.name)}</option>`).join(''),a=$('pairA').value,b=$('pairB').value;
  $('pairA').innerHTML=options;$('pairB').innerHTML=options;
  $('pairA').value=getTask(a)?a:(result.tasks.find(t=>t.kind==='prompt'&&t.chapter===2)||result.tasks[0]).id;
  $('pairB').value=getTask(b)?b:(result.tasks.find(t=>t.kind==='infer'&&t.chapter===1)||result.tasks.at(-1)).id;
  pairResult();
}
function dependsOn(task,id){return dependsOnTask(taskLookup,task.id,id);}
function pairResult(){
  const a=getTask($('pairA').value),b=getTask($('pairB').value);if(!a||!b)return;
  if(a.id===b.id){$('pairResult').textContent='This is the same task.';return;}
  if(dependsOn(a,b.id)||dependsOn(b,a.id)){$('pairResult').textContent='Cannot overlap: one task depends on the other, directly or through intermediate stages.';return;}
  const conflicts=Object.keys(a.resources).filter(p=>a.resources[p]+(b.resources[p]||0)>plan.capacities[p]+1e-7);
  $('pairResult').textContent=conflicts.length?'Cannot overlap with these limits: '+conflicts.join(', ')+'. Change a capacity only after measuring throughput and memory.':'The dependency/resource model permits overlap. This is a scheduling result, not proof that contention leaves real throughput unchanged.';
}
async function renderGPUs(){
  const key=JSON.stringify(config);
  if(comparisonKey!==key){
    if(comparisonPendingKey===key)return;
    comparisonPendingKey=key;
    $('gpuCards').innerHTML='';
    $('gpuComparison').innerHTML='<p class="caption" role="status">Comparing complete GPU schedules in the background… Controls remain available.</p>';
    try{
      const summary=await comparisonRequest.run({type:'gpu-comparison',config,evidence});
      if(!summary||JSON.stringify(config)!==key)return;
      comparisonSummary=summary;comparisonKey=key;
    }catch(error){if(JSON.stringify(config)===key)$('gpuComparison').textContent=error.message;return;}
    finally{if(comparisonPendingKey===key)comparisonPendingKey='';}
  }
  const {comparisons,unavailable}=comparisonSummary,max=Math.max(1,...comparisons.map(x=>x.r.end));
  $('gpuCards').innerHTML=comparisons.map(({g,r})=>`<article class="gpu-card ${config.gpu===g.id?'active':''}"><span class="badge">${g.basis==='concurrency'?'MATCHED WORKER GROUPS':g.basis==='measured'?'MATCHED · 5 WARM SAMPLES':'HISTORICAL · DIFFERENT CONDITIONS'}</span><h3>${esc(g.name)}</h3><span class="caption">${g.vram} GB VRAM · ${esc(g.region)} · ${g.date}</span><div class="specs"><div><strong>${g.meanClient.toFixed(2)}s</strong><small>mean client / job</small></div><div><strong>${money(g.hourly)}</strong><small>rental / hour</small></div><div><strong>${g.server.toFixed(2)}s</strong><small>backend</small></div></div><p>${esc(g.scope)}</p><p class="caption">${esc(g.pricing?.note || 'Historical rental receipt')}</p><button class="button ${config.gpu===g.id?'dark':''}" data-gpu="${g.id}">${config.gpu===g.id?'Selected profile':'Use this GPU'}</button></article>`).join('');
  $('gpuComparison').innerHTML=comparisons.map(({g,p,r})=>`<div class="compare-row"><div class="label">${esc(g.name)}<small>${esc(executionLabel(p))}</small></div><div class="track"><i style="width:${r.end/max*100}%;background:${g.id===config.gpu?'#89aa8f':'#bdccba'}"><span>${formatTime(r.end)}</span></i></div><div class="cost">${money(r.totalUSD)}</div></div>`).join('')+'<p class="caption">Each GPU uses its fastest completed compatible measurement, including its tested execution method. Same resolution, conditioning, chapter count, checks and cost assumptions; manual timeline moves are excluded from this comparison. Complete simulated time includes setup and rental waiting, director, local voice, rendering and daily storage. Timings and stock are historical. Rental uses the selected price basis; public listings and entered quotes are not new speed measurements. Unlisted variants fall back to labeled receipts.</p>'+(unavailable.length?`<p class="caption">No compatible completed measurement: ${unavailable.map(g=>esc(g.name)).join(', ')}. These GPUs have no substituted speed estimate.</p>`:'');
  $('gpuCards').querySelectorAll('[data-gpu]').forEach(b=>b.onclick=()=>{const chosen=comparisons.find(x=>x.g.id===b.dataset.gpu);checkpoint();config=chosen.c;preferences={};selected=null;setControls();rebuild();toast('Schedule updated: '+executionLabel(plan));});
}
function renderEvidence(){
  $('evidence').innerHTML=`<div class="evidence-block"><h3>What the matched test controlled</h3><p>${esc(evidence.imageSettings)}. Same prompts, character references and seeds. Each GPU made nine images; five warm landscape reference images calibrate this schedule. One host per GPU, different regions and network conditions.</p><p>Original 96 GB and MIG 48 GB profiles are separate historical runs. They are not normalized into a matched benchmark. Full 6000 detail splits and startup are assumptions.</p></div><div class="evidence-block"><h3>Startup and client stages</h3><div class="evidence-table"><table><thead><tr><th>GPU</th><th>Boot</th><th>Download / hash</th><th>Cold overhead</th><th>Client mean</th><th>Scope</th></tr></thead><tbody>${evidence.gpus.map(g=>`<tr><td>${esc(g.name)}</td><td>${sec(g.boot)}</td><td>${sec(g.download)}</td><td>${sec(g.cold)}</td><td>${sec(g.meanClient)}</td><td>${g.basis==='measured'?'Matched · cold overhead derived':'Historical + allowances'}</td></tr>`).join('')}</tbody></table></div><p>Cold overhead is the cold-server/warm-server difference, not isolated model-loading instrumentation. Download includes hash checking. Warm cache skips download, but first load still remains.</p></div><div class="evidence-block"><h3>No invented correction factor</h3><p>The ±${uncertainty}% range is a sensitivity assumption you can edit. It is not a statistical error bar or confidence interval. A shared matched benchmark would be needed to reliably adjust different old test conditions. Nine images per GPU cannot establish a population-wide error rate.</p></div><div class="evidence-block"><h3>Director, audio and rendering</h3><ul><li>Luna: ${esc(plan.director.label)}. ${esc(plan.director.scope)} The selected profile is applied to this schedule, startup comparisons and GPU rankings. Measured workflows count all director passes once; historical mode retains assumed pass weights.</li><li>Local narration: 13.47s to generate a 135.515s excerpt; scaled conservatively. Short tests cannot guarantee a two-hour voice result.</li><li>Renderer: selected ${config.videoResolution}/${config.videoFps}fps uses ${plan.renderProfile.clips} fresh matched clips in three rounds, one clip worker. Reference ${plan.renderProfile.wallSeconds.toFixed(2)}s per ${plan.renderProfile.videoSeconds}s of ${plan.renderProfile.mode==='chapter-export'?'motion and chapter assembly':'motion'}; observed round totals ${plan.renderProfile.minWallSeconds.toFixed(2)}–${plan.renderProfile.maxWallSeconds.toFixed(2)}s. Old repeated-asset 720p24 evidence is retained for history, not substituted into this forecast. ${plan.renderProfile.scope} Long production is not a measured guarantee.</li><li>Vision QC: ${(config.qcSeconds||evidence.calibration.qcSeconds).toFixed(2)}s per image; ${config.qcSeconds?"selected review timing with source details below":"historical mean across 12 calls"}. ${config.qcBenchmarkId?'Policy- and slot-specific Oct 28 QC measurements update this schedule; small-sample projections exclude repairs and manual waiting.':'No newer compatible policy/slot cohort is selected; review decisions and repair frequency can differ.'}</li><li>Routine preflight, intro planning, cleaning, alignment, timeline and final probe are explicit allowances. Manual review, chapter acquisition, outages, new character sheets and unbounded retries are excluded.</li></ul></div><div class="evidence-block"><h3>Installed constraints versus proposed improvements</h3><ul><li>${esc(productionModeNote(config))} Classic uses up to three shared API slots; staged workflows permit up to eight. The selected measured profile uses its tested slot count, already included in elapsed time. Factual chapter handoffs remain ordered; image throughput is not multiplied again by request-slot count.</li><li>Proposed mode separates preparation, upload, inference, polling, download and commits, with at most three in-flight scheduling groups. It overlaps chapter rendering and next-chapter planning. These queue changes are not deployed by this planner.</li><li>Next chapter’s story analysis waits for the preceding planned handoff. Images may arrive later; intended story facts remain authoritative.</li><li>This scenario uses measured local Kokoro narration; it does not estimate Kaggle voice latency, setup, quota or external queue waits. Native motion rendering shares the laptop GPU with local narration; the installed schedule serializes that resource. Images use the separate cloud GPU.</li><li>The legacy profile keeps one worker. Measured profiles use the tested worker count inside one delivered-image group. New worker profiles are enabled only from completed matched cohorts. More VRAM alone cannot predict their combined throughput.</li></ul></div><div class="evidence-block"><h3>Costs and retries</h3><p>GPU cost covers Boot → Stop, including downloads and idle gaps. API cost uses the selected receipt-derived profile or explicit manual estimate; Flex discounts eligible Luna tokens only; compatible measured timing is used where available, otherwise its latency remains an editable assumption. Daily storage is separate and editable. No free tokens are assumed. Extra image attempts are a configured count allowance, not a measured failure probability. No auto-repair is claimed with checks off. An API repair check or manual review could add more time/cost than this simple allowance.</p></div><div class="evidence-block"><h3>Source records and code</h3><ul><li>2026-10-05-four-gpu: summary, GPU receipts, model hashes and client component timings.</li><li>2026-10-05-three-model-comparison: MIG warm 4B cases.</li><li>cloud-setup/PERFORMANCE-AUDIT.md: original 96 GB completed job timings and price.</li><li>2026-10-03: fresh-director-results and local-voice-overlap-results.</li><li>2026-10-04-two-hour: render-transition-recovery-results.</li><li>2026-10-04-live-comparison: serial QC receipts.</li><li>Backend: studio_overlap.py, studio_execution.py, image_provider.py, studio_service.py and studio_render.py.</li></ul><p>Sanitized calibration is served from pipeline-evidence.json. No private story, portrait, project identifier, credentials or API key is included.</p></div>`;
}
function stopPlay(){playing=false;cancelAnimationFrame(playFrame);$('play').textContent='Play simulation';if($('playhead'))$('playhead').hidden=true;$('timeline').querySelectorAll('.active').forEach(b=>b.classList.remove('active'));}
function tick(now){
  if(!playing)return;playAt=(now-playStarted)/35000*result.end;
  if(playAt>result.end){stopPlay();$('playTime').textContent='Simulation complete';return;}
  $('playTime').textContent=formatTime(playAt)+' simulated';const active=result.tasks.filter(t=>t.start<=playAt&&t.end>playAt);
  $('activeWork').innerHTML=active.map(t=>`<div class="active-item"><b>${esc(t.id)}</b>${esc(t.name)}</div>`).join('')||'<p class="caption">Waiting for dependencies.</p>';
  const ids=new Set(active.map(t=>t.id));$('timeline').querySelectorAll('.task').forEach(b=>b.classList.toggle('active',ids.has(b.dataset.id)||b.dataset.id===PREPARATION_GROUP&&preparation?.members.some(t=>ids.has(t.id))));
  if($('playhead')){$('playhead').hidden=false;$('playhead').style.left=(155+playAt*scale)+'px';}
  playFrame=requestAnimationFrame(tick);
}
function download(name,value,type){const blob=new Blob([value],{type}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
async function start(){
  try{
    const response=await fetch('./pipeline-evidence.json?v=one-hour-speed-20261028');if(!response.ok)throw Error('Calibration could not load. Open through the local preview or website server.');evidence=await response.json();
    try{const productionReply=await fetch('./pipeline-production-calibration.json?v=production-components-20261031');if(productionReply.ok)evidence.productionCalibration=await productionReply.json();}catch{ /* Missing current production proof never replaces historical timing. */ }
    try{const qcReply=await fetch('./pipeline-qc-calibration.json?v=production-components-20261031');if(qcReply.ok)evidence.qcCalibration=await qcReply.json();}catch{ /* Retain prior history/assumptions if the optional study is unavailable. */ }
    const directorReply=await fetch('./pipeline-director-calibration.json?v=production-components-20261031');
    if(directorReply.ok)evidence.directorCalibration=await directorReply.json();
    $('directorProfile').innerHTML=directorProfileOptions(evidence);
    const concurrencyResponse=await fetch('./pipeline-concurrency.json');
    if(concurrencyResponse.ok){
      evidence.concurrency=await concurrencyResponse.json();
      mountGPUPanels=()=>{
      if(gpuExplorer)return;
      gpuExplorer=mountGPUExplorer($('gpuExplorer'),evidence.concurrency,settings=>{
        const next={...config,...settings,policy:config.policy==='serial'?'serial':'proposed'};
        try{buildPlan(next,evidence);checkpoint();config=next;preferences={};selected=null;setControls();rebuild();switchView('schedule');toast('Exact measured GPU configuration applied. Production settings remain unchanged.');}catch(error){toast(error.message);}
      });
      mountConcurrencyLab($('concurrencyLab'),evidence.concurrency,settings=>{
        const next={...config,...settings,policy:config.policy==='serial'?'serial':'proposed'};
        try{buildPlan(next,evidence);checkpoint();config=next;preferences={};selected=null;setControls();rebuild();switchView('schedule');toast('Measured throughput applied to the planning schedule. Production settings remain unchanged.');}catch(error){toast(error.message);}
      });
      gpuExplorer.updateProject(config,evidence);
      };
    }
    const choices=gpuChoices(evidence);
    $('gpu').innerHTML=choices.map(g=>`<option value="${g.id}">${esc(g.name)}</option>`).join('');
    const measuredDefault={...DEFAULTS,directorProfile:evidence.directorCalibration?'lean-current-standard':'historical',directorCostMode:evidence.directorCalibration?'measured':'manual',gpu:'5090',resolution:'720p',encodingProfile:'fresh'};
    try{config=realisticPlanningConfig(measuredDefault,evidence);}catch{config=realisticPlanningConfig({...measuredDefault,resolution:'legacy'},evidence);}
    const resetDefault={...config};
    try{const saved=JSON.parse(localStorage.getItem(STORE)||'null');if(saved){saved.config=migrateDirectorForecast(saved.config,true,Boolean(Object.keys(saved.preferences||{}).length));if(!evidence.directorCalibration&&saved.config.directorProfile!=='historical')throw Error('Director calibration unavailable');const state=importSnapshot(saved,evidence);config=state.config;preferences=state.preferences;studioFollowing=saved.studioSource?.requestedFollowing??(saved.studioSource?.following!==false);studioProject=saved.studioSource?.project||'';uncertainty=Number.isFinite(saved.uncertainty)?Math.max(0,Math.min(100,saved.uncertainty)):20;}}catch{toast('Saved planner settings were invalid; using the default plan. Studio projects are unaffected.');}
    if(Object.keys(preferences).length)studioFollowing=false;
    $('followStudio').checked=studioFollowing;
    $('loadStudioSettings').onclick=()=>loadStudioSettings({refresh:true});
    $('studioProject').onchange=()=>{studioProject=$('studioProject').value;studioRevision=null;void loadStudioSettings({refresh:true});};
    $('followStudio').onchange=()=>{studioFollowing=$('followStudio').checked;if(studioFollowing)void loadStudioSettings({refresh:true});else studioManual();};
    setControls();await rebuild();await loadStudioSettings({initial:true});
    setInterval(()=>{if(studioFollowing&&!document.hidden)void loadStudioSettings();},30000);
    addEventListener('focus',()=>{if(studioFollowing)void loadStudioSettings();});
    for(const k of [...keys,'uncertainty'])if($(k)){
      const apply=()=>{
      let next=readControls();if(JSON.stringify(next)===JSON.stringify(config)&&Number($('uncertainty').value)===uncertainty)return;
      if(k==='quotedGPUHourly')next.quotedGPU=next.gpu;
      if(k==='directorCost')next.directorCostMode='manual';
      if(k==='qcCost')next.qcCostManual=true;
      if(k==='directorProfile'||k==='apiSlots')next.directorActualSlots=0;
      if(k==='directorProfile'&&next.directorProfile==='historical')next.apiSlots=Math.min(next.apiSlots,3);
      if(['gpu','resolution','encodingProfile','executionMode'].includes(k))next.measurementAttempt='latest';
      if(k==='chapters'){next.readyChapters=Math.min(next.readyChapters,next.chapters);}
      if(k!=='gpuStartSeconds'&&k!=='uncertainty'&&next.gpuStartSeconds>0){next.gpuStartSeconds=0;toast('Timed GPU startup cleared after settings changed. Recalculate using Spend less on rented waiting.');}
      // Never silently change the user's check level to satisfy installed overlap.
      try{if(['gpu','resolution','encodingProfile'].includes(k))next=selectScenarioGPUConfig(next,evidence,next.gpu);const nextPlan=buildPlan(next,evidence);const u=Number($('uncertainty').value);if(!Number.isFinite(u)||u<0||u>100)throw Error('Sensitivity must be 0–100%.');checkpoint();config=next;uncertainty=u;preferences={};selected=null;setControls();rebuild();if(['gpu','resolution','encodingProfile'].includes(k))toast('Measured setup applied: '+executionLabel(nextPlan));}catch(e){toast(e.message);setControls();}
      };
      $(k).addEventListener('change',()=>{clearTimeout(controlTimer);apply();});
      $(k).addEventListener('input',()=>{clearTimeout(controlTimer);controlTimer=setTimeout(apply,350);});
    }
    $('fastestGPU').onclick=()=>{try{const next=selectGPUConfig(config,evidence,config.gpu),nextPlan=buildPlan(next,evidence);checkpoint();config=next;preferences={};selected=null;setControls();rebuild();toast('Fastest tested settings applied: '+executionLabel(nextPlan));}catch(e){toast(e.message);}};
    document.querySelectorAll('[data-view]').forEach((b,i)=>{b.onclick=()=>switchView(b.dataset.view);b.onkeydown=e=>{const tabs=[...document.querySelectorAll('[data-view]')];const next=e.key==='ArrowRight'?tabs[(i+1)%tabs.length]:e.key==='ArrowLeft'?tabs[(i+tabs.length-1)%tabs.length]:null;if(next){e.preventDefault();next.focus();switchView(next.dataset.view);}};});
    $('chapterFocus').onchange=()=>{focus=$('chapterFocus').value;renderTimeline();renderInspector();};$('zoom').onchange=renderTimeline;
    $('compactPreparation').onchange=()=>{preparationCompact=$('compactPreparation').checked;renderTimeline();};
    $('modelStorage20').onclick=()=>{checkpoint();config={...config,storageDaily:20*.07/30};setControls();rebuild();toast('20 GB model-volume forecast applied. Account storage and archive allowance were not changed.');};
    $('processSearch').oninput=renderProcesses;$('pairA').onchange=pairResult;$('pairB').onchange=pairResult;
    $('undo').onclick=()=>{const last=history.pop();if(!last)return;config=last.config;preferences=last.preferences;uncertainty=last.uncertainty;setControls();rebuild();$('undo').disabled=!history.length;toast('Previous plan restored.');};
    $('optimize').onclick=()=>{checkpoint();preferences={};rebuild();$('moveFeedback').textContent='Tasks repacked at their earliest available dependency/resource slot. This is a feasible heuristic, not a proof of the global optimum.';};
    $('reset').onclick=()=>{checkpoint();config={...resetDefault};preferences={};uncertainty=20;selected=null;setControls();rebuild();toast('Conservative installed planning scenario restored. Follow saved setup to apply its actual topology.');};
    $('play').onclick=()=>{if(playing){stopPlay();return;}if(matchMedia('(prefers-reduced-motion: reduce)').matches){toast('Animation disabled by your reduced-motion setting. Task details remain available.');return;}playing=true;playStarted=performance.now();$('play').textContent='Stop simulation';playFrame=requestAnimationFrame(tick);};
    $('export').onclick=()=>{
      const controls=readControls();
      if(config.directorCostMode==='measured')controls.directorCost=config.directorCost;
      if(renderedGeneration!==computeGeneration||JSON.stringify(controls)!==JSON.stringify(config)||Number($('uncertainty').value)!==uncertainty){toast('Wait for the current settings to finish calculating before exporting.');return;}
      const value={...snapshot(),exportedAt:new Date().toISOString(),evidenceVersion:evidence.version,execution:'planning-only',summary:{elapsedSeconds:result.end,rentalSeconds:result.rentalSeconds,rentalWindows:result.rentalWindows,imageCount:plan.imageCount,attemptCount:plan.attemptCount,gpuUSD:result.gpuUSD,apiUSD:result.apiUSD,archiveUSD:result.archiveUSD||0,productionUSD:result.productionUSD,storageUSD:result.storageUSD,totalUSD:result.totalUSD,pricing:plan.gpu.pricing},capacities:plan.capacities,tasks:result.tasks,calibration:evidence,notes:evidence.notes};
      download(`studio-plan-${config.gpu}-${config.minutes}min.json`,JSON.stringify(value,null,2),'application/json');toast('Exported schedule, task IDs, dependencies, resource limits and evidence.');
    };
    $('import').onclick=()=>$('importFile').click();$('importFile').onchange=async()=>{const file=$('importFile').files[0];if(!file)return;try{if(file.size>16_000_000)throw Error('Plan export must be smaller than 16 MB.');const input=JSON.parse(await file.text()),state=importSnapshot(input,evidence);checkpoint();config=state.config;preferences=state.preferences;uncertainty=Number.isFinite(input.uncertainty)?Math.max(0,Math.min(100,input.uncertainty)):20;selected=null;setControls();rebuild();toast('Plan imported. Paid execution and Studio projects remain unchanged.');}catch(e){toast('Could not import: '+e.message);}finally{$('importFile').value='';}};
    let resizeTimer;new ResizeObserver(()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(renderTimeline,120);}).observe($('timeline'));
    loadOptionalPanels=async()=>{
    if(optionalPanelsStarted)return;optionalPanelsStarted=true;
    try {
      const response=await fetch('./pipeline-serverless.json');
      if(response.ok){const data=await response.json();const panel=document.createElement('section');panel.id='serverlessLab';panel.innerHTML=serverlessHTML(data);$('concurrencyLab').insertAdjacentElement('afterend',panel);}
    } catch { /* Optional pilot evidence never blocks the existing planner. */ }
    try {
      const response=await fetch('./pipeline-matched.json');
      if(response.ok){const data=await response.json();const panel=document.createElement('section');panel.id='matchedLab';panel.innerHTML=matchedHTML(data,evidence);($('serverlessLab')||$('concurrencyLab')).insertAdjacentElement('afterend',panel);}
    } catch { /* Incomplete matched measurements never substitute a speed estimate. */ }
    try {
      const detailResponse=await fetch('./pipeline-details.json');
      if(!detailResponse.ok)throw Error('Optional source inventory unavailable');
      const details=await detailResponse.json();mountObservedRuns($('observedRuns'),details);mountFunctionIndex($('functionIndex'),details,kind=>{const task=result.tasks.find(t=>t.kind===kind);if(task){selected=task.id;renderInspector();}else{const meta=CATALOG.find(t=>t.id===kind);if(meta){$('inspectorLabel').textContent='NESTED / CONDITIONAL';$('taskInspector').innerHTML=`<h3>${esc(meta.name)}</h3><p class="task-desc">${esc(meta.description)}</p><p>${esc(meta.basis)}</p><p>${esc(meta.parallel)}</p>`;}}});
    } catch {
      $('functionIndex').textContent='Source inventory unavailable. Process-level explanations remain available.';
      $('observedRuns').textContent='Recorded timing file unavailable; no trace is substituted.';
    }
    };
  }catch(e){$('error').textContent=e.message;$('error').hidden=false;$('saved').textContent='Planner could not initialize';}
}
start();
