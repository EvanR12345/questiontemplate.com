"""Image backends are replaceable; no story facts or timeline logic lives here."""
from prompt_quality import execution_evidence

import base64, copy, hashlib, io, json, math, re, secrets, subprocess, time, urllib.error, urllib.request
from pathlib import Path
from PIL import Image, ImageStat
from director_provider import local_url, request_json

BASE_CAPS = {
    k: False
    for k in (
        "supportsMultipleReferences",
        "supportsImageEditing",
        "supportsNegativePrompt",
        "supportsSeed",
        "supportsPoseReference",
        "supportsControlNet",
        "supportsIPAdapter",
        "supportsStyleReference",
        "supportsLoRA",
        "supportsInpainting",
        "supportsOutpainting",
        "supportsUpscaling",
        "supportsVisionInput",
        "supportsBatchGeneration",
    )
}


class RemoteGenerationUncertain(RuntimeError):
    """A request may already have generated an image; never retry automatically."""
    def __init__(self, prompt_id=None, timed_out=False):
        self.prompt_id = prompt_id
        self.timed_out = timed_out
        detail = (' ComfyUI prompt ID: ' + str(prompt_id) + '.') if prompt_id else ''
        super().__init__('Image request outcome is uncertain.' + detail +
            ' Check the existing ComfyUI queue/history before retrying; no automatic new generation was submitted.'
            ' Stop the rented GPU if you are finished: stopping this queue does not stop rental billing.')
BASE_CAPS.update(
    maxReferenceImages=0,
    maxResolution=512,
    recommendedResolution=[512, 512],
    recommendedSteps=20,
    recommendedSampler="DPM++ 2M",
    recommendedGuidance=7,
    recommendedDenoisingStrength=0.65,
    promptFormat="sd-tags",
    negativePromptFormat="comma-tags",
    hardwareRequirements={"vramGB": 4, "ramGB": 8},
)
_GPU_MEMORY = (0, None)


def gpu_memory_gb():
    global _GPU_MEMORY
    if time.time() - _GPU_MEMORY[0] > 60:
        try:
            memory = (
                float(
                    subprocess.check_output(
                        [
                            "nvidia-smi",
                            "--query-gpu=memory.total",
                            "--format=csv,noheader,nounits",
                        ],
                        text=True,
                    ).splitlines()[0]
                )
                / 1024
            )
        except Exception:
            memory = None
        _GPU_MEMORY = (time.time(), memory)
    return _GPU_MEMORY[1]


def data_url(path):
    return "data:image/png;base64," + base64.b64encode(Path(path).read_bytes()).decode()


def visible_image(raw):
    img = Image.open(io.BytesIO(raw)).convert("RGB")
    img.load()
    if max(max(v) for v in img.getextrema()) <= 2:
        raise RuntimeError(
            "Generator returned a black image. The output was rejected; inspect model precision, VAE and workflow."
        )
    return img


class ImageProvider:
    id = "abstract"

    def available_vram_gb(self):
        return gpu_memory_gb()

    def getCapabilities(self):
        return dict(BASE_CAPS)

    def getRecommendedSettings(self):
        return {
            "width": 512,
            "height": 512,
            "steps": 20,
            "sampler": "dpm++2m",
            "scheduler": "karras",
            "guidance": 7,
            "denoisingStrength": 0.65,
        }

    def validateSettings(self, s, check_hardware=True):
        caps = self.getModelCapabilities(s.get('model', '')) if hasattr(self, 'getModelCapabilities') else self.getCapabilities()
        result = copy.deepcopy(s)
        memory = self.available_vram_gb() if check_hardware else None
        requirements = caps.get("hardwareRequirements", {})
        minimum = requirements.get("vramGB", 0)
        unit = requirements.get('vramUnit', 'GiB')
        if unit not in ('GiB', 'nominalGB'):
            raise ValueError('Unknown workflow VRAM unit.')
        if isinstance(minimum,bool) or not isinstance(minimum,(int,float)) or not math.isfinite(minimum) or minimum<0:
            raise ValueError('Workflow VRAM requirement must be a non-negative number.')
        # Existing declarations retain their GiB semantics. A workflow may
        # explicitly describe a marketed card class in nominal GB instead.
        # Driver/ECC reservations are then handled in the same byte units as
        # the remote hardware admission; this does not promise inference fit.
        minimum_gib = minimum*1_000_000_000*.94/2**30 if unit=='nominalGB' else minimum
        if (
            memory is not None
            and minimum_gib > memory + 0.05
            and requirements.get("mode") not in ("cpu", "cpu-offload")
        ):
            raise ValueError(
                f"This workflow requires approximately {minimum} {unit} VRAM; this GPU has {memory:.1f} GiB usable. Select a smaller model or explicitly configure a tested CPU/offload workflow."
            )
        for field in ("width", "height", "steps"):
            n = result.get(field, self.getRecommendedSettings()[field])
            if (
                isinstance(n, bool)
                or not isinstance(n, (int, float))
                or not math.isfinite(n)
            ):
                raise ValueError("Invalid " + field)
            result[field] = int(n)
        if (
            not 256 <= result["width"] <= caps["maxResolution"]
            or not 256 <= result["height"] <= caps["maxResolution"]
        ):
            raise ValueError("Resolution exceeds this provider’s tested memory limits.")
        if (
            result["width"] % 8
            or result["height"] % 8
            or not 1 <= result["steps"] <= 60
        ):
            raise ValueError("Use dimensions divisible by eight and 1–60 steps.")
        if result.get("loras") and not caps["supportsLoRA"]:
            raise ValueError("This workflow does not support LoRA.")
        if result.get("controlnets") and not caps["supportsControlNet"]:
            raise ValueError("This workflow does not support ControlNet.")
        if result.get("ipAdapter") and not caps["supportsIPAdapter"]:
            raise ValueError("This workflow does not support IP-Adapter.")
        if result.get("seed") is None:
            result["seed"] = secrets.randbelow(2**31)
        if (
            isinstance(result["seed"], bool)
            or not isinstance(result["seed"], int)
            or not 0 <= result["seed"] < 2**32
        ):
            raise ValueError("Invalid seed.")
        return result

    def generateImage(self, request, checkpoint):
        raise NotImplementedError

    def editImage(self, request, checkpoint):
        if not self.getCapabilities()["supportsImageEditing"]:
            raise ValueError("Image editing unavailable for this workflow.")
        return self.generateImage(request | {"operation": "edit"}, checkpoint)

    def inpaintImage(self, request, checkpoint):
        if not self.getCapabilities()["supportsInpainting"]:
            raise ValueError("Inpainting unavailable for this workflow.")
        return self.generateImage(request | {"operation": "inpaint"}, checkpoint)

    def upscaleImage(self, request, checkpoint):
        raise ValueError(
            "No neural upscaler is installed. Rendering can resize images."
        )

    def unload(self):
        pass

    def healthCheck(self):
        return {"installed": False}


class ExistingImageProvider(ImageProvider):
    id = "existing"

    def __init__(self, engine):
        self.engine = engine

    def getCapabilities(self):
        return BASE_CAPS | {
            "supportsMultipleReferences": True,
            "supportsNegativePrompt": True,
            "supportsSeed": True,
            "supportsIPAdapter": True,
            "supportsStyleReference": True,
            "supportsInpainting": True,
            "supportsImageEditing": True,
            "supportsVisionInput": False,
            "maxReferenceImages": 3,
            "maxResolution": 768,
            "recommendedResolution": [512, 512],
            "promptFormat": "sd-tags",
            "negativePromptFormat": "comma-tags",
            "hardwareRequirements": {"vramGB": 4, "ramGB": 8},
            "referenceLimitations": "IP-Adapter combines references; separate multiple-character identity is approximate.",
        }

    def healthCheck(self):
        if time.time() - getattr(self, "checked", 0) > 15:
            self.checked = time.time()
            self.cached = []
            try:
                from huggingface_hub import snapshot_download

                for model, repo in (
                    ("sd15", "stable-diffusion-v1-5/stable-diffusion-v1-5"),
                    ("dreamshaper8", "Lykon/dreamshaper-8"),
                ):
                    try:
                        folder = Path(snapshot_download(repo, local_files_only=True))
                        if all(
                            (folder / name).is_file()
                            for name in (
                                "model_index.json",
                                "text_encoder/model.fp16.safetensors",
                                "unet/diffusion_pytorch_model.fp16.safetensors",
                                "vae/diffusion_pytorch_model.fp16.safetensors",
                            )
                        ):
                            self.cached.append(model)
                    except Exception:
                        pass
            except ImportError:
                pass
        return {
            "installed": bool(self.cached),
            "models": self.cached,
            "workflow": ["text-to-image", "ip-adapter", "inpaint"],
            "error": (
                ""
                if self.cached
                else "SD weights are not cached. Use an installed provider or explicitly install the checkpoint; no download was started."
            ),
        }

    def validateSettings(self, s):
        s = super().validateSettings(s)
        if s.get("model") not in ("sd15", "dreamshaper8"):
            raise ValueError("Unknown existing model.")
        if s["model"] not in self.healthCheck()["models"]:
            raise ValueError(
                "Selected SD checkpoint is not installed. Choose a cached model; no automatic multi-GB download was started."
            )
        if (
            not 384 <= s["width"] <= 768
            or not 384 <= s["height"] <= 768
            or not 8 <= s["steps"] <= 50
        ):
            raise ValueError("SD fallback needs dimensions 384–768 and 8–50 steps.")
        if (
            s.get("sampler", "DPM++ 2M") not in ("DPM++ 2M", "dpm++2m")
            or s.get("scheduler", "karras") != "karras"
        ):
            raise ValueError("Existing backend supports DPM++ 2M / karras only.")
        return s

    def generateImage(self, r, checkpoint):
        s = self.validateSettings(r["settings"])
        operation = r.get("operation", "generate")
        if operation == "edit" and not r.get("mask"):
            raise ValueError(
                "SD fallback repairs need an inpaint mask. Use native FLUX editing or provide a mask."
            )
        data = s | {
            "prompt": r["prompt"],
            "negative": r.get("negativePrompt", ""),
            "reference_images": r.get("referenceImages", [])[:3],
            "reference_strength": s.get("referenceStrength", 0.65),
            "preset": "balanced",
            "operation": "inpaint" if operation in ("edit", "inpaint") else "generate",
        }
        if data["operation"] == "inpaint":
            data.update(
                image=r["sourceImage"],
                mask=r["mask"],
                denoising_strength=s.get("denoisingStrength", 0.65),
            )
        result = self.engine().generate(data, checkpoint)
        result["provider"] = self.id
        return result

    def unload(self):
        self.engine().unload()


class NativeFluxProvider(ImageProvider):
    id = "native-flux"

    def __init__(self, config, log_root):
        self.config = config
        self.root = Path(log_root)
        self.process = None
        self.log = None
        self.url = "http://127.0.0.1:8767"

    def getCapabilities(self):
        return BASE_CAPS | {
            "supportsMultipleReferences": True,
            "supportsImageEditing": True,
            "supportsSeed": True,
            "supportsStyleReference": True,
            "supportsVisionInput": True,
            "maxReferenceImages": 2,
            "maxResolution": 448,
            "recommendedResolution": [448, 448],
            "recommendedSteps": 4,
            "recommendedSampler": "euler",
            "recommendedGuidance": 1,
            "promptFormat": "natural-language",
            "negativePromptFormat": "unsupported",
            "hardwareRequirements": {
                "vramGB": 4,
                "ramGB": 8,
                "mode": "quantized Q4, mmap disk weights, sequential GPU use; references/editing at 384px",
            },
        }

    def getRecommendedSettings(self):
        return {
            "width": 448,
            "height": 448,
            "steps": 4,
            "sampler": "euler",
            "scheduler": "flux2",
            "guidance": 1,
            "denoisingStrength": 1,
        }

    def healthCheck(self):
        installed = all(
            Path(self.config.get(k, "")).is_file()
            for k in ("imageExecutable", "fluxModel", "fluxEncoder", "fluxVae")
        )
        return {
            "installed": installed,
            "validated": bool(self.config.get("fluxValidated", False)),
            "models": ["flux2-klein-4b-q4"],
            "workflow": ["text-to-image", "reference-edit"],
            "running": bool(self.process and self.process.poll() is None),
        }

    def validateSettings(self, s):
        s = super().validateSettings(s)
        if s.get("model") != "flux2-klein-4b-q4":
            raise ValueError(
                "Only installed FLUX.2 Klein 4B Q4 is supported by this adapter."
            )
        if s.get("denoisingStrength", 1) != 1:
            raise ValueError(
                "Native Klein uses instruction-based editing. Its workflow has no SD denoising-strength control; use 1 or choose a masked SD/Comfy workflow."
            )
        if s.get("guidance", 1) != 1:
            raise ValueError(
                "Distilled Klein uses guidance 1. Choose its preset to reset SD settings."
            )
        if (
            s.get("sampler", "euler") != "euler"
            or s.get("scheduler", "flux2") != "flux2"
        ):
            raise ValueError("Use Euler / flux2 for this tested Klein workflow.")
        if not self.healthCheck()["installed"]:
            raise RuntimeError(
                "FLUX native files are unavailable. Choose an installed provider or configure the native model paths."
            )
        return s

    def start(self, checkpoint):
        if self.process and self.process.poll() is None:
            return
        if not self.healthCheck()["installed"]:
            raise RuntimeError("Native FLUX runtime/model files missing.")
        self.root.mkdir(parents=True, exist_ok=True)
        self.log = (self.root / "native-images.log").open("w", encoding="utf-8")
        backend = self.config.get("imageBackend")
        if not backend:
            raise ValueError(
                "Configure imageBackend using the detected NVIDIA Vulkan device. Integrated GPU selection is not allowed implicitly."
            )
        args = [
            self.config["imageExecutable"],
            "--listen-ip",
            "127.0.0.1",
            "--listen-port",
            "8767",
            "--diffusion-model",
            self.config["fluxModel"],
            "--llm",
            self.config["fluxEncoder"],
            "--vae",
            self.config["fluxVae"],
            "--mmap",
            "--params-backend",
            "disk",
            "--backend",
            backend,
            "--max-vram",
            "3.7",
            "--conditioning-cache-size",
            "8",
            "-t",
            "4",
        ]
        self.process = subprocess.Popen(
            args,
            stdout=self.log,
            stderr=self.log,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        for _ in range(180):
            checkpoint(0, 4, "Loading quantized FLUX")
            if self.process.poll() is not None:
                raise RuntimeError(
                    "Native FLUX failed to start. See outputs/studio/native-images.log."
                )
            try:
                request_json(self.url + "/sdcpp/v1/capabilities", timeout=1)
                return
            except Exception:
                time.sleep(0.5)
        self.unload()
        raise RuntimeError("Native FLUX startup timed out.")

    def generateImage(self, r, checkpoint):
        if r.get("operation") == "inpaint":
            raise ValueError(
                "Native Klein does not implement masked inpainting. Use its image-edit operation, or select a provider with masked inpaint support."
            )
        s = self.validateSettings(r["settings"])
        self.start(checkpoint)
        started = time.time()
        refs = r.get("referenceImages", [])[:2]

        def resize_reference(value, size):
            img = Image.open(
                io.BytesIO(base64.b64decode(value.split(",", 1)[-1]))
            ).convert("RGB")
            img.thumbnail((size, size))
            out = io.BytesIO()
            img.save(out, "PNG")
            return "data:image/png;base64," + base64.b64encode(out.getvalue()).decode()

        refs = [resize_reference(x, 224) for x in refs]
        if r.get("operation") == "edit":
            refs = [resize_reference(r["sourceImage"], 320)] + refs[:1]
        if refs and (s["width"] > 384 or s["height"] > 384):
            raise ValueError(
                "Reference/editing shots need at most 384×384 on this 4 GB GPU. Choose the Character Reference or Image Repair preset."
            )
        body = {
            "prompt": r["prompt"],
            "width": s["width"],
            "height": s["height"],
            "seed": s["seed"],
            "batch_count": 1,
            "ref_images": refs,
            "increase_ref_index": True,
            "sample_params": {
                "sample_steps": s["steps"],
                "sample_method": "euler",
                "scheduler": "flux2",
                "guidance": {"txt_cfg": 1, "img_cfg": 1, "distilled_guidance": 1},
            },
            "vae_tiling_params": {
                "enabled": True,
                "tile_size_w": 256,
                "tile_size_h": 256,
            },
        }
        job = request_json(self.url + "/sdcpp/v1/img_gen", body)
        jobid = job["id"]
        try:
            while True:
                info = request_json(self.url + "/sdcpp/v1/jobs/" + jobid)
                checkpoint(0, s["steps"], "FLUX " + info["status"])
                if info["status"] == "completed":
                    break
                if info["status"] in ("failed", "cancelled"):
                    tail = (self.root / "native-images.log").read_text(
                        errors="replace"
                    )[-1800:]
                    raise RuntimeError(
                        f'FLUX failed at {s["width"]}×{s["height"]} on this local backend: {info.get("error")}. Use 384×384 for references/repair and close other GPU apps. Runtime details: '
                        + tail
                    )
                time.sleep(0.3)
        except Exception:
            try:
                request_json(self.url + "/sdcpp/v1/jobs/" + jobid + "/cancel", {})
            except Exception:
                pass
            raise
        result = info["result"]
        img = visible_image(base64.b64decode(result["images"][0]["b64_json"]))
        return {
            "pil": img,
            "seed": s["seed"],
            "seconds": time.time() - started,
            "provider": self.id,
            "model": "FLUX.2-klein-4B Q4_0",
            "precision": "Q4_0 transformer/text encoder; native BF16 VAE weights with Vulkan decoding; black-frame validation",
            "backend": self.config["imageBackend"],
            "referenceCount": len(refs),
            "referencePreprocessing": {
                "identityMaxPixels": 224,
                "sourceEditMaxPixels": 320,
            },
            "settings": s,
            "runtime": "stable-diffusion.cpp 3f8527a",
        }

    def unload(self):
        if self.process and self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(10)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait()
        self.process = None
        if self.log:
            self.log.close()
            self.log = None


class ComfyImageProvider(ImageProvider):
    id = "comfyui"

    def __init__(self, config):
        self.config = config
        self.url = local_url(config.get("comfyEndpoint", "http://127.0.0.1:8188"))
        self._server_memory = (0, None)
        self._health = (0, None)
        self._node_catalog = (0, None)
        self._uploads = {}

    def available_vram_gb(self):
        # A localhost SSH tunnel can lead to a different computer's GPU.
        # Always inspect ComfyUI's device rather than the helper's laptop.
        if time.time() - self._server_memory[0] > 60:
            try:
                stats = request_json(self.url + "/system_stats", timeout=3)
                devices = stats.get("devices", [])
                memory = max(
                    (float(d.get("vram_total", 0)) / 2**30 for d in devices),
                    default=0,
                )
                if not math.isfinite(memory) or memory < 0:
                    raise ValueError("Invalid GPU memory reported by ComfyUI")
                self._server_memory = (time.time(), memory)
            except Exception as e:
                raise RuntimeError(
                    "Cannot verify the image server's GPU memory. Check ComfyUI and the SSH tunnel: "
                    + str(e)
                ) from e
        return self._server_memory[1]

    def template(self):
        path = self.config.get("comfyWorkflow")
        if not path or not Path(path).is_file():
            raise ValueError(
                "Configure an exported ComfyUI API workflow and bindings in studio-config.json."
            )
        return json.loads(Path(path).read_text(encoding="utf-8"))

    def getRecommendedSettings(self):
        try:
            template = self.template()
            caps = self.getCapabilities()
            size = caps["recommendedResolution"]
            return {
                "width": size[0],
                "height": size[1],
                "steps": caps["recommendedSteps"],
                "sampler": caps["recommendedSampler"],
                "scheduler": "normal",
                "guidance": caps["recommendedGuidance"],
                "denoisingStrength": caps["recommendedDenoisingStrength"],
            } | template.get("recommendedSettings", {})
        except Exception:
            return super().getRecommendedSettings()

    def getCapabilities(self):
        try:
            return BASE_CAPS | self.template()["capabilities"]
        except Exception:
            return BASE_CAPS | {
                "maxReferenceImages": 0,
                "maxResolution": 1024,
                "promptFormat": "natural-language",
                "hardwareRequirements": {"configuredWorkflowRequired": True},
            }

    def planningCatalog(self):
        """Declared workflows for planning while a paid worker is stopped.

        This is not a health check or proof that weights are installed. Every
        generation still performs the live backend/memory/model validation.
        """
        template = self.template()
        templates = template.get('variants', [template])
        return {'installed': False, 'configured': True, 'requiresLiveValidation': True,
                'models': list(dict.fromkeys([template['model']] + [t['model'] for t in templates])),
                'workflow': list(dict.fromkeys([template['name']] + [t['name'] for t in templates] + list(template.get('automaticWorkflows', {}))))}

    def getModelCapabilities(self, model):
        return self.getCapabilities() | self.template().get('modelCapabilities', {}).get(model, {})

    def resolve_template(self, request, settings):
        root = self.template()
        variants = root.get("variants")
        if not variants:
            return root, settings
        model = settings.get("model", root["model"])
        if model not in {root["model"], *(v["model"] for v in variants)}:
            raise ValueError("Selected Comfy model is not installed in this workflow bundle.")
        workflow = request.get("workflow") or settings.get("workflow") or root["name"]
        references = bool(request.get("referenceImages")) or request.get("operation") == "edit"
        automatic = root.get('automaticWorkflows', {}).get(workflow, {})
        defaults = automatic or root
        if automatic and model not in (root['model'], automatic['model']):
            raise ValueError('Selected automatic workflow belongs to another model.')
        if request.get("purpose") == "character-reference" and not references and defaults.get("referenceCreationWorkflow"):
            workflow = defaults["referenceCreationWorkflow"]
            settings = settings | dict(zip(("width", "height"), defaults.get("referenceResolution", (1024, 1024))))
        elif workflow == root["name"] and request.get("operation") == "edit" and root.get("repairWorkflow"):
            workflow = root["repairWorkflow"]
        if workflow == root["name"] or workflow in root.get('automaticWorkflows', {}):
            kind = "reference" if references else "text"
            candidates = [v for v in variants if v.get("kind") == kind and v.get("default")]
            if automatic:
                candidates = [v for v in candidates if v['model'] == automatic['model']]
            elif model != root["model"]:
                candidates = [v for v in candidates if v["model"] == model]
            else:
                candidates = [v for v in candidates if v['model'] not in root.get('modelCapabilities', {})]
            reference_count = len(request.get('referenceImages', [])) + int(request.get('operation') == 'edit')
            candidates = [v for v in candidates if v.get('referenceCount', reference_count) == reference_count]
        else:
            candidates = [v for v in variants if v["name"] == workflow and model in (root["model"], v["model"])]
        if len(candidates) != 1:
            raise ValueError("Selected model/workflow is incompatible with the supplied references. Select the configured automatic workflow or a compatible explicit workflow.")
        template = candidates[0]
        if settings.get("loras") and settings["loras"] != template.get("presetSettings", {}).get("loras"):
            raise ValueError("Custom LoRA settings do not match this exported workflow. Configure a workflow containing the requested adapters before generating.")
        if template.get("kind") == "reference" and not references:
            raise ValueError("This image-edit workflow needs a source or character reference image. Use text-to-image for a new reference sheet.")
        reference_count = len(request.get('referenceImages', [])) + int(request.get('operation') == 'edit')
        if 'referenceCount' in template and template['referenceCount'] != reference_count:
            raise ValueError('Selected workflow requires exactly ' + str(template['referenceCount']) + ' references. Use the automatic workflow for this shot.')
        if template.get("kind") == "text" and references:
            raise ValueError("This text-to-image workflow cannot condition on character references. Select a reference workflow; no references were discarded.")
        # Lightning adapters are trained for a fixed step count and CFG.
        # Their exact preset settings are stored with the resulting image.
        return template, settings | template.get("presetSettings", {})

    def healthCheck(self, model=None, workflow=None):
        try:
            template = self.template()
            catalog_stamp = (self.config.get("comfyWorkflow"), Path(self.config["comfyWorkflow"]).stat().st_mtime_ns)
            stamp=catalog_stamp+(model,workflow)
            if self._health[1] and self._health[1][0] == stamp and time.time() - self._health[0] < 30:
                return copy.deepcopy(self._health[1][1])
            if self._node_catalog[1] and self._node_catalog[1][0]==catalog_stamp and time.time()-self._node_catalog[0]<30:
                nodes=self._node_catalog[1][1]
            else:
                nodes = request_json(self.url + "/object_info", timeout=10)
                self._node_catalog=(time.time(),(catalog_stamp,nodes))
            templates = template.get("variants", [template])
            selected=model or template.get('automaticWorkflows',{}).get(workflow,{}).get('model')
            explicit=[t for t in templates if t['name']==workflow] if workflow else []
            if explicit:templates=explicit
            elif selected:
                templates=[t for t in templates if t['model']==selected or
                    selected==template['model'] and t['model'] not in template.get('modelCapabilities',{})]
            if not templates:return {'installed':False,'models':[],'workflow':[],
                'error':'Selected image model/workflow is not configured.'}
            # Generic status may advertise the ready subset of a mixed bundle.
            # Selected generation must validate only its relevant graphs; a
            # deliberately removed unrelated checkpoint cannot block FLUX.
            if not model and not workflow and len(templates)>1:
                checks=[self.healthCheck(t['model'],t['name']) for t in templates]
                ready=[t for t,check in zip(templates,checks) if check['installed']]
                auto=[name for name,value in template.get('automaticWorkflows',{}).items()
                      if any(t['model']==value['model'] for t in ready)]
                return {'installed':bool(ready),'models':list(dict.fromkeys(t['model'] for t in ready)),
                    'workflow':[t['name'] for t in ready]+auto,
                    'unavailableWorkflows':[t['name'] for t,check in zip(templates,checks) if not check['installed']],
                    'missingNodes':list(dict.fromkeys(n for check in checks for n in check.get('missingNodes',[]))) if not ready else [],
                    'missingWeights':list(dict.fromkeys(n for check in checks for n in check.get('missingWeights',[]))) if not ready else []}
            missing = [
                v["class_type"]
                for t in templates for v in t["prompt"].values()
                if v["class_type"] not in nodes
            ]
            missing_weights = []
            for node in (n for t in templates for n in t["prompt"].values()):
                info = (
                    nodes.get(node["class_type"], {})
                    .get("input", {})
                    .get("required", {})
                )
                for field in (
                    "ckpt_name",
                    "unet_name",
                    "vae_name",
                    "clip_name",
                    "lora_name",
                    "control_net_name",
                ):
                    choices = info.get(field, [None])[0]
                    if (
                        field in node["inputs"]
                        and isinstance(choices, list)
                        and node["inputs"][field] not in choices
                    ):
                        missing_weights.append(node["inputs"][field])
            result = {
                "installed": not missing and not missing_weights,
                "models": list(dict.fromkeys([template["model"]] + [t["model"] for t in templates])),
                "workflow": list(dict.fromkeys([template["name"]] + [t["name"] for t in templates] + list(template.get('automaticWorkflows', {})))),
                "missingNodes": missing,
                "missingWeights": missing_weights,
            }
            if result["installed"]:
                self._health = (time.time(), (stamp, result))
            return result
        except Exception as e:
            return {"installed": False, "error": str(e)}

    def generateImage(self, r, checkpoint):
        began = time.monotonic()
        polling_interval = self.config.get('comfyPollInterval', .25)
        timeout = self.config.get('comfyGenerationTimeoutSeconds', 600)
        if (isinstance(polling_interval, bool) or not isinstance(polling_interval, (int, float))
                or not math.isfinite(polling_interval) or not .1 <= polling_interval <= 2):
            raise ValueError('ComfyUI polling interval must be 0.1–2 seconds.')
        if (isinstance(timeout, bool) or not isinstance(timeout, (int, float))
                or not math.isfinite(timeout) or not 30 <= timeout <= 3600):
            raise ValueError('ComfyUI generation timeout must be 30–3600 seconds.')
        s = self.validateSettings(r["settings"])
        t, s = self.resolve_template(r, s)
        health = self.healthCheck(model=t['model'],workflow=t.get('name'))
        if not health["installed"]:
            raise RuntimeError("ComfyUI workflow unavailable: " + str(health))
        if not self.template().get("variants") and s.get("model") != t["model"]:
            raise ValueError(
                "Selected Comfy model does not match the configured workflow."
            )
        prompt = copy.deepcopy(t["prompt"])
        values = {
            "prompt": r["prompt"],
            "negativePrompt": r.get("negativePrompt", ""),
            **s,
        }
        for key, bindings in t["bindings"].items():
            if key in values:
                for node, field in bindings:
                    prompt[str(node)]["inputs"][field] = values[key]
        # Reference slots are explicit bindings, never assumed from model names.
        refs = r.get("referenceImages", [])
        if r.get("operation") == "edit":
            refs = [r["sourceImage"]] + refs
        if len(refs) > self.getCapabilities().get("maxReferenceImages", 0):
            raise ValueError("Too many references for this ComfyUI workflow, including the edit source. No character references were silently dropped.")
        for index in range(len(refs)):
            if not t["bindings"].get("reference" + str(index)):
                raise ValueError(f"ComfyUI workflow has no binding for reference {index + 1}. Configure character references before generating.")
        for index, node in t.get("referenceNodes", {}).items():
            if int(index) >= len(refs):
                prompt.pop(str(node), None)
                for value in prompt.values():
                    value["inputs"] = {key: field for key, field in value["inputs"].items()
                        if not (isinstance(field, list) and field and str(field[0]) == str(node))}
        prepared = time.monotonic()
        upload_hits = 0
        for index, ref in enumerate(refs):
            checkpoint(0, s["steps"], "Uploading character references")
            raw = base64.b64decode(ref.split(",", 1)[-1])
            fingerprint = hashlib.sha256(raw).hexdigest()
            uploaded_name = self._uploads.get(fingerprint)
            upload_hits += int(bool(uploaded_name))
            boundary = "qt-" + secrets.token_hex(8)
            name = "qt-" + secrets.token_hex(8) + ".png"
            body = (
                f'--{boundary}\r\nContent-Disposition: form-data; name="image"; filename="{name}"\r\nContent-Type: image/png\r\n\r\n'.encode()
                + raw
                + f"\r\n--{boundary}--\r\n".encode()
            )
            req = urllib.request.Request(
                self.url + "/upload/image",
                data=body,
                headers={"Content-Type": "multipart/form-data; boundary=" + boundary},
            )
            if not uploaded_name:
                with urllib.request.urlopen(req, timeout=30) as response:
                    uploaded = json.load(response)
                uploaded_name = uploaded["name"]
                self._uploads[fingerprint] = uploaded_name
            for node, field in t["bindings"].get("reference" + str(index), []):
                prompt[str(node)]["inputs"][field] = uploaded_name
        uploaded_at = time.monotonic()
        observer = r.get('_executionObserver')
        if observer is not None and not callable(observer):
            raise ValueError('Execution observer must be callable.')
        operation_id = 'comfy-' + secrets.token_hex(16)
        if observer:
            observer('submitting', {'operationId': operation_id, 'provider': 'comfyui'})
        try:
            job = request_json(
                self.url + "/prompt", {"prompt": prompt, "client_id": secrets.token_hex(16)}
            )
            id = job['prompt_id']
            if not isinstance(id,str) or not id:
                raise ValueError('No confirmed ComfyUI prompt identity.')
            if observer:
                try:observer('accepted', {'operationId': operation_id, 'remoteId': id})
                except Exception as error:raise RemoteGenerationUncertain(id) from error
        except urllib.error.HTTPError as error:
            # A gateway can return 408 after the worker accepted the request.
            # Only explicit rejection statuses are safe to classify as unused.
            if error.code in (400, 401, 403, 404, 413, 422, 429):
                if observer:
                    observer('rejected', {'operationId': operation_id})
                raise
            raise RemoteGenerationUncertain() from error
        except (OSError, ValueError, KeyError) as error:
            raise RemoteGenerationUncertain() from error
        submitted_at = time.monotonic()
        started = time.time()
        polls = 0
        try:
            while True:
                checkpoint(0, s["steps"], "ComfyUI generation")
                try:
                    history = request_json(self.url + "/history/" + id, timeout=15)
                except (OSError, ValueError) as error:
                    raise RemoteGenerationUncertain(id) from error
                polls += 1
                if id in history:
                    break
                if time.monotonic() - submitted_at > timeout:
                    raise RemoteGenerationUncertain(id, timed_out=True)
                time.sleep(polling_interval)
        except Exception as error:
            # Remove this queued job. Interrupt only if this job owns the running slot.
            # A transient disconnect may still finish successfully. Leave that
            # request alone for reconciliation; explicit cancel/timeout stops it.
            if not isinstance(error, RemoteGenerationUncertain) or error.timed_out:
                try:
                    request_json(self.url + "/queue", {"delete": [id]}, timeout=3)
                    q = request_json(self.url + "/queue", timeout=3)
                    if any(v[1] == id for v in q.get("queue_running", [])):
                        request_json(self.url + "/interrupt", {}, timeout=3)
                except Exception:
                    pass
            raise
        finished_at = time.monotonic()
        entry = history[id]
        if entry.get("status", {}).get("status_str") == "error":
            if observer:
                try:observer('failed', {'operationId': operation_id})
                except Exception as error:raise RemoteGenerationUncertain(id) from error
            raise RuntimeError("ComfyUI failed: " + str(entry.get("status"))[:1200])
        try:
            image = next(
                v["images"][0] for v in entry["outputs"].values() if v.get("images")
            )
        except (KeyError, StopIteration, TypeError, AttributeError) as error:
            raise RemoteGenerationUncertain(id) from error
        from urllib.parse import urlencode

        try:
            with urllib.request.urlopen(self.url + "/view?" + urlencode(image), timeout=30) as response:
                raw = response.read()
        except OSError as error:
            raise RemoteGenerationUncertain(id) from error
        img = visible_image(raw)
        if observer:
            try:observer('completed', {'operationId': operation_id})
            except Exception as error:raise RemoteGenerationUncertain(id) from error
        return {
            "pil": img,
            "seed": s["seed"],
            "seconds": time.time() - started,
            "provider": self.id,
            "model": t["model"],
            "workflow": t["name"],
            "settings": s,
            "resolvedWorkflow": prompt,
            'remotePromptId': id,
            'serverExecutionEvidence': execution_evidence(entry,prompt),
            'providerTimings': {
                'preparationSeconds': prepared-began,
                'referenceUploadSeconds': uploaded_at-prepared,
                'submissionSeconds': submitted_at-uploaded_at,
                'waitAndPollingSeconds': finished_at-submitted_at,
                'retrievalAndValidationSeconds': time.monotonic()-finished_at,
                'totalClientSeconds': time.monotonic()-began,
                'historyRequests': polls,
                'references':len(refs),'referenceUploadCacheHits':upload_hits,
                'timingSource':'client wall time; wait includes queue, inference and polling',
            },
        }


def visible_appearance(shot, selected):
    # Persistent possessions remain in story state. A visible prop needs a
    # current director decision, rather than blindly reenacting prior combat.
    context = ' '.join(str(shot.get(k, '')) for k in ('action', 'narrationSegment', 'pose'))
    context += ' ' + str(shot.get('camera', {}).get('composition', ''))
    appearance = selected.get('appearanceState', {})
    weapons = ('gun', 'hammer', 'knife', 'sword', 'bomb')
    named = {k for k in weapons if re.search(r'\b'+k+r's?\b', context, re.IGNORECASE)}
    # A director can write "weapon raised" while the canonical scene state
    # says "gun in his hand". Do not erase that unambiguous visible prop, or
    # the generator is left to invent a blade. Carried/stowed inventory and
    # multiple held weapons remain insufficient evidence to choose a prop.
    if not named and re.search(r'\bweapons?\b', context, re.IGNORECASE) and not re.search(
        r'\bunarmed\b|\bempty[- ]handed\b|\b(?:no|without)\s+(?:(?:a|any|his|her|their)\s+)?weapons?\b', context, re.IGNORECASE
    ):
        held = []
        for kind in weapons:
            state = str(appearance.get(kind, '')).lower().replace('_', ' ')
            if not re.search(r'\b(?:dropped|removed|holstered|stowed)\b|on (?:the )?floor|not holding|no longer', state) and re.search(
                r'\b(?:holding|held|wielding|aiming|raised|firing)\b|\b(?:right|left) hand\b|\bin (?:(?:his|her|their|the) )?hand\b', state
            ):
                held.append(kind)
        if len(held) == 1:
            named.add(held[0])
    return {k:v for k,v in appearance.items() if k not in weapons or k in named}


def visual_continuity(value, names):
    """Keep visual facts while removing database identifiers from model text."""
    if isinstance(value, dict):
        return {names.get(key, key): visual_continuity(item, names)
                for key, item in value.items()
                if not re.search(r'(?:^id$|[_-]ids?$|Ids?$|IDs?$)', key)}
    if isinstance(value, list):
        return [visual_continuity(item, names) for item in value]
    return names.get(value, value) if isinstance(value, str) else value


def format_prompt(project, shot, provider):
    from prompt_quality import focused
    use_focused = focused(project,shot)
    if project["settings"].get("focusedPrompts") is True and shot.get("manual",{}).get("prompt"):
        return shot.get("prompt",""),shot.get("negativePrompt","")
    people = {c["id"]: c for c in project["characters"]}
    ch = next(c for c in project["chapters"] if c["id"] == shot["chapterId"])
    people.update({c["id"]: c for c in ch["people"]})
    descriptions = []
    for selected in shot["characters"]:
        p = people.get(selected["id"], {})
        identity = p.get("permanentIdentity", {})
        details = (
            [p.get("name", selected["id"])]
            + ([p.get("description", "")] if not any(identity.values()) else [])
            + [f"{k}: {v}" for k, v in identity.items() if v]
            + [f"{k}: {v}" for k, v in visible_appearance(shot, selected).items() if v]
        )
        if use_focused:
            details += [f"{k}: {p[k]}" for k in ("gender","approximateAge") if p.get(k)]
        descriptions.append("; ".join(details))
    camera = shot["camera"]
    parts = [
        shot["action"],
        (
            "Characters: " + " / ".join(descriptions)
            if descriptions
            else "No people in this shot."
        ),
        "Camera: "
        + camera["shot"]
        + ", "
        + camera["angle"]
        + ". "
        + camera["composition"],
        "Location: " + shot.get("location", ""),
        "Expression and pose: "
        + shot.get("expression", "")
        + "; "
        + shot.get("pose", ""),
        "Lighting: " + shot.get("lighting", ""),
        "Style: " + project["settings"]["style"],
    ]
    visual_constraints = project['settings'].get('imageVisualConstraints', project['settings'].get('visualConstraints', ''))
    if visual_constraints:
        parts.append('Production constraints: ' + visual_constraints)
    parts.append('One continuous landscape scene; one simultaneous moment. Preserve identities and current clothing; only stated story changes override them.' if use_focused else 'One continuous landscape composition depicting one simultaneous moment. No collage, split panels, borders, labels or title text. Preserve the specified identities and current clothing; do not remove clothing without a stated story change.')
    if shot.get("continuity"):
        # Persistent environmental history is not an instruction to reenact an
        # earlier battle. Only stable scene conditions belong in this prompt.
        names = {key: person.get('name', key) for key, person in people.items()}
        names.update({place['id']: place.get('name', place['id']) for place in project.get('locations', [])})
        continuity = visual_continuity({k:v for k,v in shot['continuity'].items()
                      if k not in ('mood','gunfire','elapsedTime','condition')}, names)
        if continuity:
            parts.append("Keep: " + json.dumps(continuity, ensure_ascii=False))
    caps = (provider.getModelCapabilities(shot.get('imageModel', ''))
            if hasattr(provider, 'getModelCapabilities') else provider.getCapabilities())
    prompt = (
        ". ".join(p for p in parts if p)
        + (". No extra people, duplicate weapons, panels, borders, captions or watermark." if use_focused else ". No rendered text, captions, or additional important people.")
    )
    if caps.get("promptFormat") == "sd-tags":
        prompt = (
            ", ".join(p for p in parts if p)
            + ", clear foreground action, consistent character identity, coherent composition"
        )
    negative = (
        "text, watermark, black frame, severe artifacts, extra limbs, malformed hands, unwanted characters"
        if caps.get("supportsNegativePrompt")
        else ""
    )
    return prompt, negative


def reference_prompt(project, shot, metadata, operation="generate"):
    """Name reference roles without locking a character to old reference clothing."""
    chapter = next(c for c in project["chapters"] if c["id"] == shot["chapterId"])
    people = {c["id"]: c for c in project["characters"] + chapter["people"]}
    appearances = {c['id']: visible_appearance(shot, c) for c in shot['characters']}
    from prompt_quality import focused
    use_focused = focused(project,shot)
    notes = []
    offset = 1 if operation == "edit" else 0
    if offset:
        notes.append("Image 1 is the shot to edit. Preserve its unaffected people, objects and composition.")
    for index, ref in enumerate(metadata, 1 + offset):
        if ref.get("characterId"):
            person = people.get(ref["characterId"], {})
            if use_focused:
                notes.append(f'Image {index}: {person.get("name", ref["characterId"])} permanent face identity. Shot controls clothing and pose: ' + json.dumps(appearances.get(ref["characterId"],{}),ensure_ascii=False) + ".")
                continue
            notes.append(
                f'Use image {index} as the identity reference for {person.get("name", ref["characterId"])}. '
                "Preserve face and permanent traits. Current appearance overrides reference clothing: "
                + json.dumps(appearances.get(ref["characterId"], {}), ensure_ascii=False) + "."
            )
        elif ref.get("locationId"):
            notes.append(f"Use image {index} for the location architecture and palette, not character identity.")
        elif ref.get("referenceType") == "style":
            notes.append(f"Use image {index} for visual style only, not its characters or events.")
        else:
            notes.append(f"Use image {index} only for its user-selected reference role.")
    return " ".join(notes)


def select_references(project, shot, store, provider, reserved_slots=0):
    caps = (provider.getModelCapabilities(shot['imageModel'])
            if shot.get('imageModel') and hasattr(provider, 'getModelCapabilities')
            else provider.getCapabilities())
    maximum = max(0, caps.get("maxReferenceImages", 0) - reserved_slots)
    refs = []
    metadata = []
    if shot.get("manual", {}).get("referenceImages"):
        selected = shot.get("referenceImages", [])
        if len(selected) > maximum:
            raise ValueError('Selected references exceed the image workflow limit '
                             f'({len(selected)} selected, {maximum} available). '
                             'Choose a compatible workflow or edit the reference selection; '
                             'no references were silently dropped.')
        return [
            data_url(store.asset(project["id"], r["path"])) for r in selected
        ], copy.deepcopy(selected)
    chapter = next(c for c in project["chapters"] if c["id"] == shot["chapterId"])
    people = project["characters"] + chapter["people"]
    required_main = sum(
        selected.get('type') == 'main'
        and bool(next((p.get('references') for p in people if p['id'] == selected['id']), []))
        for selected in shot['characters']
    )
    if caps.get('maxReferenceImages', 0) and required_main > maximum:
        raise ValueError(f'This shot needs identity references for {required_main} main characters, '
                         f'but the selected model/workflow has {maximum} available reference slots '
                         'after reserving the edit source. Choose a compatible workflow; '
                         'no character identity references were silently dropped.')
    if not maximum:
        return [], []
    for selected in sorted(shot["characters"], key=lambda c: c["type"] != "main"):
        p = next((c for c in people if c["id"] == selected["id"]), None)
        if not p:
            continue
        options = p.get("references", [])
        angle = shot["camera"].get("angle", "").lower()
        distance = shot["camera"].get("shot", "").lower()
        desired = (
            ["side", "full-body"]
            if "profile" in angle + distance
            else (
                ["back", "full-body"]
                if "behind" in angle
                else (
                    ["face", "front", "expression"]
                    if "close" in distance
                    else ["full-body", "three-quarter", "front"]
                )
            )
        )
        ordered = sorted(
            options,
            key=lambda r: (
                desired.index(r.get("kind")) if r.get("kind") in desired else 9
            ),
        )
        if ordered:
            if len(refs) >= maximum:
                break
            r = ordered[0]
            refs.append(data_url(store.asset(project["id"], r["path"])))
            metadata.append(r | {"characterId": p["id"]})
    if len(refs) < maximum and caps.get("supportsStyleReference"):
        location = next(
            (
                x
                for x in project.get("locations", [])
                if x["id"] == shot.get("locationId")
            ),
            None,
        )
        if location and location.get("references"):
            r = location["references"][0]
            refs.append(data_url(store.asset(project["id"], r["path"])))
            metadata.append(r | {"locationId": location["id"]})
        if len(refs) < maximum and project.get("styleReferences"):
            r = project["styleReferences"][0]
            refs.append(data_url(store.asset(project["id"], r["path"])))
            metadata.append(r | {"referenceType": "style"})
    return refs[:maximum], metadata[:maximum]
