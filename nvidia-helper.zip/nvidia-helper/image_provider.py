"""Image backends are replaceable; no story facts or timeline logic lives here."""
from prompt_quality import execution_evidence

import base64, copy, hashlib, io, json, math, re, secrets, subprocess, sys, time, urllib.error, urllib.request
from pathlib import Path
from studio_data import shot_chapter
from collections import OrderedDict
import threading
import http.client
from PIL import Image, ImageStat
from director_provider import local_url, request_json

BASE_CAPS = {
    k: False
    for k in (
        "supportsMultipleReferences",
        "supportsImageEditing",
        "supportsNegativePrompt",
        "supportsSeed",
        "supportsPoseReference",
        "supportsControlNet",
        "supportsIPAdapter",
        "supportsStyleReference",
        "supportsLoRA",
        "supportsInpainting",
        "supportsOutpainting",
        "supportsUpscaling",
        "supportsVisionInput",
        "supportsBatchGeneration",
    )
}


class RemoteGenerationUncertain(RuntimeError):
    """A request may already have generated an image; never retry automatically."""
    def __init__(self, prompt_id=None, timed_out=False):
        self.prompt_id = prompt_id
        self.timed_out = timed_out
        detail = (' ComfyUI prompt ID: ' + str(prompt_id) + '.') if prompt_id else ''
        super().__init__('Image request outcome is uncertain.' + detail +
            ' Check the existing ComfyUI queue/history before retrying; no automatic new generation was submitted.'
            ' Stop the rented GPU if you are finished: stopping this queue does not stop rental billing.')


class ImageAdmissionBlocked(RuntimeError):
    """No POST belongs to this request; do not retry or switch image providers."""
    submitted = False
    prompt_id = None

    def __init__(self, reason):
        super().__init__(reason + ' This request was not submitted; no automatic retry or alternate image provider is permitted.')


class ComfyHTTPPool:
    """Bounded keepalive to one private Comfy endpoint; never retry a request.

    A lost POST reply is still uncertain. Fully read responses are detached from
    the connection before reuse, so concurrent image jobs never share a socket.
    Worker resets invalidate idle connections and retire in-flight leases when
    those replies finish. No API keys, cross-origin requests or redirects.
    """
    def __init__(self, endpoint, capacity=4, idle_seconds=15):
        from urllib.parse import urlsplit
        self.endpoint=local_url(endpoint)
        parsed=urlsplit(self.endpoint)
        self.origin=(parsed.scheme,parsed.hostname,parsed.port or 80)
        self.capacity=capacity;self.idle_seconds=idle_seconds
        self.cv=threading.Condition();self.idle=[];self.active=0;self.epoch=0

    def invalidate(self):
        with self.cv:
            self.epoch+=1
            for connection,_when,_epoch in self.idle:connection.close()
            self.idle.clear();self.cv.notify_all()

    def open(self, request, timeout=180):
        from urllib.parse import urlsplit
        if isinstance(request,str):request=urllib.request.Request(request)
        parsed=urlsplit(request.full_url)
        if ((parsed.scheme,parsed.hostname,parsed.port or 80)!=self.origin
                or parsed.username or parsed.password or parsed.fragment):
            raise ValueError('Persistent Comfy requests must remain on their private endpoint.')
        deadline=time.monotonic()+timeout
        with self.cv:
            while self.active>=self.capacity:
                remaining=deadline-time.monotonic()
                if remaining<=0:raise TimeoutError('Private Comfy connection capacity wait timed out.')
                self.cv.wait(remaining)
            self.active+=1;epoch=self.epoch;connection=None
            while self.idle:
                candidate,when,saved_epoch=self.idle.pop()
                if saved_epoch==epoch and time.monotonic()-when<self.idle_seconds:
                    connection=candidate;break
                candidate.close()
        reusable=False
        try:
            remaining=deadline-time.monotonic()
            if remaining<=0:raise TimeoutError('Private Comfy request timed out before dispatch.')
            if connection is None:
                connection=http.client.HTTPConnection(parsed.hostname,parsed.port or 80,timeout=remaining)
            else:
                connection.timeout=remaining
                if connection.sock is not None:connection.sock.settimeout(remaining)
            headers=dict(request.header_items())
            headers.setdefault('User-agent','Python-urllib/'+urllib.request.__version__)
            selector=parsed.path or '/'
            if parsed.query:selector+='?'+parsed.query
            # Exactly one dispatch. A disconnected reused socket must not cause
            # an automatic replacement POST that could buy a duplicate image.
            connection.request(request.get_method(),selector,body=request.data,headers=headers)
            response=connection.getresponse()
            data=response.read();status=response.status;reason=response.reason;response_headers=response.headers
            reusable=not response.will_close
            response.close()
            if not 200<=status<300:
                reusable=False
                raise urllib.error.HTTPError(request.full_url,status,reason,response_headers,io.BytesIO(data))
            return io.BytesIO(data)
        except http.client.HTTPException as error:
            raise OSError('Private Comfy HTTP reply was incomplete: '+type(error).__name__) from error
        finally:
            with self.cv:
                if connection is not None:
                    if reusable and epoch==self.epoch:self.idle.append((connection,time.monotonic(),epoch))
                    else:connection.close()
                self.active-=1;self.cv.notify_all()

    def json(self,url,body=None,timeout=180):
        request=urllib.request.Request(url,data=None if body is None else json.dumps(body).encode(),
            headers={'Content-Type':'application/json'})
        with self.open(request,timeout) as response:return json.load(response)
BASE_CAPS.update(
    maxReferenceImages=0,
    maxResolution=512,
    recommendedResolution=[512, 512],
    recommendedSteps=20,
    recommendedSampler="DPM++ 2M",
    recommendedGuidance=7,
    recommendedDenoisingStrength=0.65,
    promptFormat="sd-tags",
    negativePromptFormat="comma-tags",
    hardwareRequirements={"vramGB": 4, "ramGB": 8},
)
_GPU_MEMORY = (0, None)


def gpu_memory_gb():
    global _GPU_MEMORY
    if time.time() - _GPU_MEMORY[0] > 60:
        try:
            memory = (
                float(
                    subprocess.check_output(
                        [
                            "nvidia-smi",
                            "--query-gpu=memory.total",
                            "--format=csv,noheader,nounits",
                        ],
                        text=True,
                    ).splitlines()[0]
                )
                / 1024
            )
        except Exception:
            memory = None
        _GPU_MEMORY = (time.time(), memory)
    return _GPU_MEMORY[1]


class ImageEncodingCache:
    """Bounded exact-byte preparation, invalidated by each local file revision."""
    def __init__(self,max_bytes=32*2**20):
        self.max_bytes=max_bytes;self.bytes=0;self.items=OrderedDict();self.lock=threading.RLock()
        # Reuse the exact bytes/digest already read by encode(), or prepare an
        # externally supplied immutable data URL once. This separate bounded
        # LRU counts retained input keys, raw bytes, digest strings, tuples and
        # incremental OrderedDict storage (fixed empty-cache overhead excluded).
        self.decoded=OrderedDict();self.decoded_bytes=0;self._decoded_base=sys.getsizeof(self.decoded)
    @property
    def decoded_retained_bytes(self):
        with self.lock:
            return self.decoded_bytes+max(0,sys.getsizeof(self.decoded)-self._decoded_base)
    @staticmethod
    def _decoded_size(value,entry):
        return sys.getsizeof(value)+sys.getsizeof(entry)+sum(sys.getsizeof(item) for item in entry)
    def _remember_reference(self,value,raw,fingerprint):
        # Caller holds the shared lock. Keys and values are immutable, so exact
        # string equality is sufficient; no path/stat/worker assumptions apply.
        old=self.decoded.get(value)
        if old is not None:
            self.decoded.move_to_end(value);return old
        entry=(raw,fingerprint);size=self._decoded_size(value,entry)
        if size>self.max_bytes:return entry
        self.decoded[value]=entry;self.decoded_bytes+=size
        while self.decoded and (self.decoded_retained_bytes>self.max_bytes or len(self.decoded)>128):
            key,removed=self.decoded.popitem(last=False);self.decoded_bytes-=self._decoded_size(key,removed)
        if not self.decoded:self.decoded=OrderedDict()
        return entry
    def reference_bytes(self,value):
        with self.lock:
            # Oversized inputs still follow the existing decode/hash path but
            # are never retained as cache keys or values.
            if sys.getsizeof(value)<=self.max_bytes:
                old=self.decoded.get(value)
                if old is not None:self.decoded.move_to_end(value);return old
            raw=base64.b64decode(value.split(',',1)[-1])
            return self._remember_reference(value,raw,hashlib.sha256(raw).hexdigest())
    @staticmethod
    def stamp(path):
        stat=path.stat();return (stat.st_ino,stat.st_size,stat.st_mtime_ns,stat.st_ctime_ns)
    def encode(self,path):
        path=Path(path).resolve();key=str(path)
        with self.lock:
            before=self.stamp(path);old=self.items.get(key)
            # Windows can report identical timestamps for two same-size writes
            # inside one filesystem clock tick. Verify bytes on every hit;
            # cache expensive encoding, never infer identity from stat alone.
            raw=path.read_bytes();fingerprint=hashlib.sha256(raw).digest()
            if old and old[0]==before and old[2]==fingerprint:
                self.items.move_to_end(key);self._remember_reference(old[1],raw,fingerprint.hex());return old[1]
            value='data:image/png;base64,'+base64.b64encode(raw).decode()
            if old:self.bytes-=len(self.items.pop(key)[1])
            if len(value)<=self.max_bytes and self.stamp(path)==before:
                self.items[key]=(before,value,fingerprint);self.bytes+=len(value)
                while self.bytes>self.max_bytes or len(self.items)>128:
                    _,entry=self.items.popitem(last=False);self.bytes-=len(entry[1])
            self._remember_reference(value,raw,fingerprint.hex())
            return value


_image_encoding_cache=ImageEncodingCache()
def data_url(path):
    return _image_encoding_cache.encode(path)


def visible_image(raw):
    img = Image.open(io.BytesIO(raw)).convert("RGB")
    img.load()
    if max(max(v) for v in img.getextrema()) <= 2:
        raise RuntimeError(
            "Generator returned a black image. The output was rejected; inspect model precision, VAE and workflow."
        )
    return img


class ImageProvider:
    id = "abstract"

    def available_vram_gb(self):
        return gpu_memory_gb()

    def getCapabilities(self):
        return dict(BASE_CAPS)

    def getRecommendedSettings(self):
        return {
            "width": 512,
            "height": 512,
            "steps": 20,
            "sampler": "dpm++2m",
            "scheduler": "karras",
            "guidance": 7,
            "denoisingStrength": 0.65,
        }

    def validateSettings(self, s, check_hardware=True):
        caps = self.getModelCapabilities(s.get('model', '')) if hasattr(self, 'getModelCapabilities') else self.getCapabilities()
        result = copy.deepcopy(s)
        memory = self.available_vram_gb() if check_hardware else None
        requirements = caps.get("hardwareRequirements", {})
        minimum = requirements.get("vramGB", 0)
        unit = requirements.get('vramUnit', 'GiB')
        if unit not in ('GiB', 'nominalGB'):
            raise ValueError('Unknown workflow VRAM unit.')
        if isinstance(minimum,bool) or not isinstance(minimum,(int,float)) or not math.isfinite(minimum) or minimum<0:
            raise ValueError('Workflow VRAM requirement must be a non-negative number.')
        # Existing declarations retain their GiB semantics. A workflow may
        # explicitly describe a marketed card class in nominal GB instead.
        # Driver/ECC reservations are then handled in the same byte units as
        # the remote hardware admission; this does not promise inference fit.
        minimum_gib = minimum*1_000_000_000*.94/2**30 if unit=='nominalGB' else minimum
        if (
            memory is not None
            and minimum_gib > memory + 0.05
            and requirements.get("mode") not in ("cpu", "cpu-offload")
        ):
            raise ValueError(
                f"This workflow requires approximately {minimum} {unit} VRAM; this GPU has {memory:.1f} GiB usable. Select a smaller model or explicitly configure a tested CPU/offload workflow."
            )
        for field in ("width", "height", "steps"):
            n = result.get(field, self.getRecommendedSettings()[field])
            if (
                isinstance(n, bool)
                or not isinstance(n, (int, float))
                or not math.isfinite(n)
            ):
                raise ValueError("Invalid " + field)
            result[field] = int(n)
        if (
            not 256 <= result["width"] <= caps["maxResolution"]
            or not 256 <= result["height"] <= caps["maxResolution"]
        ):
            raise ValueError("Resolution exceeds this provider’s tested memory limits.")
        if (
            result["width"] % 8
            or result["height"] % 8
            or not 1 <= result["steps"] <= 60
        ):
            raise ValueError("Use dimensions divisible by eight and 1–60 steps.")
        if result.get("loras") and not caps["supportsLoRA"]:
            raise ValueError("This workflow does not support LoRA.")
        if result.get("controlnets") and not caps["supportsControlNet"]:
            raise ValueError("This workflow does not support ControlNet.")
        if result.get("ipAdapter") and not caps["supportsIPAdapter"]:
            raise ValueError("This workflow does not support IP-Adapter.")
        if result.get("seed") is None:
            result["seed"] = secrets.randbelow(2**31)
        if (
            isinstance(result["seed"], bool)
            or not isinstance(result["seed"], int)
            or not 0 <= result["seed"] < 2**32
        ):
            raise ValueError("Invalid seed.")
        return result

    def generateImage(self, request, checkpoint):
        raise NotImplementedError

    def editImage(self, request, checkpoint):
        if not self.getCapabilities()["supportsImageEditing"]:
            raise ValueError("Image editing unavailable for this workflow.")
        return self.generateImage(request | {"operation": "edit"}, checkpoint)

    def inpaintImage(self, request, checkpoint):
        if not self.getCapabilities()["supportsInpainting"]:
            raise ValueError("Inpainting unavailable for this workflow.")
        return self.generateImage(request | {"operation": "inpaint"}, checkpoint)

    def upscaleImage(self, request, checkpoint):
        raise ValueError(
            "No neural upscaler is installed. Rendering can resize images."
        )

    def unload(self):
        pass

    def healthCheck(self):
        return {"installed": False}


class ExistingImageProvider(ImageProvider):
    id = "existing"

    def __init__(self, engine):
        self.engine = engine

    def getCapabilities(self):
        return BASE_CAPS | {
            "supportsMultipleReferences": True,
            "supportsNegativePrompt": True,
            "supportsSeed": True,
            "supportsIPAdapter": True,
            "supportsStyleReference": True,
            "supportsInpainting": True,
            "supportsImageEditing": True,
            "supportsVisionInput": False,
            "maxReferenceImages": 3,
            "maxResolution": 768,
            "recommendedResolution": [512, 512],
            "promptFormat": "sd-tags",
            "negativePromptFormat": "comma-tags",
            "hardwareRequirements": {"vramGB": 4, "ramGB": 8},
            "referenceLimitations": "IP-Adapter combines references; separate multiple-character identity is approximate.",
        }

    def healthCheck(self):
        if time.time() - getattr(self, "checked", 0) > 15:
            self.checked = time.time()
            self.cached = []
            try:
                from huggingface_hub import snapshot_download

                for model, repo in (
                    ("sd15", "stable-diffusion-v1-5/stable-diffusion-v1-5"),
                    ("dreamshaper8", "Lykon/dreamshaper-8"),
                ):
                    try:
                        folder = Path(snapshot_download(repo, local_files_only=True))
                        if all(
                            (folder / name).is_file()
                            for name in (
                                "model_index.json",
                                "text_encoder/model.fp16.safetensors",
                                "unet/diffusion_pytorch_model.fp16.safetensors",
                                "vae/diffusion_pytorch_model.fp16.safetensors",
                            )
                        ):
                            self.cached.append(model)
                    except Exception:
                        pass
            except ImportError:
                pass
        return {
            "installed": bool(self.cached),
            "models": self.cached,
            "workflow": ["text-to-image", "ip-adapter", "inpaint"],
            "error": (
                ""
                if self.cached
                else "SD weights are not cached. Use an installed provider or explicitly install the checkpoint; no download was started."
            ),
        }

    def validateSettings(self, s):
        s = super().validateSettings(s)
        if s.get("model") not in ("sd15", "dreamshaper8"):
            raise ValueError("Unknown existing model.")
        if s["model"] not in self.healthCheck()["models"]:
            raise ValueError(
                "Selected SD checkpoint is not installed. Choose a cached model; no automatic multi-GB download was started."
            )
        if (
            not 384 <= s["width"] <= 768
            or not 384 <= s["height"] <= 768
            or not 8 <= s["steps"] <= 50
        ):
            raise ValueError("SD fallback needs dimensions 384–768 and 8–50 steps.")
        if (
            s.get("sampler", "DPM++ 2M") not in ("DPM++ 2M", "dpm++2m")
            or s.get("scheduler", "karras") != "karras"
        ):
            raise ValueError("Existing backend supports DPM++ 2M / karras only.")
        return s

    def generateImage(self, r, checkpoint):
        s = self.validateSettings(r["settings"])
        operation = r.get("operation", "generate")
        if operation == "edit" and not r.get("mask"):
            raise ValueError(
                "SD fallback repairs need an inpaint mask. Use native FLUX editing or provide a mask."
            )
        data = s | {
            "prompt": r["prompt"],
            "negative": r.get("negativePrompt", ""),
            "reference_images": r.get("referenceImages", [])[:3],
            "reference_strength": s.get("referenceStrength", 0.65),
            "preset": "balanced",
            "operation": "inpaint" if operation in ("edit", "inpaint") else "generate",
        }
        if data["operation"] == "inpaint":
            data.update(
                image=r["sourceImage"],
                mask=r["mask"],
                denoising_strength=s.get("denoisingStrength", 0.65),
            )
        result = self.engine().generate(data, checkpoint)
        result["provider"] = self.id
        return result

    def unload(self):
        self.engine().unload()


class NativeFluxProvider(ImageProvider):
    id = "native-flux"

    def __init__(self, config, log_root):
        self.config = config
        self.root = Path(log_root)
        self.process = None
        self.log = None
        self.url = "http://127.0.0.1:8767"

    def getCapabilities(self):
        return BASE_CAPS | {
            "supportsMultipleReferences": True,
            "supportsImageEditing": True,
            "supportsSeed": True,
            "supportsStyleReference": True,
            "supportsVisionInput": True,
            "maxReferenceImages": 2,
            "maxResolution": 448,
            "recommendedResolution": [448, 448],
            "recommendedSteps": 4,
            "recommendedSampler": "euler",
            "recommendedGuidance": 1,
            "promptFormat": "natural-language",
            "negativePromptFormat": "unsupported",
            "hardwareRequirements": {
                "vramGB": 4,
                "ramGB": 8,
                "mode": "quantized Q4, mmap disk weights, sequential GPU use; references/editing at 384px",
            },
        }

    def getRecommendedSettings(self):
        return {
            "width": 448,
            "height": 448,
            "steps": 4,
            "sampler": "euler",
            "scheduler": "flux2",
            "guidance": 1,
            "denoisingStrength": 1,
        }

    def healthCheck(self):
        installed = all(
            Path(self.config.get(k, "")).is_file()
            for k in ("imageExecutable", "fluxModel", "fluxEncoder", "fluxVae")
        )
        return {
            "installed": installed,
            "validated": bool(self.config.get("fluxValidated", False)),
            "models": ["flux2-klein-4b-q4"],
            "workflow": ["text-to-image", "reference-edit"],
            "running": bool(self.process and self.process.poll() is None),
        }

    def validateSettings(self, s):
        s = super().validateSettings(s)
        if s.get("model") != "flux2-klein-4b-q4":
            raise ValueError(
                "Only installed FLUX.2 Klein 4B Q4 is supported by this adapter."
            )
        if s.get("denoisingStrength", 1) != 1:
            raise ValueError(
                "Native Klein uses instruction-based editing. Its workflow has no SD denoising-strength control; use 1 or choose a masked SD/Comfy workflow."
            )
        if s.get("guidance", 1) != 1:
            raise ValueError(
                "Distilled Klein uses guidance 1. Choose its preset to reset SD settings."
            )
        if (
            s.get("sampler", "euler") != "euler"
            or s.get("scheduler", "flux2") != "flux2"
        ):
            raise ValueError("Use Euler / flux2 for this tested Klein workflow.")
        if not self.healthCheck()["installed"]:
            raise RuntimeError(
                "FLUX native files are unavailable. Choose an installed provider or configure the native model paths."
            )
        return s

    def start(self, checkpoint):
        if self.process and self.process.poll() is None:
            return
        if not self.healthCheck()["installed"]:
            raise RuntimeError("Native FLUX runtime/model files missing.")
        self.root.mkdir(parents=True, exist_ok=True)
        self.log = (self.root / "native-images.log").open("w", encoding="utf-8")
        backend = self.config.get("imageBackend")
        if not backend:
            raise ValueError(
                "Configure imageBackend using the detected NVIDIA Vulkan device. Integrated GPU selection is not allowed implicitly."
            )
        args = [
            self.config["imageExecutable"],
            "--listen-ip",
            "127.0.0.1",
            "--listen-port",
            "8767",
            "--diffusion-model",
            self.config["fluxModel"],
            "--llm",
            self.config["fluxEncoder"],
            "--vae",
            self.config["fluxVae"],
            "--mmap",
            "--params-backend",
            "disk",
            "--backend",
            backend,
            "--max-vram",
            "3.7",
            "--conditioning-cache-size",
            "8",
            "-t",
            "4",
        ]
        self.process = subprocess.Popen(
            args,
            stdout=self.log,
            stderr=self.log,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        for _ in range(180):
            checkpoint(0, 4, "Loading quantized FLUX")
            if self.process.poll() is not None:
                raise RuntimeError(
                    "Native FLUX failed to start. See outputs/studio/native-images.log."
                )
            try:
                request_json(self.url + "/sdcpp/v1/capabilities", timeout=1)
                return
            except Exception:
                time.sleep(0.5)
        self.unload()
        raise RuntimeError("Native FLUX startup timed out.")

    def generateImage(self, r, checkpoint):
        if r.get("operation") == "inpaint":
            raise ValueError(
                "Native Klein does not implement masked inpainting. Use its image-edit operation, or select a provider with masked inpaint support."
            )
        s = self.validateSettings(r["settings"])
        self.start(checkpoint)
        started = time.time()
        refs = r.get("referenceImages", [])[:2]

        def resize_reference(value, size):
            img = Image.open(
                io.BytesIO(base64.b64decode(value.split(",", 1)[-1]))
            ).convert("RGB")
            img.thumbnail((size, size))
            out = io.BytesIO()
            img.save(out, "PNG")
            return "data:image/png;base64," + base64.b64encode(out.getvalue()).decode()

        refs = [resize_reference(x, 224) for x in refs]
        if r.get("operation") == "edit":
            refs = [resize_reference(r["sourceImage"], 320)] + refs[:1]
        if refs and (s["width"] > 384 or s["height"] > 384):
            raise ValueError(
                "Reference/editing shots need at most 384×384 on this 4 GB GPU. Choose the Character Reference or Image Repair preset."
            )
        body = {
            "prompt": r["prompt"],
            "width": s["width"],
            "height": s["height"],
            "seed": s["seed"],
            "batch_count": 1,
            "ref_images": refs,
            "increase_ref_index": True,
            "sample_params": {
                "sample_steps": s["steps"],
                "sample_method": "euler",
                "scheduler": "flux2",
                "guidance": {"txt_cfg": 1, "img_cfg": 1, "distilled_guidance": 1},
            },
            "vae_tiling_params": {
                "enabled": True,
                "tile_size_w": 256,
                "tile_size_h": 256,
            },
        }
        job = request_json(self.url + "/sdcpp/v1/img_gen", body)
        jobid = job["id"]
        try:
            while True:
                info = request_json(self.url + "/sdcpp/v1/jobs/" + jobid)
                checkpoint(0, s["steps"], "FLUX " + info["status"])
                if info["status"] == "completed":
                    break
                if info["status"] in ("failed", "cancelled"):
                    tail = (self.root / "native-images.log").read_text(
                        errors="replace"
                    )[-1800:]
                    raise RuntimeError(
                        f'FLUX failed at {s["width"]}×{s["height"]} on this local backend: {info.get("error")}. Use 384×384 for references/repair and close other GPU apps. Runtime details: '
                        + tail
                    )
                time.sleep(0.3)
        except Exception:
            try:
                request_json(self.url + "/sdcpp/v1/jobs/" + jobid + "/cancel", {})
            except Exception:
                pass
            raise
        result = info["result"]
        img = visible_image(base64.b64decode(result["images"][0]["b64_json"]))
        return {
            "pil": img,
            "seed": s["seed"],
            "seconds": time.time() - started,
            "provider": self.id,
            "model": "FLUX.2-klein-4B Q4_0",
            "precision": "Q4_0 transformer/text encoder; native BF16 VAE weights with Vulkan decoding; black-frame validation",
            "backend": self.config["imageBackend"],
            "referenceCount": len(refs),
            "referencePreprocessing": {
                "identityMaxPixels": 224,
                "sourceEditMaxPixels": 320,
            },
            "settings": s,
            "runtime": "stable-diffusion.cpp 3f8527a",
        }

    def unload(self):
        if self.process and self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(10)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait()
        self.process = None
        if self.log:
            self.log.close()
            self.log = None


class ComfyImageProvider(ImageProvider):
    id = "comfyui"

    def __init__(self, config, request_slots=1):
        if type(request_slots) is not int or request_slots not in (1, 2):
            raise ValueError('Choose one or two ComfyUI request slots.')
        self.config = config
        self.url = local_url(config.get("comfyEndpoint", "http://127.0.0.1:8188"))
        # Matched real-worker ABBA kept all corresponding pixels identical.
        # Explicit False retains the original transport without changing any
        # saved image setting, workflow, kernel or reference bytes.
        self._transport=ComfyHTTPPool(self.url) if config.get('comfyPersistentHTTP',True) is True else None
        self._server_memory = (0, None)
        self._health = (0, None)
        self._node_catalog = (0, None)
        self._uploads = {}
        self._request_slots = request_slots
        self._admission = threading.Condition(threading.RLock())
        self._active_requests = 0
        self._worker_epoch = 0
        self._upload_flights = {}
        self._uncertain = threading.Event()
        self._uncertain_prompt = None
        self._worker_lifetime = None

    @property
    def client_capacity(self):
        return self._request_slots

    def begin_worker_lifetime(self, proof=None):
        """Accept only the owner's verified fresh rental, never a health refresh.

        The rental controller supplies the token only after a stopped-to-started
        owned worker or a newly created owned worker has passed readiness. This
        provider also refuses active-call resets and replay of a fenced token.
        """
        if (not isinstance(proof, dict) or proof.get('owned') is not True
                or proof.get('ready') is not True or proof.get('endpoint') != self.url
                or not isinstance(proof.get('podId'), str) or not proof['podId'].strip()
                or not isinstance(proof.get('lifetimeId'), str) or not proof['lifetimeId'].strip()):
            raise ValueError('A verified owned worker lifetime proof is required.')
        identity = (proof['podId'], proof['lifetimeId'])
        with self._admission:
            if self._active_requests:
                raise RuntimeError('Cannot reset a worker while image requests are active.')
            if identity == self._worker_lifetime:
                if self._uncertain.is_set():
                    raise RuntimeError('The same worker still has unresolved remote work; no reset permitted.')
                return
            self.invalidate_backend_cache()
            self._worker_lifetime = identity
            self._uncertain_prompt = None
            self._uncertain.clear()

    def _available_for_dispatch(self, epoch=None):
        if self._uncertain.is_set():
            raise ImageAdmissionBlocked('This image endpoint has unresolved remote work; reconcile and verify a fresh owned worker before new dispatch.')
        if self._request_slots == 2 and self._worker_lifetime is None:
            raise ImageAdmissionBlocked('Queued image delivery requires a verified owned worker lifetime.')
        if epoch is not None and epoch != self._worker_epoch:
            raise ImageAdmissionBlocked('Image worker metadata changed during preparation.')

    def _acquire_request(self, request, checkpoint):
        while True:
            checkpoint(0, request.get('settings', {}).get('steps', 1), 'Waiting for a ComfyUI request slot')
            with self._admission:
                self._available_for_dispatch()
                if self._active_requests < self._request_slots:
                    self._active_requests += 1
                    return self._worker_epoch
                self._admission.wait(.05)

    def _latch_uncertainty(self, prompt_id=None):
        # Set the flag before waiting for the admission mutex or releasing a
        # slot. Preparing requests recheck it immediately before their POST.
        self._uncertain.set()
        with self._admission:
            if self._uncertain_prompt is None:
                self._uncertain_prompt = prompt_id
            self._admission.notify_all()

    def block_new_dispatch(self):
        """Fence a pool sibling without acquiring a worker admission mutex.

        The pool may hold its own mutex while another worker's final validator
        checks that pool. Taking both mutexes here would invert their order.
        Already submitted calls retain their own IDs and continue collecting.
        """
        self._uncertain.set()

    def _upload_reference(self, raw, fingerprint, epoch, checkpoint, steps):
        key = (epoch, fingerprint)
        with self._admission:
            self._available_for_dispatch(epoch)
            if fingerprint in self._uploads:
                return self._uploads[fingerprint], True
            flight = self._upload_flights.get(key)
            owner = flight is None
            if owner:
                flight = {'done': threading.Event()}
                self._upload_flights[key] = flight
        if not owner:
            while not flight['done'].wait(.05):
                checkpoint(0, steps, 'Waiting for the identical character reference upload')
                with self._admission:self._available_for_dispatch(epoch)
            with self._admission:
                self._available_for_dispatch(epoch)
                if 'error' in flight:
                    raise RuntimeError('The shared character reference upload did not complete.') from flight['error']
                return flight['name'], True
        try:
            boundary = 'qt-' + secrets.token_hex(8)
            name = 'qt-' + secrets.token_hex(8) + '.png'
            body = (f'--{boundary}\r\nContent-Disposition: form-data; name="image"; filename="{name}"\r\nContent-Type: image/png\r\n\r\n'.encode()
                    + raw + f'\r\n--{boundary}--\r\n'.encode())
            req = urllib.request.Request(self.url + '/upload/image', data=body,
                headers={'Content-Type': 'multipart/form-data; boundary=' + boundary})
            with self._open(req, timeout=30) as response:uploaded = json.load(response)
            uploaded_name = uploaded['name']
            if not isinstance(uploaded_name, str) or not uploaded_name:
                raise ValueError('Character reference upload returned no filename.')
            checkpoint(0, steps, 'Character reference upload received')
            with self._admission:
                self._available_for_dispatch(epoch)
                self._uploads[fingerprint] = uploaded_name
                flight['name'] = uploaded_name
            return uploaded_name, False
        except BaseException as error:
            with self._admission:flight['error'] = error
            raise
        finally:
            with self._admission:
                self._upload_flights.pop(key, None)
                flight['done'].set()

    def invalidate_backend_cache(self):
        """Invalidate metadata without reauthorizing uncertain remote work."""
        with self._admission:
            self._worker_epoch += 1
            self._uploads.clear()
            if self._transport:self._transport.invalidate()
            self._health=(0,None);self._server_memory=(0,None);self._node_catalog=(0,None)
            self._admission.notify_all()

    def _request_json(self,url,body=None,timeout=180):
        if self._transport:return self._transport.json(url,body,timeout)
        if body is None:return request_json(url,timeout=timeout)
        return request_json(url,body,timeout=timeout)

    def _readiness_json(self,path,timeout):
        """Retry only timed-out, pre-submission metadata GETs, at most twice.

        Memory/workflow checks remain mandatory. This never wraps inference,
        uploads, history or cancellation, whose existing dispatch rules apply.
        Each attempt retains the existing timeout (9s/30s total socket bounds).
        """
        if path not in ('/system_stats','/object_info'):
            raise ValueError('Readiness retry is restricted to metadata GETs.')
        for attempt in range(3):
            try:return self._request_json(self.url+path,timeout=timeout)
            except (TimeoutError,urllib.error.URLError) as error:
                timed_out=(isinstance(error,TimeoutError) or
                    not isinstance(error,urllib.error.HTTPError) and isinstance(error.reason,TimeoutError))
                if not timed_out or attempt==2:raise

    def _open(self,request,timeout):
        if self._transport:return self._transport.open(request,timeout)
        return urllib.request.urlopen(request,timeout=timeout)

    def available_vram_gb(self):
        # A localhost SSH tunnel can lead to a different computer's GPU.
        # Always inspect ComfyUI's device rather than the helper's laptop.
        if time.time() - self._server_memory[0] > 60:
            try:
                stats = self._readiness_json('/system_stats',timeout=3)
                devices = stats.get("devices", [])
                memory = max(
                    (float(d.get("vram_total", 0)) / 2**30 for d in devices),
                    default=0,
                )
                if not math.isfinite(memory) or memory < 0:
                    raise ValueError("Invalid GPU memory reported by ComfyUI")
                self._server_memory = (time.time(), memory)
            except Exception as e:
                raise RuntimeError(
                    "Cannot verify the image server's GPU memory. Check ComfyUI and the SSH tunnel: "
                    + str(e)
                ) from e
        return self._server_memory[1]

    def template(self):
        path = self.config.get("comfyWorkflow")
        if not path or not Path(path).is_file():
            raise ValueError(
                "Configure an exported ComfyUI API workflow and bindings in studio-config.json."
            )
        return json.loads(Path(path).read_text(encoding="utf-8"))

    def getRecommendedSettings(self):
        try:
            template = self.template()
            caps = self.getCapabilities()
            size = caps["recommendedResolution"]
            return {
                "width": size[0],
                "height": size[1],
                "steps": caps["recommendedSteps"],
                "sampler": caps["recommendedSampler"],
                "scheduler": "normal",
                "guidance": caps["recommendedGuidance"],
                "denoisingStrength": caps["recommendedDenoisingStrength"],
            } | template.get("recommendedSettings", {})
        except Exception:
            return super().getRecommendedSettings()

    def getCapabilities(self):
        try:
            return BASE_CAPS | self.template()["capabilities"]
        except Exception:
            return BASE_CAPS | {
                "maxReferenceImages": 0,
                "maxResolution": 1024,
                "promptFormat": "natural-language",
                "hardwareRequirements": {"configuredWorkflowRequired": True},
            }

    def planningCatalog(self):
        """Declared workflows for planning while a paid worker is stopped.

        This is not a health check or proof that weights are installed. Every
        generation still performs the live backend/memory/model validation.
        """
        template = self.template()
        templates = template.get('variants', [template])
        return {'installed': False, 'configured': True, 'requiresLiveValidation': True,
                'models': list(dict.fromkeys([template['model']] + [t['model'] for t in templates])),
                'workflow': list(dict.fromkeys([template['name']] + [t['name'] for t in templates] + list(template.get('automaticWorkflows', {}))))}

    def getModelCapabilities(self, model):
        return self.getCapabilities() | self.template().get('modelCapabilities', {}).get(model, {})

    def resolve_template(self, request, settings):
        root = self.template()
        variants = root.get("variants")
        if not variants:
            return root, settings
        model = settings.get("model", root["model"])
        if model not in {root["model"], *(v["model"] for v in variants)}:
            raise ValueError("Selected Comfy model is not installed in this workflow bundle.")
        workflow = request.get("workflow") or settings.get("workflow") or root["name"]
        references = bool(request.get("referenceImages")) or request.get("operation") == "edit"
        automatic = root.get('automaticWorkflows', {}).get(workflow, {})
        defaults = automatic or root
        if automatic and model not in (root['model'], automatic['model']):
            raise ValueError('Selected automatic workflow belongs to another model.')
        if request.get("purpose") == "character-reference" and not references and defaults.get("referenceCreationWorkflow"):
            workflow = defaults["referenceCreationWorkflow"]
            settings = settings | dict(zip(("width", "height"), defaults.get("referenceResolution", (1024, 1024))))
        elif workflow == root["name"] and request.get("operation") == "edit" and root.get("repairWorkflow"):
            workflow = root["repairWorkflow"]
        if workflow == root["name"] or workflow in root.get('automaticWorkflows', {}):
            kind = "reference" if references else "text"
            candidates = [v for v in variants if v.get("kind") == kind and v.get("default")]
            if automatic:
                candidates = [v for v in candidates if v['model'] == automatic['model']]
            elif model != root["model"]:
                candidates = [v for v in candidates if v["model"] == model]
            else:
                candidates = [v for v in candidates if v['model'] not in root.get('modelCapabilities', {})]
            reference_count = len(request.get('referenceImages', [])) + int(request.get('operation') == 'edit')
            candidates = [v for v in candidates if v.get('referenceCount', reference_count) == reference_count]
        else:
            candidates = [v for v in variants if v["name"] == workflow and model in (root["model"], v["model"])]
        if len(candidates) != 1:
            raise ValueError("Selected model/workflow is incompatible with the supplied references. Select the configured automatic workflow or a compatible explicit workflow.")
        template = candidates[0]
        if settings.get("loras") and settings["loras"] != template.get("presetSettings", {}).get("loras"):
            raise ValueError("Custom LoRA settings do not match this exported workflow. Configure a workflow containing the requested adapters before generating.")
        if template.get("kind") == "reference" and not references:
            raise ValueError("This image-edit workflow needs a source or character reference image. Use text-to-image for a new reference sheet.")
        reference_count = len(request.get('referenceImages', [])) + int(request.get('operation') == 'edit')
        if 'referenceCount' in template and template['referenceCount'] != reference_count:
            raise ValueError('Selected workflow requires exactly ' + str(template['referenceCount']) + ' references. Use the automatic workflow for this shot.')
        if template.get("kind") == "text" and references:
            raise ValueError("This text-to-image workflow cannot condition on character references. Select a reference workflow; no references were discarded.")
        # Lightning adapters are trained for a fixed step count and CFG.
        # Their exact preset settings are stored with the resulting image.
        return template, settings | template.get("presetSettings", {})

    def healthCheck(self, model=None, workflow=None):
        try:
            template = self.template()
            catalog_stamp = (self.config.get("comfyWorkflow"), Path(self.config["comfyWorkflow"]).stat().st_mtime_ns)
            stamp=catalog_stamp+(model,workflow)
            if self._health[1] and self._health[1][0] == stamp and time.time() - self._health[0] < 30:
                return copy.deepcopy(self._health[1][1])
            if self._node_catalog[1] and self._node_catalog[1][0]==catalog_stamp and time.time()-self._node_catalog[0]<30:
                nodes=self._node_catalog[1][1]
            else:
                nodes = self._readiness_json('/object_info',timeout=10)
                self._node_catalog=(time.time(),(catalog_stamp,nodes))
            templates = template.get("variants", [template])
            selected=model or template.get('automaticWorkflows',{}).get(workflow,{}).get('model')
            explicit=[t for t in templates if t['name']==workflow] if workflow else []
            if explicit:templates=explicit
            elif selected:
                templates=[t for t in templates if t['model']==selected or
                    selected==template['model'] and t['model'] not in template.get('modelCapabilities',{})]
            if not templates:return {'installed':False,'models':[],'workflow':[],
                'error':'Selected image model/workflow is not configured.'}
            # Generic status may advertise the ready subset of a mixed bundle.
            # Selected generation must validate only its relevant graphs; a
            # deliberately removed unrelated checkpoint cannot block FLUX.
            if not model and not workflow and len(templates)>1:
                checks=[self.healthCheck(t['model'],t['name']) for t in templates]
                ready=[t for t,check in zip(templates,checks) if check['installed']]
                auto=[name for name,value in template.get('automaticWorkflows',{}).items()
                      if any(t['model']==value['model'] for t in ready)]
                return {'installed':bool(ready),'models':list(dict.fromkeys(t['model'] for t in ready)),
                    'workflow':[t['name'] for t in ready]+auto,
                    'unavailableWorkflows':[t['name'] for t,check in zip(templates,checks) if not check['installed']],
                    'missingNodes':list(dict.fromkeys(n for check in checks for n in check.get('missingNodes',[]))) if not ready else [],
                    'missingWeights':list(dict.fromkeys(n for check in checks for n in check.get('missingWeights',[]))) if not ready else []}
            missing = [
                v["class_type"]
                for t in templates for v in t["prompt"].values()
                if v["class_type"] not in nodes
            ]
            missing_weights = []
            for node in (n for t in templates for n in t["prompt"].values()):
                info = (
                    nodes.get(node["class_type"], {})
                    .get("input", {})
                    .get("required", {})
                )
                for field in (
                    "ckpt_name",
                    "unet_name",
                    "vae_name",
                    "clip_name",
                    "lora_name",
                    "control_net_name",
                ):
                    choices = info.get(field, [None])[0]
                    if (
                        field in node["inputs"]
                        and isinstance(choices, list)
                        and node["inputs"][field] not in choices
                    ):
                        missing_weights.append(node["inputs"][field])
            result = {
                "installed": not missing and not missing_weights,
                "models": list(dict.fromkeys([template["model"]] + [t["model"] for t in templates])),
                "workflow": list(dict.fromkeys([template["name"]] + [t["name"] for t in templates] + list(template.get('automaticWorkflows', {})))),
                "missingNodes": missing,
                "missingWeights": missing_weights,
            }
            if result["installed"]:
                self._health = (time.time(), (stamp, result))
            return result
        except Exception as e:
            return {"installed": False, "error": str(e)}

    def _skip_builtin_qwen_cfg1_negative_encoding(self, template, prompt):
        """Drop only an inactive dependency in an unmodified built-in bundle.

        Native CFG1 discards unconditional conditioning before the denoiser.
        The audited default post-CFGNorm does not disable that optimization.
        Keep exported nodes/bindings intact; only the sampler socket changes.
        Manual graphs and every non-CFG1 resolved sampler retain their branch.
        """
        try:
            from qwen_workflow import bundle as qwen_bundle
            from flux_workflow import bundle as flux_bundle
        except ImportError:
            return False

        builtin = qwen_bundle()
        if template not in builtin["variants"]:
            return False
        configured = self.template()
        if configured != builtin and configured != flux_bundle():
            return False
        sampler = prompt.get("9", {})
        inputs = sampler.get("inputs", {})
        cfg = inputs.get("cfg")
        if (sampler.get("class_type") != "KSampler"
                or type(cfg) not in (int, float) or cfg != 1
                or inputs.get("model") != ["5", 0]
                or prompt.get("5") != {
                    "class_type": "CFGNorm", "inputs": {
                        "model": ["4", 0], "strength": 1.0, "pre_cfg": False}}
                or prompt["5"]["inputs"]["pre_cfg"] is not False):
            return False
        positive = ["12", 0] if template.get("kind") == "reference" else ["6", 0]
        negative = ["13", 0] if template.get("kind") == "reference" else ["7", 0]
        if inputs.get("positive") != positive or inputs.get("negative") != negative:
            return False
        inputs["negative"] = copy.deepcopy(positive)
        return True

    def generateImage(self, r, checkpoint):
        epoch = self._acquire_request(r, checkpoint)
        execution = {'epoch': epoch, 'submitted': False, 'terminal': False,
                     'observerStarted': False, 'remoteId': None}
        try:
            return self._generate_image(r, checkpoint, execution)
        except BaseException as error:
            if isinstance(error, ImageAdmissionBlocked):
                raise
            elif isinstance(error, RemoteGenerationUncertain):
                self._latch_uncertainty(error.prompt_id)
            elif execution['submitted'] and not execution['terminal']:
                self._latch_uncertainty(execution['remoteId'])
                # Preserve the legacy single-slot user-cancel signal. A queued
                # cancellation must surface unresolved ownership to the caller.
                if not isinstance(error, Exception) or (
                        self._request_slots == 1 and isinstance(error, InterruptedError)):
                    raise
                raise RemoteGenerationUncertain(execution['remoteId']) from error
            elif (execution['observerStarted'] and not execution['terminal']
                    and self._request_slots == 2):
                # A durable admission hook may have partly committed before it
                # failed. No HTTP replay or sibling admission is safe here.
                self._latch_uncertainty()
                if isinstance(error, Exception):raise RemoteGenerationUncertain() from error
            raise
        finally:
            with self._admission:
                self._active_requests -= 1
                self._admission.notify_all()

    def _generate_image(self, r, checkpoint, execution):
        began = time.monotonic()
        polling_interval = self.config.get('comfyPollInterval', .25)
        timeout = self.config.get('comfyGenerationTimeoutSeconds', 600)
        if (isinstance(polling_interval, bool) or not isinstance(polling_interval, (int, float))
                or not math.isfinite(polling_interval) or not .1 <= polling_interval <= 2):
            raise ValueError('ComfyUI polling interval must be 0.1–2 seconds.')
        if (isinstance(timeout, bool) or not isinstance(timeout, (int, float))
                or not math.isfinite(timeout) or not 30 <= timeout <= 3600):
            raise ValueError('ComfyUI generation timeout must be 30–3600 seconds.')
        s = self.validateSettings(r["settings"])
        t, s = self.resolve_template(r, s)
        health = self.healthCheck(model=t['model'],workflow=t.get('name'))
        if not health["installed"]:
            raise RuntimeError("ComfyUI workflow unavailable: " + str(health))
        if not self.template().get("variants") and s.get("model") != t["model"]:
            raise ValueError(
                "Selected Comfy model does not match the configured workflow."
            )
        prompt = copy.deepcopy(t["prompt"])
        values = {
            "prompt": r["prompt"],
            "negativePrompt": r.get("negativePrompt", ""),
            **s,
        }
        for key, bindings in t["bindings"].items():
            if key in values:
                for node, field in bindings:
                    prompt[str(node)]["inputs"][field] = values[key]
        # Reference slots are explicit bindings, never assumed from model names.
        refs = r.get("referenceImages", [])
        if r.get("operation") == "edit":
            refs = [r["sourceImage"]] + refs
        if len(refs) > self.getCapabilities().get("maxReferenceImages", 0):
            raise ValueError("Too many references for this ComfyUI workflow, including the edit source. No character references were silently dropped.")
        for index in range(len(refs)):
            if not t["bindings"].get("reference" + str(index)):
                raise ValueError(f"ComfyUI workflow has no binding for reference {index + 1}. Configure character references before generating.")
        for index, node in t.get("referenceNodes", {}).items():
            if int(index) >= len(refs):
                prompt.pop(str(node), None)
                for value in prompt.values():
                    value["inputs"] = {key: field for key, field in value["inputs"].items()
                        if not (isinstance(field, list) and field and str(field[0]) == str(node))}
        negative_encoding_skipped = self._skip_builtin_qwen_cfg1_negative_encoding(t, prompt)
        prepared = time.monotonic()
        upload_hits = 0
        for index, ref in enumerate(refs):
            checkpoint(0, s["steps"], "Uploading character references")
            raw, fingerprint = _image_encoding_cache.reference_bytes(ref)
            uploaded_name, cache_hit = self._upload_reference(
                raw, fingerprint, execution['epoch'], checkpoint, s['steps'])
            upload_hits += int(cache_hit)
            for node, field in t["bindings"].get("reference" + str(index), []):
                prompt[str(node)]["inputs"][field] = uploaded_name
        uploaded_at = time.monotonic()
        observer = r.get('_executionObserver')
        if observer is not None and not callable(observer):
            raise ValueError('Execution observer must be callable.')
        validator = r.get('_preDispatchValidator')
        if validator is not None and not callable(validator):
            raise ValueError('Pre-dispatch validator must be callable.')
        operation_id = 'comfy-' + secrets.token_hex(16)
        # One admission mutex orders the final source/cap/cancel validation,
        # durable intent and single POST against uncertainty/lifetime changes.
        # It does not cover generation, polling or image retrieval.
        with self._admission:
            self._available_for_dispatch(execution['epoch'])
            checkpoint(0, s['steps'], 'Submitting ComfyUI generation')
            if validator:validator()
            self._available_for_dispatch(execution['epoch'])
            if observer:
                execution['observerStarted'] = True
                observer('submitting', {'operationId': operation_id, 'provider': 'comfyui'})
            try:
                self._available_for_dispatch(execution['epoch'])
            except Exception:
                # The intent was durable, but this exact call has not entered
                # its POST. Settle only this unused operation before stopping.
                if observer:observer('rejected', {'operationId': operation_id})
                execution['terminal'] = True
                raise
            execution['submitted'] = True
            try:
                job = self._request_json(
                    self.url + '/prompt', {'prompt': prompt, 'client_id': secrets.token_hex(16)})
                id = job['prompt_id']
                if not isinstance(id, str) or not id:
                    raise ValueError('No confirmed ComfyUI prompt identity.')
                execution['remoteId'] = id
                if observer:
                    try:observer('accepted', {'operationId': operation_id, 'remoteId': id})
                    except Exception as error:raise RemoteGenerationUncertain(id) from error
            except urllib.error.HTTPError as error:
                # A gateway can return 408 after the worker accepted the request.
                # Only explicit rejection statuses prove no generation bought.
                if error.code in (400, 401, 403, 404, 413, 422, 429):
                    if observer:observer('rejected', {'operationId': operation_id})
                    execution['terminal'] = True
                    raise
                raise RemoteGenerationUncertain() from error
            except (OSError, ValueError, KeyError, TypeError) as error:
                raise RemoteGenerationUncertain(execution['remoteId']) from error
        submitted_at = time.monotonic()
        started = time.time()
        polls = 0
        try:
            while True:
                checkpoint(0, s["steps"], "ComfyUI generation")
                try:
                    history = self._request_json(self.url + "/history/" + id, timeout=15)
                except (OSError, ValueError) as error:
                    raise RemoteGenerationUncertain(id) from error
                polls += 1
                if id in history:
                    break
                if time.monotonic() - submitted_at > timeout:
                    raise RemoteGenerationUncertain(id, timed_out=True)
                time.sleep(polling_interval)
        except Exception as error:
            # Queue deletion is scoped to this exact prompt. Queued delivery
            # never uses global interrupt: the running job could have changed
            # between GET /queue and POST /interrupt, harming a sibling.
            # A transient disconnect may still finish successfully. Leave that
            # request alone for reconciliation; explicit cancel/timeout stops it.
            if not isinstance(error, RemoteGenerationUncertain) or error.timed_out:
                try:
                    self._request_json(self.url + "/queue", {"delete": [id]}, timeout=3)
                    if self._request_slots == 1:
                        q = self._request_json(self.url + '/queue', timeout=3)
                        if any(v[1] == id for v in q.get('queue_running', [])):
                            self._request_json(self.url + '/interrupt', {}, timeout=3)
                except Exception:
                    pass
            raise
        finished_at = time.monotonic()
        entry = history[id]
        if entry.get("status", {}).get("status_str") == "error":
            if observer:
                try:observer('failed', {'operationId': operation_id})
                except Exception as error:raise RemoteGenerationUncertain(id) from error
            execution['terminal'] = True
            raise RuntimeError("ComfyUI failed: " + str(entry.get("status"))[:1200])
        try:
            image = next(
                v["images"][0] for v in entry["outputs"].values() if v.get("images")
            )
        except (KeyError, StopIteration, TypeError, AttributeError) as error:
            raise RemoteGenerationUncertain(id) from error
        from urllib.parse import urlencode

        try:
            with self._open(self.url + "/view?" + urlencode(image), timeout=30) as response:
                raw = response.read()
        except OSError as error:
            raise RemoteGenerationUncertain(id) from error
        img = visible_image(raw)
        result = {
            "pil": img,
            "seed": s["seed"],
            "seconds": time.time() - started,
            "provider": self.id,
            "model": t["model"],
            "workflow": t["name"],
            "settings": s,
            "resolvedWorkflow": prompt,
            'remotePromptId': id,
            'requestSlots': self._request_slots,
            'serverExecutionEvidence': execution_evidence(entry,prompt),
            'providerTimings': {
                'preparationSeconds': prepared-began,
                'referenceUploadSeconds': uploaded_at-prepared,
                'submissionSeconds': submitted_at-uploaded_at,
                'waitAndPollingSeconds': finished_at-submitted_at,
                'retrievalAndValidationSeconds': time.monotonic()-finished_at,
                'totalClientSeconds': time.monotonic()-began,
                'historyRequests': polls,
                'references':len(refs),'referenceUploadCacheHits':upload_hits,
                'negativeEncodingDependencySkipped':negative_encoding_skipped,
                'timingSource':'client wall time; wait includes queue, inference and polling',
            },
        }
        if observer:
            try:observer('completed', {'operationId': operation_id})
            except Exception as error:raise RemoteGenerationUncertain(id) from error
        execution['terminal'] = True
        return result


def visible_appearance(shot, selected):
    # Persistent possessions remain in story state. A visible prop needs a
    # current director decision, rather than blindly reenacting prior combat.
    context = ' '.join(str(shot.get(k, '')) for k in ('action', 'narrationSegment', 'pose'))
    context += ' ' + str(shot.get('camera', {}).get('composition', ''))
    appearance = selected.get('appearanceState', {})
    weapons = ('gun', 'hammer', 'knife', 'sword', 'bomb')
    named = {k for k in weapons if re.search(r'\b'+k+r's?\b', context, re.IGNORECASE)}
    # A director can write "weapon raised" while the canonical scene state
    # says "gun in his hand". Do not erase that unambiguous visible prop, or
    # the generator is left to invent a blade. Carried/stowed inventory and
    # multiple held weapons remain insufficient evidence to choose a prop.
    if not named and re.search(r'\bweapons?\b', context, re.IGNORECASE) and not re.search(
        r'\bunarmed\b|\bempty[- ]handed\b|\b(?:no|without)\s+(?:(?:a|any|his|her|their)\s+)?weapons?\b', context, re.IGNORECASE
    ):
        held = []
        for kind in weapons:
            state = str(appearance.get(kind, '')).lower().replace('_', ' ')
            if not re.search(r'\b(?:dropped|removed|holstered|stowed)\b|on (?:the )?floor|not holding|no longer', state) and re.search(
                r'\b(?:holding|held|wielding|aiming|raised|firing)\b|\b(?:right|left) hand\b|\bin (?:(?:his|her|their|the) )?hand\b', state
            ):
                held.append(kind)
        if len(held) == 1:
            named.add(held[0])
    physical = {'outfit','clothing','hairStyle','injury','accessories','wetness','dirt','makeup',
                'disguise','age','transformation','status','restraint','posture','face','hair','eyes',
                'skin','build','height','distinguishingMarks','watch','necklace','scar'}
    visible = {}
    for key,value in appearance.items():
        if key in weapons and key not in named: continue
        # Weapons have already passed their named/unambiguous-held test above.
        # Requiring their literal name again would erase "weapon raised" + the
        # single canonical held gun, leaving the generator to invent its type.
        if key not in physical and key not in weapons and re.search(r'\b(?:held|holding|carr(?:y|ies|ied)|hands?|floor|dropped|removed|stowed)\b',str(value),re.I):
            words = [w for w in re.findall(r'[a-z]+',key.lower()) if w not in ('the','of','a','an')]
            if words and not all(re.search(r'\b'+re.escape(w)+r's?\b',context,re.I) for w in words): continue
        visible[key]=value
    return visible


def visual_continuity(value, names):
    """Keep visual facts while removing database identifiers from model text."""
    if isinstance(value, dict):
        return {names.get(key, key): visual_continuity(item, names)
                for key, item in value.items()
                if not re.search(r'(?:^id$|[_-]ids?$|Ids?$|IDs?$)', key)}
    if isinstance(value, list):
        return [visual_continuity(item, names) for item in value]
    return names.get(value, value) if isinstance(value, str) else value


def format_prompt(project, shot, provider):
    from prompt_quality import focused
    use_focused = focused(project,shot)
    if shot.get("manual",{}).get("prompt"):
        return shot.get("prompt",""),shot.get("negativePrompt","")
    people = {c["id"]: c for c in project["characters"]}
    ch = shot_chapter(project,shot) or {"people":[]}
    people.update({c["id"]: c for c in ch["people"]})
    descriptions = []
    for selected in shot["characters"]:
        p = people.get(selected["id"], {})
        identity = p.get("permanentIdentity", {})
        details = (
            [p.get("name", selected["id"])]
            + ([p.get("description", "")] if not any(identity.values()) else [])
            + [f"{k}: {v}" for k, v in identity.items() if v]
            + [f"{k}: {v}" for k, v in visible_appearance(shot, selected).items() if v]
        )
        if use_focused:
            details += [f"{k}: {p[k]}" for k in ("gender","approximateAge") if p.get(k)]
        descriptions.append("; ".join(details))
    camera = shot["camera"]
    parts = [
        shot["action"],
        (
            "Characters: " + " / ".join(descriptions)
            if descriptions
            else "No people in this shot."
        ),
        "Camera: "
        + camera["shot"]
        + ", "
        + camera["angle"]
        + ". "
        + camera["composition"],
        "Location: " + shot.get("location", ""),
        "Expression and pose: "
        + shot.get("expression", "")
        + "; "
        + shot.get("pose", ""),
        "Lighting: " + shot.get("lighting", ""),
        "Style: " + project["settings"]["style"],
    ]
    visual_constraints = project['settings'].get('imageVisualConstraints', project['settings'].get('visualConstraints', ''))
    if visual_constraints:
        parts.append('Production constraints: ' + visual_constraints)
    parts.append('One continuous landscape scene at one moment. Preserve identity and current clothing; only stated story changes override them. No extra important people, duplicate bodies, collage, borders or text.')
    if shot.get("continuity"):
        # Persistent environmental history is not an instruction to reenact an
        # earlier battle. Only stable scene conditions belong in this prompt.
        names = {key: person.get('name', key) for key, person in people.items()}
        names.update({place['id']: place.get('name', place['id']) for place in project.get('locations', [])})
        from story_grounding import visual_environment
        continuity = visual_continuity(visual_environment(shot), names)
        if continuity:
            parts.append('Current scene: '+ '; '.join(f'{key}: {value}' for key,value in continuity.items()))
    caps = (provider.getModelCapabilities(shot.get('imageModel', ''))
            if hasattr(provider, 'getModelCapabilities') else provider.getCapabilities())
    prompt = (
        ". ".join(p for p in parts if p)
    )
    if caps.get("promptFormat") == "sd-tags":
        prompt = (
            ", ".join(p for p in parts if p)
            + ", clear foreground action, consistent character identity, coherent composition"
        )
    negative = (
        "text, watermark, black frame, severe artifacts, extra limbs, malformed hands, unwanted characters"
        if caps.get("supportsNegativePrompt")
        else ""
    )
    return prompt, negative


# Candidate binding stays experimental until the matched image test passes.
CURRENT_APPEARANCE_REFERENCES = False


def _reference_clothing_changed(person, current):
    """Only an explicit current/baseline difference changes reference guidance."""
    baseline = person.get('defaultAppearance', {})
    clothing = str(current.get('outfit') or current.get('clothing') or '').strip()
    original = str(baseline.get('outfit') or baseline.get('clothing') or '').strip()
    return bool(clothing and original
                and ' '.join(clothing.casefold().split()) != ' '.join(original.casefold().split()))


def reference_prompt(project, shot, metadata, operation="generate", include_scene_facts=True):
    """Name reference roles without locking a character to old reference clothing."""
    chapter = shot_chapter(project,shot) or {"people":[]}
    people = {c["id"]: c for c in project["characters"] + chapter["people"]}
    appearances = {c['id']: visible_appearance(shot, c) for c in shot['characters']}
    from prompt_quality import focused
    use_focused = focused(project,shot)
    automatic_prompt = not shot.get('manual', {}).get('prompt')
    binding_enabled = automatic_prompt and CURRENT_APPEARANCE_REFERENCES
    multiple_people = len({ref['characterId'] for ref in metadata if ref.get('characterId')}) > 1
    notes = []
    offset = 1 if operation == "edit" else 0
    if offset:
        notes.append("Image 1 is the shot to edit. Preserve its unaffected people, objects and composition.")
    for index, ref in enumerate(metadata, 1 + offset):
        if ref.get("characterId"):
            person = people.get(ref["characterId"], {})
            if use_focused:
                notes.append(f'Image {index}: {person.get("name", ref["characterId"])} permanent face identity. Shot controls clothing and pose: ' + json.dumps(appearances.get(ref["characterId"],{}),ensure_ascii=False) + ".")
                continue
            notes.append(
                f'Use image {index} as the identity reference for {person.get("name", ref["characterId"])}. '
                "Preserve face and permanent traits; the shot's current appearance controls clothing and pose."
            )
            current = appearances.get(ref['characterId'], {})
            if binding_enabled and (multiple_people or _reference_clothing_changed(person, current)):
                # Bind state to its actual subject beside the numbered reference.
                # A value occurring elsewhere in the body may describe another
                # person; it is not evidence that this subject's state is bound.
                if current:
                    notes.append(f'Current-shot state for {person.get("name", ref["characterId"])}: '
                                 + '; '.join(f'{key}: {value}' for key, value in current.items() if value) + '.')
                continue
            # Saved or hand-authored prompts may omit current appearance.
            # Deduplicate only facts already in the body, never erase them.
            body=shot.get('prompt','').casefold()
            missing=[f'{key}: {value}' for key,value in appearances.get(ref['characterId'],{}).items()
                     if value and str(value).casefold() not in body]
            if missing:notes.append('Current appearance: '+ '; '.join(missing)+'.')
        elif ref.get("locationId"):
            notes.append(f"Use image {index} for the location architecture and palette, not character identity.")
        elif ref.get("referenceType") == "style":
            notes.append(f"Use image {index} for visual style only, not its characters or events.")
        else:
            notes.append(f"Use image {index} only for its user-selected reference role.")
    if binding_enabled and multiple_people:
        notes.append('Keep each named person matched to their own reference and current-shot state, including their own pose and restraints.')
    from scene_conditioning import enabled, scene_contract
    if include_scene_facts and enabled(project,shot):
        notes.append(scene_contract(project,shot))
    return " ".join(notes)


def select_references(project, shot, store, provider, reserved_slots=0):
    caps = (provider.getModelCapabilities(shot['imageModel'])
            if shot.get('imageModel') and hasattr(provider, 'getModelCapabilities')
            else provider.getCapabilities())
    maximum = max(0, caps.get("maxReferenceImages", 0) - reserved_slots)
    refs = []
    metadata = []
    if shot.get("manual", {}).get("referenceImages"):
        selected = shot.get("referenceImages", [])
        if len(selected) > maximum:
            raise ValueError('Selected references exceed the image workflow limit '
                             f'({len(selected)} selected, {maximum} available). '
                             'Choose a compatible workflow or edit the reference selection; '
                             'no references were silently dropped.')
        return [
            data_url(store.asset(project["id"], r["path"])) for r in selected
        ], copy.deepcopy(selected)
    chapter = shot_chapter(project,shot) or {"people":[]}
    people = project["characters"] + chapter["people"]
    required_main = sum(
        selected.get('type') == 'main'
        and bool(next((p.get('references') for p in people if p['id'] == selected['id']), []))
        for selected in shot['characters']
    )
    if caps.get('maxReferenceImages', 0) and required_main > maximum:
        raise ValueError(f'This shot needs identity references for {required_main} main characters, '
                         f'but the selected model/workflow has {maximum} available reference slots '
                         'after reserving the edit source. Choose a compatible workflow; '
                         'no character identity references were silently dropped.')
    if not maximum:
        return [], []
    for selected in sorted(shot["characters"], key=lambda c: c["type"] != "main"):
        p = next((c for c in people if c["id"] == selected["id"]), None)
        if not p:
            continue
        options = p.get("references", [])
        angle = shot["camera"].get("angle", "").lower()
        distance = shot["camera"].get("shot", "").lower()
        desired = (
            ["side", "full-body"]
            if "profile" in angle + distance
            else (
                ["back", "full-body"]
                if "behind" in angle
                else (
                    ["face", "front", "expression"]
                    if "close" in distance
                    else ["full-body", "three-quarter", "front"]
                )
            )
        )
        # An outfit change should not preferentially pull a full-body portrait's
        # old costume into the new scene when an identity portrait is available.
        # Preserve angle-specific side/back selection and never invent a change
        # from missing baseline or current clothing data.
        current = visible_appearance(shot, selected)
        if (CURRENT_APPEARANCE_REFERENCES and not shot.get('manual', {}).get('prompt') and _reference_clothing_changed(p, current)
                and 'profile' not in angle + distance and 'behind' not in angle):
            desired = ['face', 'expression', 'front', 'three-quarter', 'full-body']
        ordered = sorted(
            options,
            key=lambda r: (
                desired.index(r.get("kind")) if r.get("kind") in desired else 9
            ),
        )
        if ordered:
            if len(refs) >= maximum:
                break
            r = ordered[0]
            from scene_conditioning import enabled, conditioned_reference,needs_identity_only
            if enabled(project,shot) and needs_identity_only(project,shot,p['id']):
                data, conditioned = conditioned_reference(project,r,store)
                refs.append(data)
                metadata.append(conditioned | {"characterId": p["id"]})
            else:
                refs.append(data_url(store.asset(project["id"], r["path"])))
                metadata.append(r | {"characterId": p["id"]})
    if len(refs) < maximum and caps.get("supportsStyleReference"):
        location = next(
            (
                x
                for x in project.get("locations", [])
                if x["id"] == shot.get("locationId")
            ),
            None,
        )
        if location and location.get("references"):
            r = location["references"][0]
            refs.append(data_url(store.asset(project["id"], r["path"])))
            metadata.append(r | {"locationId": location["id"]})
        if len(refs) < maximum and project.get("styleReferences"):
            r = project["styleReferences"][0]
            refs.append(data_url(store.asset(project["id"], r["path"])))
            metadata.append(r | {"referenceType": "style"})
    return refs[:maximum], metadata[:maximum]
